// Serviço de comunicação em rede para sincronização entre módulos
export class NetworkService {
  private static instance: NetworkService;
  private localIP: string = '';
  private discoveredDevices: Map<string, any> = new Map();
  private syncInterval: NodeJS.Timeout | null = null;
  private isDiscovering: boolean = false;

  static getInstance(): NetworkService {
    if (!NetworkService.instance) {
      NetworkService.instance = new NetworkService();
    }
    return NetworkService.instance;
  }

  constructor() {
    this.detectLocalIP();
    this.startDeviceDiscovery();
  }

  // Detectar IP local do dispositivo
  private async detectLocalIP(): Promise<void> {
    try {
      // Método 1: WebRTC para detectar IP local
      const pc = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
      });
      
      pc.createDataChannel('');
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      
      pc.onicecandidate = (event) => {
        if (event.candidate) {
          const candidate = event.candidate.candidate;
          const ipMatch = candidate.match(/(\d+\.\d+\.\d+\.\d+)/);
          if (ipMatch && !ipMatch[1].startsWith('127.')) {
            this.localIP = ipMatch[1];
            console.log('🌐 IP local detectado:', this.localIP);
            pc.close();
          }
        }
      };
    } catch (error) {
      console.warn('⚠️ Não foi possível detectar IP local via WebRTC:', error);
      // Fallback: usar IP padrão da rede local
      this.localIP = '192.168.1.100';
    }
  }

  // Descobrir dispositivos na rede local
  async discoverNetworkDevices(): Promise<any[]> {
    if (this.isDiscovering) return Array.from(this.discoveredDevices.values());
    
    this.isDiscovering = true;
    console.log('🔍 Iniciando descoberta de dispositivos na rede...');
    
    const devices: any[] = [];
    const baseIP = this.localIP.substring(0, this.localIP.lastIndexOf('.'));
    
    // Escanear IPs comuns da rede local
    const commonIPs = [
      '192.168.1',
      '192.168.0', 
      '10.0.0',
      '172.16.0'
    ];
    
    const ipsToScan = commonIPs.includes(baseIP) ? [baseIP] : [baseIP, ...commonIPs];
    
    for (const ipBase of ipsToScan) {
      // Escanear apenas IPs mais prováveis para impressoras e dispositivos
      const targetIPs = [
        `${ipBase}.100`, `${ipBase}.101`, `${ipBase}.102`, `${ipBase}.103`,
        `${ipBase}.200`, `${ipBase}.201`, `${ipBase}.202`, `${ipBase}.203`,
        `${ipBase}.10`, `${ipBase}.11`, `${ipBase}.12`, `${ipBase}.13`,
        `${ipBase}.20`, `${ipBase}.21`, `${ipBase}.22`, `${ipBase}.23`,
      ];
      
      const promises = targetIPs.map(ip => this.checkDevice(ip));
      const results = await Promise.allSettled(promises);
      
      results.forEach((result, index) => {
        if (result.status === 'fulfilled' && result.value) {
          devices.push(result.value);
          this.discoveredDevices.set(targetIPs[index], result.value);
        }
      });
    }
    
    this.isDiscovering = false;
    console.log(`✅ Descoberta concluída: ${devices.length} dispositivos encontrados`);
    return devices;
  }

  // Verificar se um IP específico tem um dispositivo/impressora
  private async checkDevice(ip: string): Promise<any | null> {
    const commonPorts = [9100, 631, 515, 80, 8080, 3000, 3001, 5000];
    
    for (const port of commonPorts) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2000);
        
        const response = await fetch(`http://${ip}:${port}/status`, {
          method: 'GET',
          mode: 'no-cors',
          signal: controller.signal,
        });
        
        clearTimeout(timeoutId);
        
        // Se chegou até aqui, o dispositivo respondeu
        const deviceType = this.identifyDeviceType(port);
        
        return {
          ip,
          port,
          type: deviceType,
          name: `${deviceType} em ${ip}:${port}`,
          lastSeen: new Date().toISOString(),
          status: 'online'
        };
        
      } catch (error) {
        // Continuar tentando outras portas
        continue;
      }
    }
    
    return null;
  }

  // Identificar tipo de dispositivo baseado na porta
  private identifyDeviceType(port: number): string {
    switch (port) {
      case 9100:
        return 'Impressora Térmica';
      case 631:
        return 'Impressora IPP';
      case 515:
        return 'Impressora LPR';
      case 80:
      case 8080:
        return 'Servidor Web';
      case 3000:
      case 3001:
      case 5000:
        return 'Sistema PDV';
      default:
        return 'Dispositivo de Rede';
    }
  }

  // Sincronizar dados entre módulos na rede
  async syncWithNetwork(data: any): Promise<void> {
    const devices = Array.from(this.discoveredDevices.values());
    const pdvDevices = devices.filter(d => d.type === 'Sistema PDV');
    
    console.log('🔄 Sincronizando com dispositivos PDV na rede:', pdvDevices.length);
    
    for (const device of pdvDevices) {
      try {
        await fetch(`http://${device.ip}:${device.port}/api/sync`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            type: 'data_sync',
            source: this.localIP,
            timestamp: new Date().toISOString(),
            data: data
          }),
          mode: 'no-cors'
        });
        
        console.log(`✅ Dados sincronizados com ${device.ip}:${device.port}`);
      } catch (error) {
        console.warn(`⚠️ Falha ao sincronizar com ${device.ip}:${device.port}:`, error);
      }
    }
  }

  // Enviar pedido para impressora de rede
  async sendToNetworkPrinter(printerIP: string, printerPort: number, content: string): Promise<boolean> {
    const endpoints = [
      `/print`,
      `/raw`,
      `/thermal`,
      `/pos`,
      `/`
    ];
    
    console.log(`🖨️ Tentando enviar para impressora ${printerIP}:${printerPort}`);
    
    for (const endpoint of endpoints) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000);
        
        const response = await fetch(`http://${printerIP}:${printerPort}${endpoint}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'text/plain',
            'Accept': '*/*',
          },
          body: content,
          mode: 'no-cors',
          signal: controller.signal,
        });
        
        clearTimeout(timeoutId);
        console.log(`✅ Pedido enviado com sucesso para ${printerIP}:${printerPort}${endpoint}`);
        return true;
        
      } catch (error) {
        console.warn(`⚠️ Falha no endpoint ${endpoint}:`, error);
        continue;
      }
    }
    
    console.error(`❌ Falha em todos os endpoints para ${printerIP}:${printerPort}`);
    return false;
  }

  // Descobrir impressoras na rede automaticamente
  async discoverPrinters(): Promise<any[]> {
    console.log('🖨️ Descobrindo impressoras na rede...');
    
    const devices = await this.discoverNetworkDevices();
    const printers = devices.filter(device => 
      device.type.includes('Impressora') || 
      [9100, 631, 515].includes(device.port)
    );
    
    console.log(`🖨️ ${printers.length} impressora(s) encontrada(s):`, printers);
    return printers;
  }

  // Iniciar descoberta automática de dispositivos
  private startDeviceDiscovery(): void {
    // Descobrir dispositivos a cada 30 segundos
    this.syncInterval = setInterval(() => {
      this.discoverNetworkDevices();
    }, 30000);
    
    // Descoberta inicial
    setTimeout(() => {
      this.discoverNetworkDevices();
    }, 2000);
  }

  // Parar descoberta de dispositivos
  stopDeviceDiscovery(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
  }

  // Obter dispositivos descobertos
  getDiscoveredDevices(): any[] {
    return Array.from(this.discoveredDevices.values());
  }

  // Obter impressoras descobertas
  getDiscoveredPrinters(): any[] {
    return this.getDiscoveredDevices().filter(device => 
      device.type.includes('Impressora') || 
      [9100, 631, 515].includes(device.port)
    );
  }

  // Testar conectividade com dispositivo
  async testDeviceConnection(ip: string, port: number): Promise<boolean> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);
      
      await fetch(`http://${ip}:${port}/ping`, {
        method: 'GET',
        mode: 'no-cors',
        signal: controller.signal,
      });
      
      clearTimeout(timeoutId);
      return true;
    } catch (error) {
      return false;
    }
  }
}