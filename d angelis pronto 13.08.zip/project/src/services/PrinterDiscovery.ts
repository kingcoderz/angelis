// Serviço especializado para descoberta e configuração de impressoras
export class PrinterDiscoveryService {
  private static instance: PrinterDiscoveryService;
  private discoveredPrinters: Map<string, any> = new Map();
  private isScanning: boolean = false;

  static getInstance(): PrinterDiscoveryService {
    if (!PrinterDiscoveryService.instance) {
      PrinterDiscoveryService.instance = new PrinterDiscoveryService();
    }
    return PrinterDiscoveryService.instance;
  }

  // Descobrir impressoras na rede local
  async discoverPrinters(): Promise<any[]> {
    if (this.isScanning) {
      console.log('🔍 Descoberta já em andamento...');
      return Array.from(this.discoveredPrinters.values());
    }

    this.isScanning = true;
    console.log('🖨️ Iniciando descoberta de impressoras na rede...');
    
    const printers: any[] = [];
    
    // IPs comuns para impressoras
    const commonNetworks = [
      '192.168.1',
      '192.168.0',
      '10.0.0',
      '172.16.0',
      '192.168.100'
    ];
    
    // Portas comuns para impressoras
    const printerPorts = [
      9100, // Raw/Direct IP
      631,  // IPP (Internet Printing Protocol)
      515,  // LPR (Line Printer Remote)
      80,   // HTTP
      8080, // HTTP alternativo
      23    // Telnet
    ];

    for (const network of commonNetworks) {
      // Escanear IPs mais prováveis para impressoras
      const targetIPs = [
        // IPs comuns para impressoras
        `${network}.100`, `${network}.101`, `${network}.102`, `${network}.103`, `${network}.104`,
        `${network}.200`, `${network}.201`, `${network}.202`, `${network}.203`, `${network}.204`,
        `${network}.10`, `${network}.11`, `${network}.12`, `${network}.13`, `${network}.14`,
        `${network}.20`, `${network}.21`, `${network}.22`, `${network}.23`, `${network}.24`,
        `${network}.50`, `${network}.51`, `${network}.52`, `${network}.53`, `${network}.54`,
      ];

      const scanPromises = targetIPs.map(ip => this.scanIPForPrinters(ip, printerPorts));
      const results = await Promise.allSettled(scanPromises);
      
      results.forEach((result, index) => {
        if (result.status === 'fulfilled' && result.value) {
          const printer = result.value;
          const key = `${printer.ip}:${printer.port}`;
          
          if (!this.discoveredPrinters.has(key)) {
            printers.push(printer);
            this.discoveredPrinters.set(key, printer);
            console.log(`✅ Impressora encontrada: ${printer.name} (${printer.ip}:${printer.port})`);
          }
        }
      });
    }

    this.isScanning = false;
    console.log(`🖨️ Descoberta concluída: ${printers.length} impressora(s) encontrada(s)`);
    
    return printers;
  }

  // Escanear um IP específico em busca de impressoras
  private async scanIPForPrinters(ip: string, ports: number[]): Promise<any | null> {
    for (const port of ports) {
      try {
        const isOnline = await this.testPrinterConnection(ip, port);
        
        if (isOnline) {
          const printerInfo = await this.identifyPrinter(ip, port);
          
          return {
            id: `printer-${ip}-${port}`,
            name: printerInfo.name || `Impressora ${ip}:${port}`,
            ip: ip,
            port: port,
            type: printerInfo.type || this.getPrinterTypeByPort(port),
            protocol: this.getProtocolByPort(port),
            manufacturer: printerInfo.manufacturer || 'Desconhecido',
            model: printerInfo.model || 'Genérica',
            status: 'online',
            capabilities: printerInfo.capabilities || ['text', 'thermal'],
            lastSeen: new Date().toISOString(),
            discovered: true
          };
        }
      } catch (error) {
        // Continuar para próxima porta
        continue;
      }
    }
    
    return null;
  }

  // Testar conexão com impressora
  private async testPrinterConnection(ip: string, port: number): Promise<boolean> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);
      
      // Tentar diferentes endpoints comuns de impressoras
      const endpoints = ['/status', '/info', '/ping', '/'];
      
      for (const endpoint of endpoints) {
        try {
          await fetch(`http://${ip}:${port}${endpoint}`, {
            method: 'GET',
            mode: 'no-cors',
            signal: controller.signal,
          });
          
          clearTimeout(timeoutId);
          return true;
        } catch (error) {
          continue;
        }
      }
      
      clearTimeout(timeoutId);
      return false;
    } catch (error) {
      return false;
    }
  }

  // Identificar informações da impressora
  private async identifyPrinter(ip: string, port: number): Promise<any> {
    try {
      // Tentar obter informações via HTTP
      const response = await fetch(`http://${ip}:${port}/info`, {
        method: 'GET',
        mode: 'cors',
        headers: {
          'Accept': 'application/json, text/plain, */*'
        }
      });
      
      if (response.ok) {
        const info = await response.json();
        return {
          name: info.name || info.deviceName || `Impressora ${ip}`,
          type: info.type || 'Impressora de Rede',
          manufacturer: info.manufacturer || info.vendor,
          model: info.model || info.deviceModel,
          capabilities: info.capabilities || ['text', 'thermal']
        };
      }
    } catch (error) {
      // Fallback para informações básicas
    }
    
    return {
      name: `Impressora ${ip}:${port}`,
      type: this.getPrinterTypeByPort(port),
      manufacturer: 'Desconhecido',
      model: 'Genérica',
      capabilities: ['text', 'thermal']
    };
  }

  // Determinar tipo de impressora pela porta
  private getPrinterTypeByPort(port: number): string {
    switch (port) {
      case 9100:
        return 'Impressora Térmica (Raw)';
      case 631:
        return 'Impressora IPP';
      case 515:
        return 'Impressora LPR';
      case 80:
      case 8080:
        return 'Impressora Web';
      case 23:
        return 'Impressora Telnet';
      default:
        return 'Impressora de Rede';
    }
  }

  // Determinar protocolo pela porta
  private getProtocolByPort(port: number): string {
    switch (port) {
      case 9100:
        return 'RAW';
      case 631:
        return 'IPP';
      case 515:
        return 'LPR';
      case 80:
      case 8080:
        return 'HTTP';
      case 23:
        return 'TELNET';
      default:
        return 'TCP';
    }
  }

  // Obter impressoras descobertas
  getDiscoveredPrinters(): any[] {
    return Array.from(this.discoveredPrinters.values());
  }

  // Limpar cache de impressoras descobertas
  clearDiscoveredPrinters(): void {
    this.discoveredPrinters.clear();
  }

  // Salvar impressora selecionada
  savePrinterConfig(printer: any, type: 'kitchen' | 'waiter'): void {
    const config = {
      id: printer.id,
      name: printer.name,
      ip: printer.ip,
      port: printer.port,
      type: type,
      enabled: true,
      protocol: printer.protocol,
      manufacturer: printer.manufacturer,
      model: printer.model,
      discoveredAt: new Date().toISOString()
    };
    
    // Salvar no localStorage para persistência
    const savedPrinters = JSON.parse(localStorage.getItem('discoveredPrinters') || '[]');
    const existingIndex = savedPrinters.findIndex((p: any) => p.id === printer.id);
    
    if (existingIndex >= 0) {
      savedPrinters[existingIndex] = config;
    } else {
      savedPrinters.push(config);
    }
    
    localStorage.setItem('discoveredPrinters', JSON.stringify(savedPrinters));
    console.log(`💾 Configuração da impressora ${type} salva:`, config);
  }

  // Carregar impressoras salvas
  loadSavedPrinters(): any[] {
    try {
      const saved = localStorage.getItem('discoveredPrinters');
      return saved ? JSON.parse(saved) : [];
    } catch (error) {
      console.error('❌ Erro ao carregar impressoras salvas:', error);
      return [];
    }
  }

  // Testar impressora específica
  async testPrinter(ip: string, port: number, content: string): Promise<boolean> {
    try {
      const endpoints = ['/print', '/raw', '/thermal', '/pos', '/'];
      
      for (const endpoint of endpoints) {
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 5000);
          
          await fetch(`http://${ip}:${port}${endpoint}`, {
            method: 'POST',
            headers: {
              'Content-Type': 'text/plain',
            },
            body: content,
            mode: 'no-cors',
            signal: controller.signal,
          });
          
          clearTimeout(timeoutId);
          console.log(`✅ Teste de impressão enviado para ${ip}:${port}${endpoint}`);
          return true;
        } catch (error) {
          continue;
        }
      }
      
      return false;
    } catch (error) {
      console.error(`❌ Erro ao testar impressora ${ip}:${port}:`, error);
      return false;
    }
  }
}