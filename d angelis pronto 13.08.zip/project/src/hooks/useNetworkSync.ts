import { useEffect, useRef } from 'react';
import { useApp } from '../contexts/AppContext';
import { NetworkService } from '../services/NetworkService';

// Hook para sincronização automática entre módulos na rede
export function useNetworkSync() {
  const { state, dispatch } = useApp();
  const networkService = useRef(NetworkService.getInstance());
  const syncInterval = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    console.log('🌐 Iniciando sincronização de rede...');
    
    // Configurar listener para dados recebidos da rede
    const handleNetworkData = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return;
      
      const { type, data } = event.data;
      
      switch (type) {
        case 'network_sync_orders':
          console.log('📡 Recebendo pedidos sincronizados da rede');
          dispatch({ type: 'SET_ORDERS', payload: data });
          break;
          
        case 'network_sync_tables':
          console.log('📡 Recebendo mesas sincronizadas da rede');
          dispatch({ type: 'SET_TABLES', payload: data });
          break;
          
        case 'network_sync_config':
          console.log('📡 Recebendo configurações sincronizadas da rede');
          dispatch({ type: 'SET_CONFIG', payload: data });
          break;
          
        case 'kitchen_order_received':
          console.log('🍳 Pedido recebido na cozinha via rede');
          // Atualizar status do pedido para "enviado"
          if (data.orderId) {
            const order = state.orders.find(o => o.id === data.orderId);
            if (order) {
              const updatedOrder = { ...order, status: 'enviado' as const };
              dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
            }
          }
          break;
      }
    };

    window.addEventListener('message', handleNetworkData);
    
    // Sincronização periódica com outros módulos na rede
    const startPeriodicSync = () => {
      syncInterval.current = setInterval(async () => {
        try {
          // Descobrir outros módulos PDV na rede
          const devices = await networkService.current.discoverNetworkDevices();
          const pdvModules = devices.filter(d => d.type === 'Sistema PDV');
          
          if (pdvModules.length > 0) {
            console.log(`🔄 Sincronizando com ${pdvModules.length} módulo(s) PDV na rede`);
            
            // Enviar dados atuais para outros módulos
            await networkService.current.syncWithNetwork({
              type: 'full_sync',
              orders: state.orders,
              tables: state.tables,
              config: state.config,
              timestamp: new Date().toISOString(),
              source: 'auto_sync'
            });
          }
        } catch (error) {
          console.warn('⚠️ Erro na sincronização periódica:', error);
        }
      }, 30000); // Sincronizar a cada 30 segundos
    };

    // Iniciar sincronização após 5 segundos
    setTimeout(startPeriodicSync, 5000);
    
    return () => {
      window.removeEventListener('message', handleNetworkData);
      if (syncInterval.current) {
        clearInterval(syncInterval.current);
      }
      networkService.current.stopDeviceDiscovery();
    };
  }, [state.orders, state.tables, state.config, dispatch]);

  // Função para forçar sincronização manual
  const forcSync = async () => {
    console.log('🔄 Forçando sincronização manual...');
    try {
      await networkService.current.syncWithNetwork({
        type: 'manual_sync',
        orders: state.orders,
        tables: state.tables,
        config: state.config,
        timestamp: new Date().toISOString(),
        source: 'manual_sync'
      });
      console.log('✅ Sincronização manual concluída');
    } catch (error) {
      console.error('❌ Erro na sincronização manual:', error);
    }
  };

  // Função para descobrir impressoras na rede
  const discoverPrinters = async () => {
    return await networkService.current.discoverPrinters();
  };

  // Função para testar conectividade
  const testConnection = async (ip: string, port: number) => {
    return await networkService.current.testDeviceConnection(ip, port);
  };

  return {
    forcSync,
    discoverPrinters,
    testConnection,
    discoveredDevices: networkService.current.getDiscoveredDevices(),
    discoveredPrinters: networkService.current.getDiscoveredPrinters(),
  };
}