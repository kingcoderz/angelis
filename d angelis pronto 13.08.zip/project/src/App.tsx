import React from 'react';
import { AppProvider, useApp } from './contexts/AppContext';
import { LoginScreen } from './components/LoginScreen';
import { WaiterDashboard } from './components/waiter/WaiterDashboard';
import { AdminDashboard } from './components/admin/AdminDashboard';

function AppContent() {
  const { state } = useApp();

  console.log('🔍 App state:', { 
    hasUser: !!state.currentUser 
  });

  // Se não há usuário logado, mostrar tela de login
  if (!state.currentUser) {
    console.log('🔐 Mostrando tela de login');
    return <LoginScreen />;
  }

  // Usuário logado - mostrar dashboard apropriado
  console.log('✅ Usuário logado - mostrando dashboard');
  return (
    <>
      {state.currentUser.role === 'garcom' ? (
        <WaiterDashboard />
      ) : state.currentUser.role === 'admin' ? (
        <AdminDashboard />
      ) : (
        <LoginScreen />
      )}
    </>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;