import React, { useState } from 'react';
import { Users, Settings, User, Lock, Sparkles, Coffee } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { Button } from './ui/Button';
import { Input } from './ui/Input';
import { Card } from './ui/Card';
import { Modal } from './ui/Modal';

export function LoginScreen() {
  const { state, login } = useApp();
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginType, setLoginType] = useState<'garcom' | 'admin'>('garcom');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    if (login(username, password)) {
      setShowLoginModal(false);
      setUsername('');
      setPassword('');
      setError('');
    } else {
      setError('Usuário ou senha incorretos');
    }
  };

  const openLoginModal = (type: 'garcom' | 'admin') => {
    setLoginType(type);
    setShowLoginModal(true);
    setError('');
    // Pre-fill credentials for demo
    if (type === 'garcom') {
      setUsername('jose');
      setPassword('1234');
    } else {
      setUsername('admin');
      setPassword('1234');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-purple-600/20 rounded-full blur-3xl animate-float" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-emerald-400/20 to-blue-600/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-purple-400/10 to-pink-600/10 rounded-full blur-3xl animate-pulse" />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Modern header */}
        <div className="text-center mb-10">
          <div className="relative mb-6">
            <div className="w-24 h-24 bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-blue-500/25 transform rotate-3 hover:rotate-6 transition-transform duration-300">
              <Coffee className="w-12 h-12 text-white" />
            </div>
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
              <Sparkles className="w-3 h-3 text-white" />
            </div>
          </div>
          
          <h1 className="text-4xl font-black text-transparent bg-gradient-to-r from-slate-900 via-blue-900 to-indigo-900 bg-clip-text mb-3">
            {state.config.company.nomeFantasia || 'Sistema PDV'}
          </h1>
          <p className="text-slate-600 text-lg font-medium">Sistema de Pedidos Moderno</p>
          <div className="w-20 h-1 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mx-auto mt-4" />
        </div>

        {/* Modern login options */}
        <div className="space-y-4">
          <Card variant="modern" className="group hover:shadow-2xl transition-all duration-300" hover>
            <Button
              variant="gradient"
              size="xl"
              icon={Users}
              fullWidth
              onClick={() => openLoginModal('garcom')}
              className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 hover:from-blue-700 hover:via-purple-700 hover:to-indigo-800"
              rounded="2xl"
            >
              <span className="text-lg font-bold">Entrar como Garçom</span>
            </Button>
          </Card>

          <Card variant="modern" className="group hover:shadow-2xl transition-all duration-300" hover>
            <Button
              variant="gradient"
              size="xl"
              icon={Settings}
              fullWidth
              onClick={() => openLoginModal('admin')}
              className="bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 hover:from-emerald-700 hover:via-teal-700 hover:to-cyan-800"
              rounded="2xl"
            >
              <span className="text-lg font-bold">Entrar como Caixa/Admin</span>
            </Button>
          </Card>
        </div>

        {/* Modern footer */}
        <div className="mt-10 text-center">
          <div className="inline-flex items-center space-x-2 px-4 py-2 bg-white/60 backdrop-blur-xl rounded-full border border-white/20 shadow-lg">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <p className="text-sm text-slate-600 font-medium">
              Sistema PDV - Versão 2.0
            </p>
          </div>
        </div>
      </div>

      {/* Modern login modal */}
      <Modal
        isOpen={showLoginModal}
        onClose={() => setShowLoginModal(false)}
        title={`Login - ${loginType === 'garcom' ? 'Garçom' : 'Caixa/Admin'}`}
        variant="modern"
      >
        <div className="space-y-6">
          <div className="text-center">
            <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl flex items-center justify-center ${
              loginType === 'garcom' 
                ? 'bg-gradient-to-br from-blue-500 to-purple-600' 
                : 'bg-gradient-to-br from-emerald-500 to-teal-600'
            } shadow-xl`}>
              {loginType === 'garcom' ? (
                <Users className="w-8 h-8 text-white" />
              ) : (
                <Settings className="w-8 h-8 text-white" />
              )}
            </div>
            <p className="text-slate-600">
              {loginType === 'garcom' 
                ? 'Acesse o painel do garçom' 
                : 'Acesse o painel administrativo'
              }
            </p>
          </div>

          <Input
            label="Usuário"
            placeholder="Digite seu usuário"
            value={username}
            onChange={setUsername}
            icon={User}
            fullWidth
            required
            variant="modern"
          />

          <Input
            label="Senha"
            type="password"
            placeholder="Digite sua senha"
            value={password}
            onChange={setPassword}
            icon={Lock}
            fullWidth
            required
            variant="modern"
          />

          {error && (
            <Card variant="bordered" className="bg-red-50 border-red-200">
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-red-500 rounded-full" />
                <p className="text-sm text-red-600 font-medium">{error}</p>
              </div>
            </Card>
          )}

          <div className="flex space-x-4">
            <Button
              variant="outline"
              fullWidth
              onClick={() => setShowLoginModal(false)}
              rounded="xl"
            >
              Cancelar
            </Button>
            <Button
              variant="primary"
              fullWidth
              onClick={handleLogin}
              rounded="xl"
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              Entrar
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}