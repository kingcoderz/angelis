import React, { useState } from 'react';
import { Users, Clock, User, Edit, Trash2, Plus, Save, X } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Modal } from '../ui/Modal';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { StatusBadge } from '../ui/StatusBadge';
import { Order, OrderItem } from '../../types';

interface OrderDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onAddItems: () => void;
}

export function OrderDetailsModal({ isOpen, onClose, order, onAddItems }: OrderDetailsModalProps) {
  const { removeItemFromOrder, updateOrderItem, state } = useApp();
  const [editingItem, setEditingItem] = useState<OrderItem | null>(null);
  const [editNotes, setEditNotes] = useState('');
  const [editQuantity, setEditQuantity] = useState('1');

  if (!order) return null;

  const handleRemoveItem = (itemId: string) => {
    // Verificar se é garçom e se o pedido é dele
    if (state.currentUser?.role === 'garcom' && order.waiterName !== state.currentUser.name) {
      alert('Você só pode remover itens de seus próprios pedidos!');
      return;
    }
    
    if (order.status !== 'aberto') {
      alert('Apenas itens de pedidos em aberto podem ser removidos!');
      return;
    }
    
    if (confirm('⚠️ Tem certeza que deseja remover este item?\n\nEsta ação não pode ser desfeita.')) {
      removeItemFromOrder(order.id, itemId);
    }
  };

  const handleEditItem = (item: OrderItem) => {
    // Verificar se é garçom e se o pedido é dele
    if (state.currentUser?.role === 'garcom' && order.waiterName !== state.currentUser.name) {
      alert('Você só pode editar itens de seus próprios pedidos!');
      return;
    }
    
    if (order.status !== 'aberto') {
      alert('Apenas itens de pedidos em aberto podem ser editados!');
      return;
    }
    
    setEditingItem(item);
    setEditNotes(item.notes || '');
    setEditQuantity(item.quantity.toString());
  };

  const handleSaveEdit = () => {
    if (editingItem && editQuantity) {
      const quantity = parseInt(editQuantity);
      if (quantity < 1) {
        alert('Quantidade deve ser maior que zero!');
        return;
      }
      
      const updatedItem = {
        ...editingItem,
        quantity,
        notes: editNotes.trim() || undefined,
      };
      updateOrderItem(order.id, updatedItem);
      setEditingItem(null);
      setEditNotes('');
      setEditQuantity('1');
    }
  };

  const canEditOrder = (state.currentUser?.role === 'admin') || 
                      (state.currentUser?.role === 'garcom' && order.waiterName === state.currentUser.name);
  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title={`Mesa ${order.tableNumber} - Detalhes`}
        size="lg"
        variant="modern"
      >
        <div className="space-y-6">
          {/* Header Info */}
          <Card variant="modern" className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-lg font-semibold text-blue-900 flex items-center">
                  <Users className="w-5 h-5 mr-2" />
                  {order.customers.map(c => c.name).join(', ')}
                </h3>
                <p className="text-sm text-blue-700 flex items-center mt-1">
                  <User className="w-4 h-4 mr-1" />
                  Garçom: {order.waiterName}
                </p>
                <p className="text-sm text-blue-700 flex items-center mt-1">
                  <Clock className="w-4 h-4 mr-1" />
                  Criado: {new Date(order.createdAt).toLocaleString('pt-BR')}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <StatusBadge status={order.status} />
                {order.status === 'aberto' && canEditOrder && (
                  <Button
                    variant="primary"
                    size="sm"
                    icon={Plus}
                    onClick={onAddItems}
                    rounded="xl"
                  >
                    Adicionar
                  </Button>
                )}
              </div>
            </div>
          </Card>

          {/* Permissions Info */}
          {!canEditOrder && (
            <Card variant="modern" className="bg-yellow-50 border-yellow-200">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">⚠️</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-yellow-900">
                    Visualização apenas
                  </p>
                  <p className="text-xs text-yellow-700">
                    Você só pode editar pedidos que criou ou ser administrador
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* Items List */}
          <Card variant="modern">
            <h4 className="font-medium text-gray-900 mb-4">Itens do Pedido</h4>
            <div className="space-y-3">
              {order.items.map((item, index) => (
                <div key={item.id} className="flex justify-between items-start py-3 border-b border-gray-100 last:border-b-0">
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-gray-900">
                        {item.quantity}x {item.productName}
                      </p>
                      <div className="flex space-x-1">
                        {order.status === 'aberto' && canEditOrder && (
                          <>
                            <Button
                              variant="outline"
                              size="sm"
                              icon={Edit}
                              onClick={() => handleEditItem(item)}
                              rounded="xl"
                            />
                            <Button
                              variant="danger"
                              size="sm"
                              icon={Trash2}
                              onClick={() => handleRemoveItem(item.id)}
                              rounded="xl"
                            />
                          </>
                        )}
                      </div>
                    </div>
                    
                    {item.customerName && (
                      <p className="text-sm text-gray-500">
                        Cliente: {item.customerName}
                      </p>
                    )}
                    {item.notes && (
                      <p className="text-sm text-blue-600 bg-blue-50 px-2 py-1 rounded mt-1">
                        Obs: {item.notes}
                      </p>
                    )}
                  </div>
                  <div className="text-right ml-4">
                    <p className="font-medium text-gray-900">
                      R$ {(item.price * item.quantity).toFixed(2)}
                    </p>
                    <p className="text-sm text-gray-500">
                      R$ {item.price.toFixed(2)} cada
                    </p>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="pt-4 border-t border-gray-200 mt-4">
              <div className="flex justify-between items-center">
                <p className="text-lg font-semibold text-gray-900">Total</p>
                <p className="text-2xl font-bold text-green-600">
                  R$ {order.total.toFixed(2)}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </Modal>

      {/* Edit Item Modal */}
      {editingItem && (
        <Modal
          isOpen={!!editingItem}
          onClose={() => {
            setEditingItem(null);
            setEditNotes('');
            setEditQuantity('1');
          }}
          title="Editar Item"
          size="md"
          variant="modern"
        >
          <div className="space-y-6">
            <Card variant="modern" className="bg-blue-50 border-blue-200">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-500 rounded-2xl flex items-center justify-center">
                  <Edit className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="font-medium text-blue-900 mb-1">
                    {editingItem.productName}
                  </h4>
                  <p className="text-sm text-blue-700">
                    Cliente: {editingItem.customerName} • R$ {editingItem.price.toFixed(2)} cada
                  </p>
                </div>
              </div>
            </Card>

            <Input
              label="Quantidade"
              type="number"
              min="1"
              value={editQuantity}
              onChange={setEditQuantity}
              fullWidth
              variant="modern"
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Observações
              </label>
              <textarea
                value={editNotes}
                onChange={(e) => setEditNotes(e.target.value)}
                placeholder="Digite observações para este item..."
                rows={3}
                className="block w-full rounded-xl border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-all duration-200"
              />
            </div>

            <Card variant="modern" className="bg-green-50 border-green-200">
              <div className="flex justify-between items-center">
                <span className="text-green-700 font-medium">Total do item:</span>
                <span className="text-xl font-bold text-green-900">
                  R$ {(editingItem.price * parseInt(editQuantity || '1')).toFixed(2)}
                </span>
              </div>
            </Card>

            <div className="flex space-x-3 pt-4">
              <Button
                variant="outline"
                fullWidth
                onClick={() => {
                  setEditingItem(null);
                  setEditNotes('');
                  setEditQuantity('1');
                }}
                rounded="xl"
              >
                Cancelar
              </Button>
              <Button
                variant="success"
                fullWidth
                onClick={handleSaveEdit}
                icon={Save}
                rounded="xl"
                className="bg-gradient-to-r from-green-600 to-emerald-600"
              >
                Salvar Alterações
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </>
  );
}