import React, { useState, useEffect } from 'react';
import { useApp } from '../../contexts/AppContext';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Plus, Minus, ShoppingCart, User, Search, Package, CheckCircle, MessageSquare } from 'lucide-react';
import { OrderItem, Table, Customer } from '../../types';

interface AddItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  table: Table | null;
  selectedCustomer: Customer | null;
  onCustomerChange?: (customer: Customer) => void;
}

export function AddItemModal({ isOpen, onClose, table, selectedCustomer, onCustomerChange }: AddItemModalProps) {
  const { state, addItemToOrder } = useApp();
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [isAdding, setIsAdding] = useState(false);
  const [addedItems, setAddedItems] = useState<string[]>([]);
  const [expandedNotes, setExpandedNotes] = useState<Record<string, boolean>>({});
  const [currentCustomer, setCurrentCustomer] = useState<Customer | null>(selectedCustomer);

  // Reset form when modal opens/closes
  useEffect(() => {
    if (isOpen) {
      setQuantities({});
      setNotes({});
      setSearchTerm('');
      setSelectedCategory('');
      setAddedItems([]);
      setExpandedNotes({});
      setCurrentCustomer(selectedCustomer);
    }
  }, [isOpen]);

  // Update current customer when selectedCustomer changes
  useEffect(() => {
    if (selectedCustomer) {
      setCurrentCustomer(selectedCustomer);
    }
  }, [selectedCustomer]);

  const categories = [...new Set(state.products.map(p => p.category))];
  
  const filteredProducts = state.products.filter(product => {
    if (!product.available) return false;
    
    const matchesCategory = !selectedCategory || product.category === selectedCategory;
    const matchesSearch = !searchTerm || 
      product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    return matchesCategory && matchesSearch;
  });

  const handleQuantityChange = (productId: string, change: number) => {
    const currentQty = quantities[productId] || 0;
    const newQty = Math.max(0, currentQty + change);
    
    if (newQty === 0) {
      const newQuantities = { ...quantities };
      delete newQuantities[productId];
      setQuantities(newQuantities);
      
      const newNotes = { ...notes };
      delete newNotes[productId];
      setNotes(newNotes);
      
      const newExpanded = { ...expandedNotes };
      delete newExpanded[productId];
      setExpandedNotes(newExpanded);
    } else {
      setQuantities({ ...quantities, [productId]: newQty });
    }
  };

  const handleNotesChange = (productId: string, noteText: string) => {
    setNotes({ ...notes, [productId]: noteText });
  };

  const toggleNotesExpanded = (productId: string) => {
    setExpandedNotes({
      ...expandedNotes,
      [productId]: !expandedNotes[productId]
    });
  };

  const handleCustomerChange = (customer: Customer) => {
    console.log('🔄 [MODAL] Alterando cliente selecionado:', customer.name);
    setCurrentCustomer(customer);
    
    // Limpar seleções atuais para evitar confusão
    setQuantities({});
    setNotes({});
    setExpandedNotes({});
    setAddedItems([]);
    
    // Notificar componente pai se callback disponível
    if (onCustomerChange) {
      onCustomerChange(customer);
    }
  };

  const handleAddItems = async () => {
    if (!table?.orderId || !currentCustomer) {
      console.error('Mesa ou cliente não encontrado:', { table, currentCustomer });
      alert('❌ Erro: Mesa ou cliente não encontrado');
      return;
    }

    const itemsToAdd = Object.entries(quantities).filter(([_, qty]) => qty > 0);
    
    if (itemsToAdd.length === 0) {
      alert('⚠️ Selecione pelo menos um item para adicionar');
      return;
    }

    setIsAdding(true);
    console.log('🛒 [MODAL] Iniciando adição de itens...', {
      orderId: table.orderId,
      cliente: currentCustomer.name,
      itensParaAdicionar: itemsToAdd.length,
      quantidades: quantities
    });

    try {
      let totalItemsAdded = 0;
      const addedProductNames: string[] = [];

      // Processar cada produto selecionado SEQUENCIALMENTE
      for (const [productId, quantity] of itemsToAdd) {
        const product = state.products.find(p => p.id === productId);
        
        if (!product) {
          console.warn(`Produto não encontrado: ${productId}`);
          continue;
        }

        console.log(`📦 [MODAL] Processando ${quantity}x ${product.name} para ${currentCustomer.name}`);

        // IMPORTANTE: Criar itens individuais para cada quantidade
        // Isso garante que cada item tenha seu próprio ID único
        for (let i = 0; i < quantity; i++) {
          // Gerar ID único com timestamp + random + índice para garantir unicidade
          const uniqueId = `item-${Date.now()}-${Math.random().toString(36).substr(2, 12)}-${productId}-${i}-${totalItemsAdded}`;
          
          const item: OrderItem = {
            id: uniqueId,
            productId,
            productName: product.name,
            price: product.price,
            quantity: 1, // Sempre 1 para permitir controle individual
            customerName: currentCustomer.name,
            notes: notes[productId]?.trim() || undefined,
            status: 'pendente',
          };

          console.log(`➕ [MODAL] Adicionando item ${i + 1}/${quantity}:`, {
            id: item.id,
            produto: item.productName,
            cliente: item.customerName,
            preco: item.price
          });
          
          // Adicionar item ao pedido - AGUARDAR CADA ADIÇÃO
          try {
            addItemToOrder(table.orderId!, item);
            totalItemsAdded++;
            
            // Delay entre adições para garantir processamento sequencial
            await new Promise(resolve => setTimeout(resolve, 150));
            
            console.log(`✅ [MODAL] Item ${i + 1}/${quantity} adicionado com sucesso`);
          } catch (error) {
            console.error(`❌ [MODAL] Erro ao adicionar item ${i + 1}/${quantity}:`, error);
          }
        }

        addedProductNames.push(`${quantity}x ${product.name}`);
        setAddedItems(prev => [...prev, productId]);
        
        // Delay entre produtos diferentes
        await new Promise(resolve => setTimeout(resolve, 200));
      }

      console.log(`✅ [MODAL] TOTAL de itens adicionados: ${totalItemsAdded}`);
      
      // Feedback de sucesso
      if (totalItemsAdded > 0) {
        alert(`✅ ${totalItemsAdded} item(s) adicionado(s) com sucesso!\n\n${addedProductNames.join('\n')}\n\n🍳 Itens enviados automaticamente para a cozinha!`);
        
        // ✅ CORREÇÃO: Reset apenas as quantidades e notas, mas NÃO fechar o modal
        setQuantities({});
        setNotes({});
        setExpandedNotes({});
        setAddedItems([]);
        
        // ✅ IMPORTANTE: NÃO chamar onClose() aqui - deixar o usuário decidir quando sair
        console.log('✅ [MODAL] Itens adicionados, modal permanece aberto para mais pedidos');
      } else {
        alert('⚠️ Nenhum item foi adicionado. Tente novamente.');
      }

    } catch (error) {
      console.error('❌ [MODAL] Erro geral ao adicionar itens:', error);
      alert('❌ Erro ao adicionar itens. Tente novamente.');
    } finally {
      setIsAdding(false);
    }
  };

  const totalItems = Object.values(quantities).reduce((sum, qty) => sum + qty, 0);
  const totalValue = Object.entries(quantities).reduce((sum, [productId, qty]) => {
    const product = state.products.find(p => p.id === productId);
    return sum + (product ? product.price * qty : 0);
  }, 0);

  if (!table || !currentCustomer) {
    return (
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title="Adicionar Itens"
        variant="modern"
      >
        <div className="text-center py-12">
          <div className="w-20 h-20 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center mx-auto mb-6">
            <Package className="w-10 h-10 text-slate-400" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-3">
            Erro ao carregar
          </h3>
          <p className="text-slate-600 mb-6">
            Erro ao carregar dados da mesa ou cliente.
          </p>
          <Button variant="outline" onClick={onClose} rounded="xl">
            Fechar
          </Button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Adicionar Itens - Mesa ${table.number}`}
      size="xl"
      variant="modern"
    >
      <div className="space-y-6">
        {/* Customer Selector and Info */}
        <Card variant="modern" className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
              <User className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1 space-y-3">
              <div>
                <label className="block text-sm font-bold text-blue-900 mb-2 uppercase tracking-wide">
                  🎯 Pedido para qual cliente?
                </label>
                <select
                  value={currentCustomer?.id || ''}
                  onChange={(e) => {
                    const customer = table.customers.find(c => c.id === e.target.value);
                    if (customer) {
                      handleCustomerChange(customer);
                    }
                  }}
                  className="block w-full rounded-xl border-blue-200 bg-white/80 focus:border-blue-500 focus:ring-blue-500 transition-all duration-200 px-4 py-3 text-sm font-bold text-blue-900 shadow-lg"
                  disabled={isAdding}
                >
                  {table.customers.map(customer => (
                    <option key={customer.id} value={customer.id}>
                      👤 {customer.name} ({customer.items.length} item(s) • R$ {customer.totalAmount.toFixed(2)})
                    </option>
                  ))}
                </select>
              </div>
              
              {currentCustomer && (
                <div className="bg-blue-100/50 rounded-xl p-3">
                  <h4 className="text-lg font-bold text-blue-900">
                    📝 Adicionando para: {currentCustomer.name}
                  </h4>
                  <p className="text-sm text-blue-700">
                    {currentCustomer.items.length} item(s) atual • R$ {currentCustomer.totalAmount.toFixed(2)}
                  </p>
                </div>
              )}
            </div>
            {totalItems > 0 && (
              <div className="text-right">
                <p className="text-sm font-bold text-blue-900">
                  Adicionando: {totalItems} item(s)
                </p>
                <p className="text-lg font-black text-blue-900">
                  + R$ {totalValue.toFixed(2)}
                </p>
              </div>
            )}
          </div>
        </Card>

        {/* Progress indicator */}
        {isAdding && (
          <Card variant="modern" className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                <CheckCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-bold text-green-900">Adicionando itens ao pedido...</p>
                <p className="text-sm text-green-700">Aguarde, processando {totalItems} item(s) sequencialmente</p>
              </div>
            </div>
          </Card>
        )}

        {/* ✅ AVISO IMPORTANTE SOBRE O MODAL */}
        <Card variant="modern" className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
              <span className="text-white font-bold text-sm">✅</span>
            </div>
            <div>
              <p className="text-sm font-bold text-green-900">
                🚀 Fluxo Otimizado para Garçons
              </p>
              <p className="text-xs text-green-700">
                • Alterne entre clientes usando o seletor acima<br/>
                • Adicione itens para diferentes clientes sem fechar o modal<br/>
                • Itens ficam "pendentes" até enviar para cozinha
              </p>
            </div>
          </div>
        </Card>

        {/* Search and Category Filter */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            placeholder="Buscar produtos..."
            value={searchTerm}
            onChange={setSearchTerm}
            icon={Search}
            fullWidth
            variant="modern"
            disabled={isAdding}
          />
          
          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              disabled={isAdding}
              className="block w-full rounded-xl border-slate-200 bg-slate-50/50 focus:border-blue-500 focus:ring-blue-500 focus:bg-white transition-all duration-200 px-4 py-3 text-sm font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <option value="">Todas as categorias</option>
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Category Buttons */}
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedCategory === '' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setSelectedCategory('')}
            rounded="full"
            disabled={isAdding}
          >
            Todas
          </Button>
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? 'primary' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              rounded="full"
              disabled={isAdding}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="max-h-96 overflow-y-auto">
          {filteredProducts.length === 0 ? (
            <Card variant="modern" className="text-center py-12">
              <Package className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                Nenhum produto encontrado
              </h3>
              <p className="text-slate-600">
                Tente ajustar os filtros de busca.
              </p>
            </Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {filteredProducts.map((product) => {
                const quantity = quantities[product.id] || 0;
                const isAdded = addedItems.includes(product.id);
                const hasNotes = notes[product.id]?.trim();
                const isNotesExpanded = expandedNotes[product.id];
                
                return (
                  <Card 
                    key={product.id} 
                    variant="modern" 
                    className={`p-4 group transition-all duration-300 ${
                      quantity > 0 ? 'ring-2 ring-blue-500 bg-blue-50' : 'hover:shadow-xl'
                    } ${isAdded ? 'ring-2 ring-green-500 bg-green-50' : ''}`}
                    hover={!isAdding}
                    animated
                  >
                    <div className="flex justify-between items-start mb-3">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <h4 className={`font-bold transition-colors duration-300 ${
                            quantity > 0 ? 'text-blue-700' : 'text-slate-900 group-hover:text-blue-600'
                          }`}>
                            {product.name}
                          </h4>
                          {isAdded && (
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          )}
                          {hasNotes && (
                            <MessageSquare className="w-4 h-4 text-orange-500" />
                          )}
                        </div>
                        <p className="text-sm text-slate-500 font-medium">{product.category}</p>
                        {product.description && (
                          <p className="text-xs text-slate-400 mt-1 line-clamp-2">{product.description}</p>
                        )}
                        <p className="text-xl font-black text-green-600 mt-2">
                          R$ {product.price.toFixed(2)}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Button
                          variant="outline"
                          size="sm"
                          icon={Minus}
                          onClick={() => handleQuantityChange(product.id, -1)}
                          disabled={!quantity || isAdding}
                          rounded="full"
                        />
                        <span className={`w-12 text-center font-black text-lg ${
                          quantity > 0 ? 'text-blue-600' : 'text-slate-600'
                        }`}>
                          {quantity}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          icon={Plus}
                          onClick={() => handleQuantityChange(product.id, 1)}
                          disabled={isAdding}
                          rounded="full"
                        />
                      </div>
                      
                      {quantity > 0 && (
                        <div className="text-right">
                          <p className="text-sm font-bold text-slate-900">
                            R$ {(product.price * quantity).toFixed(2)}
                          </p>
                          <p className="text-xs text-blue-600 font-bold">
                            {quantity} item(s)
                          </p>
                        </div>
                      )}
                    </div>

                    {quantity > 0 && (
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wide">
                            Observações para {quantity} item(s):
                          </label>
                          <Button
                            variant="ghost"
                            size="sm"
                            icon={MessageSquare}
                            onClick={() => toggleNotesExpanded(product.id)}
                            className="text-xs"
                          >
                            {isNotesExpanded ? 'Recolher' : 'Expandir'}
                          </Button>
                        </div>
                        
                        <textarea
                          placeholder="Ex: sem cebola, bem passado, molho à parte..."
                          className={`w-full text-sm border border-slate-200 rounded-xl px-3 py-2 resize-none focus:border-blue-500 focus:ring-blue-500 bg-slate-50/50 focus:bg-white transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed ${
                            isNotesExpanded ? 'h-24' : 'h-16'
                          }`}
                          value={notes[product.id] || ''}
                          onChange={(e) => handleNotesChange(product.id, e.target.value)}
                          disabled={isAdding}
                        />
                        
                        {hasNotes && (
                          <div className="text-xs text-orange-600 bg-orange-50 px-2 py-1 rounded-lg">
                            💬 Observação adicionada
                          </div>
                        )}
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </div>

        {/* Summary */}
        {totalItems > 0 && (
          <Card variant="modern" className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <div className="flex justify-between items-center">
              <div>
                <p className="text-lg font-bold text-green-900">
                  Resumo do Pedido
                </p>
                <p className="text-sm text-green-700">
                  {Object.entries(quantities).filter(([_, qty]) => qty > 0).map(([productId, qty]) => {
                    const product = state.products.find(p => p.id === productId);
                    const hasNotes = notes[productId]?.trim();
                    return product ? `${qty}x ${product.name}${hasNotes ? ' 💬' : ''} → ${currentCustomer?.name}` : '';
                  }).filter(Boolean).join(', ')}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm text-green-700">Total de itens:</p>
                <p className="text-2xl font-black text-green-900">{totalItems}</p>
              </div>
            </div>
          </Card>
        )}

        {/* Footer */}
        <div className="flex justify-between items-center pt-6 border-t border-slate-200">
          <div className="text-left">
            <p className="text-sm text-slate-600">
              Total de itens: <span className="font-bold text-lg">{totalItems}</span>
            </p>
            {totalValue > 0 && (
              <p className="text-xl font-black text-green-600">
                Valor total: R$ {totalValue.toFixed(2)}
              </p>
            )}
            {Object.values(notes).filter(note => note?.trim()).length > 0 && (
              <p className="text-xs text-orange-600 mt-1">
                💬 {Object.values(notes).filter(note => note?.trim()).length} item(s) com observações
              </p>
            )}
          </div>
          
          <div className="flex space-x-4">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isAdding}
              rounded="xl"
            >
              {isAdding ? 'Processando...' : 'Fechar'}
            </Button>
            <Button
              variant="success"
              icon={isAdding ? CheckCircle : ShoppingCart}
              onClick={handleAddItems}
              disabled={totalItems === 0 || isAdding}
              loading={isAdding}
              rounded="xl"
              className="bg-gradient-to-r from-emerald-600 to-green-600"
            >
              {isAdding ? `Adicionando ${totalItems} item(s)...` : `Adicionar ${totalItems} Item(s)`}
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
}