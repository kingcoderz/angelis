import React, { useState } from 'react';
import { Users, Plus, ShoppingCart, User } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Customer, Table } from '../../types';

interface CustomerSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  table: Table | null;
  onCustomerSelected: (customer: Customer) => void;
}

export function CustomerSelectionModal({ 
  isOpen, 
  onClose, 
  table, 
  onCustomerSelected 
}: CustomerSelectionModalProps) {
  const [isSelecting, setIsSelecting] = useState(false);

  const handleCustomerSelect = async (customer: Customer) => {
    console.log('Cliente selecionado:', customer);
    setIsSelecting(true);
    
    try {
      // Fechar este modal primeiro
      onClose();
      
      // Aguardar um pouco para garantir que o modal foi fechado
      await new Promise(resolve => setTimeout(resolve, 200));
      
      // Chamar callback para abrir o modal de adicionar itens
      onCustomerSelected(customer);
    } catch (error) {
      console.error('Erro ao selecionar cliente:', error);
    } finally {
      setIsSelecting(false);
    }
  };

  if (!table || table.customers.length === 0) {
    return (
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title="Selecionar Cliente"
        variant="modern"
      >
        <div className="text-center py-12">
          <div className="w-20 h-20 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center mx-auto mb-6">
            <Users className="w-10 h-10 text-slate-400" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-3">
            Nenhum cliente encontrado
          </h3>
          <p className="text-slate-600 mb-6">
            Não há clientes cadastrados nesta mesa.
          </p>
          <Button variant="outline" onClick={onClose} rounded="xl">
            Fechar
          </Button>
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Selecionar Cliente - Mesa ${table.number}`}
      size="md"
      variant="modern"
    >
      <div className="space-y-6">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
            <ShoppingCart className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">
            Para quem é este pedido?
          </h3>
          <p className="text-slate-600">
            Selecione o cliente que está fazendo o pedido
          </p>
        </div>

        <div className="grid gap-4">
          {table.customers.map((customer) => (
            <Card 
              key={customer.id} 
              variant="modern"
              className="group border-2 border-transparent hover:border-blue-200"
              hover
              animated
            >
              <button
                onClick={() => handleCustomerSelect(customer)}
                disabled={isSelecting}
                className="w-full p-5 text-left hover:bg-blue-50/50 transition-all duration-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300">
                      <span className="text-white font-black text-xl">
                        {customer.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    
                    <div>
                      <h4 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition-colors duration-300">
                        {customer.name}
                      </h4>
                      <p className="text-sm text-slate-600">
                        {customer.items.length} item(s) • R$ {customer.totalAmount.toFixed(2)}
                      </p>
                      <div className={`
                        inline-flex items-center px-2 py-1 rounded-full text-xs font-bold mt-1
                        ${customer.status === 'ativo' ? 'bg-green-100 text-green-800' :
                          customer.status === 'pago' ? 'bg-blue-100 text-blue-800' :
                          'bg-slate-100 text-slate-800'}
                      `}>
                        {customer.status === 'ativo' ? '🟢 Ativo' :
                         customer.status === 'pago' ? '🔵 Pago' : '⚪ Saiu'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3">
                    <div className="text-right">
                      <p className="text-sm text-slate-500">Clique para</p>
                      <p className="text-sm font-bold text-blue-600">
                        {isSelecting ? 'Selecionando...' : 'Adicionar Itens'}
                      </p>
                    </div>
                    <Plus className="w-6 h-6 text-blue-500 group-hover:scale-110 transition-transform duration-300" />
                  </div>
                </div>

                {customer.items.length > 0 && (
                  <div className="mt-4 pt-4 border-t border-slate-200">
                    <p className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wide">
                      Últimos itens:
                    </p>
                    <div className="space-y-1">
                      {customer.items.slice(-3).map((item, index) => (
                        <div key={index} className="flex justify-between text-xs">
                          <span className="text-slate-600">
                            {item.quantity}x {item.productName}
                          </span>
                          <span className="font-bold text-slate-900">
                            R$ {(item.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                      ))}
                      {customer.items.length > 3 && (
                        <p className="text-xs text-slate-500 italic">
                          +{customer.items.length - 3} item(s) a mais...
                        </p>
                      )}
                    </div>
                  </div>
                )}
              </button>
            </Card>
          ))}
        </div>

        <div className="pt-6 border-t border-slate-200">
          <Button
            variant="outline"
            fullWidth
            onClick={onClose}
            rounded="xl"
            disabled={isSelecting}
          >
            {isSelecting ? 'Aguarde...' : 'Cancelar'}
          </Button>
        </div>
      </div>
    </Modal>
  );
}