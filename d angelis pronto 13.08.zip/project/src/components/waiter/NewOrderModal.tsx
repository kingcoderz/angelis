import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { Modal } from '../ui/Modal';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Plus, Minus } from 'lucide-react';

interface NewOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function NewOrderModal({ isOpen, onClose }: NewOrderModalProps) {
  const { state, createOrder } = useApp();
  const [tableNumber, setTableNumber] = useState('');
  const [customers, setCustomers] = useState(['']);

  const handleAddCustomer = () => {
    setCustomers([...customers, '']);
  };

  const handleRemoveCustomer = (index: number) => {
    if (customers.length > 1) {
      setCustomers(customers.filter((_, i) => i !== index));
    }
  };

  const handleCustomerChange = (index: number, value: string) => {
    const newCustomers = [...customers];
    newCustomers[index] = value;
    setCustomers(newCustomers);
  };

  const handleSubmit = () => {
    if (tableNumber && customers.some(c => c.trim())) {
      const validCustomers = customers.filter(c => c.trim());
      createOrder(tableNumber, validCustomers, state.currentUser?.name || '');
      setTableNumber('');
      setCustomers(['']);
      onClose();
    }
  };

  const resetForm = () => {
    setTableNumber('');
    setCustomers(['']);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        resetForm();
        onClose();
      }}
      title="Novo Pedido"
    >
      <div className="space-y-4">
        <Input
          label="Número da Mesa/Comanda"
          placeholder="Ex: 1, 2, 3..."
          value={tableNumber}
          onChange={setTableNumber}
          fullWidth
          required
        />

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Clientes <span className="text-red-500">*</span>
          </label>
          
          {customers.map((customer, index) => (
            <div key={index} className="flex space-x-2 mb-2">
              <Input
                placeholder={`Nome do cliente ${index + 1}`}
                value={customer}
                onChange={(value) => handleCustomerChange(index, value)}
                fullWidth
              />
              
              {customers.length > 1 && (
                <Button
                  variant="outline"
                  size="sm"
                  icon={Minus}
                  onClick={() => handleRemoveCustomer(index)}
                />
              )}
            </div>
          ))}
          
          <Button
            variant="outline"
            size="sm"
            icon={Plus}
            onClick={handleAddCustomer}
          >
            Adicionar Cliente
          </Button>
        </div>

        <div className="flex space-x-3 pt-4">
          <Button
            variant="outline"
            fullWidth
            onClick={() => {
              resetForm();
              onClose();
            }}
          >
            Cancelar
          </Button>
          <Button
            variant="primary"
            fullWidth
            onClick={handleSubmit}
            disabled={!tableNumber || !customers.some(c => c.trim())}
          >
            Criar Pedido
          </Button>
        </div>
      </div>
    </Modal>
  );
}