import React, { useState } from 'react';
import { Users, Plus, Minus, Edit, Trash2, ShoppingCart, Receipt, CreditCard } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Card } from '../ui/Card';
import { Table, Customer } from '../../types';
import { IndividualPaymentModal } from '../admin/IndividualPaymentModal';

interface TableManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  table: Table | null;
  onAddItems: () => void;
  onCreateOrder: (tableId: string, customerNames: string[]) => string;
}

export function TableManagementModal({ 
  isOpen, 
  onClose, 
  table, 
  onAddItems, 
  onCreateOrder 
}: TableManagementModalProps) {
  const { state, updateTable, addCustomerToTable, removeCustomerFromTable, printPreview } = useApp();
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [newCustomerName, setNewCustomerName] = useState('');
  const [showCreateOrder, setShowCreateOrder] = useState(false);
  const [customerNames, setCustomerNames] = useState(['']);
  const [showIndividualPayment, setShowIndividualPayment] = useState(false);
  const [selectedCustomerForPayment, setSelectedCustomerForPayment] = useState<Customer | null>(null);

  if (!table) return null;

  const handleAddCustomer = () => {
    if (newCustomerName.trim()) {
      addCustomerToTable(table.id, newCustomerName.trim());
      setNewCustomerName('');
      setShowAddCustomer(false);
    }
  };

  const handleRemoveCustomer = (customerId: string) => {
    const customer = table.customers.find(c => c.id === customerId);
    if (!customer) return;
    
    // ✅ VALIDAÇÃO: Impedir remoção se cliente tem consumo pendente
    const amountPending = customer.totalAmount - customer.paidAmount;
    if (amountPending > 0) {
      alert(`❌ Não é possível remover ${customer.name}!\n\nMotivo: Cliente possui consumo pendente de R$ ${amountPending.toFixed(2)}\n\n💡 Para remover o cliente:\n1. Processe o pagamento individual primeiro\n2. Ou remova todos os itens do cliente\n3. Depois poderá remover o cliente da mesa`);
      return;
    }
    
    if (confirm(`Tem certeza que deseja remover ${customer.name} da mesa?\n\nCliente não possui consumo pendente.`)) {
      removeCustomerFromTable(table.id, customerId);
    }
  };

  const handleCreateOrderClick = () => {
    if (table.status === 'livre') {
      setShowCreateOrder(true);
    } else {
      onAddItems();
    }
  };

  const handleCreateNewOrder = () => {
    const validCustomers = customerNames.filter(name => name.trim());
    if (validCustomers.length > 0) {
      const orderId = onCreateOrder(table.id, validCustomers);
      if (orderId) {
        setShowCreateOrder(false);
        setCustomerNames(['']);
        // Fechar modal atual e abrir modal de adicionar itens
        setTimeout(() => {
          onAddItems();
        }, 100);
      }
    }
  };

  const handleAddCustomerName = () => {
    setCustomerNames([...customerNames, '']);
  };

  const handleRemoveCustomerName = (index: number) => {
    if (customerNames.length > 1) {
      setCustomerNames(customerNames.filter((_, i) => i !== index));
    }
  };

  const handleCustomerNameChange = (index: number, value: string) => {
    const newNames = [...customerNames];
    newNames[index] = value;
    setCustomerNames(newNames);
  };

  const handlePrintPreview = () => {
    if (table.orderId) {
      const order = state.orders.find(o => o.id === table.orderId);
      if (order) {
        console.log('🖨️ Imprimindo prévia da comanda via impressora do garçom');
        printPreview(order);
      }
    }
  };

  const handleIndividualPayment = (customer: Customer) => {
    console.log('🔄 Abrindo modal de pagamento individual para:', customer.name);
    setSelectedCustomerForPayment(customer);
    setShowIndividualPayment(true);
  };

  const handleIndividualPaymentSuccess = () => {
    console.log('✅ Pagamento individual processado com sucesso');
    
    // Fechar o modal de pagamento
    setShowIndividualPayment(false);
    setSelectedCustomerForPayment(null);
    
    // Não fechar o modal principal, apenas atualizar os dados
    // O estado será atualizado automaticamente pelo contexto
  };

  const handleIndividualPaymentClose = () => {
    console.log('🔄 Fechando modal de pagamento individual');
    setShowIndividualPayment(false);
    setSelectedCustomerForPayment(null);
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title={`Mesa ${table.number} - Gerenciamento`}
        size="lg"
        variant="modern"
      >
        <div className="space-y-6">
          {/* Table Status */}
          <Card variant="modern" className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">
                  Status: {table.status === 'livre' ? 'Livre' : 
                          table.status === 'ocupada' ? 'Ocupada' : 'Aguardando'}
                </h3>
                <p className="text-sm text-gray-600">
                  {table.customers.length} cliente(s) na mesa
                </p>
                {table.waiterName && (
                  <p className="text-sm text-gray-500">
                    Garçom: {table.waiterName}
                  </p>
                )}
              </div>
              
              <div className="flex space-x-2">
                {table.status === 'livre' ? (
                  <Button
                    variant="primary"
                    icon={Plus}
                    onClick={handleCreateOrderClick}
                    rounded="xl"
                  >
                    Iniciar Pedido
                  </Button>
                ) : (
                  <>
                    <Button
                      variant="primary"
                      icon={ShoppingCart}
                      onClick={onAddItems}
                      disabled={table.customers.length === 0}
                      rounded="xl"
                    >
                      Adicionar Itens
                    </Button>
                    <Button
                      variant="outline"
                      icon={Users}
                      onClick={() => setShowAddCustomer(true)}
                      rounded="xl"
                    >
                      Novo Cliente
                    </Button>
                  </>
                )}
              </div>
            </div>
          </Card>

          {/* Botão de Prévia da Comanda - Só aparece se a mesa tem pedido */}
          {table.status === 'ocupada' && table.orderId && (
            <Card variant="modern" className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
              <div className="flex justify-between items-center">
                <div>
                  <h4 className="text-lg font-semibold text-green-900">
                    📋 Prévia da Comanda
                  </h4>
                  <p className="text-sm text-green-700">
                    Imprimir prévia do consumo atual da mesa via impressora do garçom
                  </p>
                </div>
                <Button
                  variant="success"
                  icon={Receipt}
                  onClick={handlePrintPreview}
                  rounded="xl"
                  className="bg-gradient-to-r from-green-600 to-emerald-600"
                >
                  Emitir Prévia
                </Button>
              </div>
            </Card>
          )}

          {/* Customers List */}
          {table.status === 'ocupada' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-lg font-medium text-gray-900">Clientes na Mesa</h4>
                {/* Indicador de que é admin */}
                {state.currentUser?.role === 'admin' && (
                  <div className="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded-full font-bold">
                    👑 ADMIN - Pode processar pagamentos individuais
                  </div>
                )}
              </div>
              
              {table.customers.length === 0 ? (
                <Card variant="modern" className="text-center py-8">
                  <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 mb-4">Nenhum cliente na mesa</p>
                  <Button
                    variant="primary"
                    icon={Plus}
                    onClick={() => setShowAddCustomer(true)}
                    rounded="xl"
                  >
                    Adicionar Primeiro Cliente
                  </Button>
                </Card>
              ) : (
                <div className="grid gap-4 md:grid-cols-2">
                  {table.customers.map((customer) => {
                    const amountToPay = customer.totalAmount - customer.paidAmount;
                    const isFullyPaid = customer.paidAmount >= customer.totalAmount;
                    
                    return (
                      <Card key={customer.id} variant="modern" className="p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <h5 className="font-medium text-gray-900">{customer.name}</h5>
                            <p className="text-sm text-gray-500">
                              {customer.items.length} item(s)
                            </p>
                          </div>
                          
                          <div className={`
                            px-2 py-1 rounded-full text-xs font-medium
                            ${customer.status === 'ativo' ? 'bg-green-100 text-green-800' :
                              customer.status === 'pago' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'}
                          `}>
                            {customer.status === 'ativo' ? 'Ativo' :
                             customer.status === 'pago' ? 'Pago' : 'Saiu'}
                          </div>
                        </div>

                        <div className="mb-3">
                          <div className="flex justify-between text-sm">
                            <span>Total:</span>
                            <span className="font-medium">R$ {customer.totalAmount.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Pago:</span>
                            <span className="font-medium text-green-600">
                              R$ {customer.paidAmount.toFixed(2)}
                            </span>
                          </div>
                          <div className="flex justify-between text-sm font-medium">
                            <span>Restante:</span>
                            <span className={
                              amountToPay > 0 ? 'text-red-600' : 'text-green-600'
                            }>
                              R$ {amountToPay.toFixed(2)}
                            </span>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {/* Botão de Pagamento Individual - SEMPRE VISÍVEL PARA ADMIN */}
                          {state.currentUser?.role === 'admin' && (
                            <div className="w-full">
                              {amountToPay > 0 ? (
                                <Button
                                  variant="success"
                                  size="sm"
                                  icon={CreditCard}
                                  onClick={() => handleIndividualPayment(customer)}
                                  fullWidth
                                  rounded="xl"
                                  className="bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold"
                                >
                                  💳 Pagar Individual (R$ {amountToPay.toFixed(2)})
                                </Button>
                              ) : (
                                <div className="w-full text-center py-2 bg-green-100 text-green-800 rounded-xl text-sm font-bold">
                                  ✅ Cliente Quitado
                                </div>
                              )}
                            </div>
                          )}
                          
                          {/* Botão de remover cliente */}
                          <div className="flex space-x-2">
                            <Button
                              variant="danger"
                              size="sm"
                              icon={Trash2}
                              onClick={() => handleRemoveCustomer(customer.id)}
                              fullWidth
                              rounded="xl"
                            >
                              Remover Cliente
                            </Button>
                          </div>
                        </div>

                        {/* Customer Items */}
                        {customer.items.length > 0 && (
                          <div className="mt-3 pt-3 border-t">
                            <p className="text-xs font-medium text-gray-700 mb-2">Itens:</p>
                            <div className="space-y-1">
                              {customer.items.slice(0, 3).map((item) => (
                                <div key={item.id} className="flex justify-between text-xs">
                                  <span>{item.quantity}x {item.productName}</span>
                                  <span>R$ {(item.price * item.quantity).toFixed(2)}</span>
                                </div>
                              ))}
                              {customer.items.length > 3 && (
                                <p className="text-xs text-gray-500">
                                  +{customer.items.length - 3} item(s)...
                                </p>
                              )}
                            </div>
                          </div>
                        )}
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      </Modal>

      {/* Create Order Modal */}
      {showCreateOrder && (
        <Modal
          isOpen={showCreateOrder}
          onClose={() => {
            setShowCreateOrder(false);
            setCustomerNames(['']);
          }}
          title={`Iniciar Pedido - Mesa ${table.number}`}
          size="md"
          variant="modern"
        >
          <div className="space-y-4">
            <p className="text-gray-600">
              Adicione os nomes dos clientes que irão ocupar esta mesa:
            </p>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Clientes <span className="text-red-500">*</span>
              </label>
              
              {customerNames.map((customer, index) => (
                <div key={index} className="flex space-x-2 mb-2">
                  <Input
                    placeholder={`Nome do cliente ${index + 1}`}
                    value={customer}
                    onChange={(value) => handleCustomerNameChange(index, value)}
                    fullWidth
                    variant="modern"
                  />
                  
                  {customerNames.length > 1 && (
                    <Button
                      variant="outline"
                      size="sm"
                      icon={Minus}
                      onClick={() => handleRemoveCustomerName(index)}
                      rounded="xl"
                    />
                  )}
                </div>
              ))}
              
              <Button
                variant="outline"
                size="sm"
                icon={Plus}
                onClick={handleAddCustomerName}
                rounded="xl"
              >
                Adicionar Cliente
              </Button>
            </div>

            <div className="flex space-x-3 pt-4">
              <Button
                variant="outline"
                fullWidth
                onClick={() => {
                  setShowCreateOrder(false);
                  setCustomerNames(['']);
                }}
                rounded="xl"
              >
                Cancelar
              </Button>
              <Button
                variant="primary"
                fullWidth
                onClick={handleCreateNewOrder}
                disabled={!customerNames.some(c => c.trim())}
                rounded="xl"
              >
                Criar Pedido
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Add Customer Modal */}
      {showAddCustomer && (
        <Modal
          isOpen={showAddCustomer}
          onClose={() => {
            setShowAddCustomer(false);
            setNewCustomerName('');
          }}
          title="Adicionar Cliente"
          size="sm"
          variant="modern"
        >
          <div className="space-y-4">
            <Input
              label="Nome do Cliente"
              placeholder="Digite o nome..."
              value={newCustomerName}
              onChange={setNewCustomerName}
              fullWidth
              variant="modern"
            />
            
            <div className="flex space-x-3">
              <Button
                variant="outline"
                fullWidth
                onClick={() => {
                  setShowAddCustomer(false);
                  setNewCustomerName('');
                }}
                rounded="xl"
              >
                Cancelar
              </Button>
              <Button
                variant="primary"
                fullWidth
                onClick={handleAddCustomer}
                disabled={!newCustomerName.trim()}
                rounded="xl"
              >
                Adicionar
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Individual Payment Modal */}
      <IndividualPaymentModal
        isOpen={showIndividualPayment}
        onClose={handleIndividualPaymentClose}
        table={table}
        customer={selectedCustomerForPayment}
        onSuccess={handleIndividualPaymentSuccess}
      />
    </>
  );
}