import React, { useState, useEffect } from 'react';
import { LogOut, Grid3X3, Users, TrendingUp, Clock, Bell, Coffee, Sparkles, Settings } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { useNetworkSync } from '../../hooks/useNetworkSync';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { TableGrid } from '../ui/TableGrid';
import { AddItemModal } from './AddItemModal';
import { CustomerSelectionModal } from './CustomerSelectionModal';
import { TableManagementModal } from './TableManagementModal';
import { WaiterTableManagement } from './TableManagement';
import { Table, Customer } from '../../types';

type ActiveTab = 'tables' | 'tableManagement';

export function WaiterDashboard() {
  const { state, logout, createOrder } = useApp();
  const { forcSync, discoveredDevices } = useNetworkSync();
  const [activeTab, setActiveTab] = useState<ActiveTab>('tables');
  const [showAddItemModal, setShowAddItemModal] = useState(false);
  const [showCustomerSelectionModal, setShowCustomerSelectionModal] = useState(false);
  const [showTableModal, setShowTableModal] = useState(false);
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [notifications, setNotifications] = useState<string[]>([]);
  const [networkStatus, setNetworkStatus] = useState<'connected' | 'disconnected' | 'syncing'>('disconnected');

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  // Check for notifications
  useEffect(() => {
    const newNotifications: string[] = [];
    
    // Check for orders ready
    const readyOrders = state.orders.filter(
      order => order.status === 'pronto' && order.waiterName === state.currentUser?.name
    );
    
    if (readyOrders.length > 0) {
      newNotifications.push(`${readyOrders.length} pedido(s) pronto(s) para entrega`);
    }
    
    // Check network status
    const connectedDevices = discoveredDevices.length;
    if (connectedDevices > 0) {
      setNetworkStatus('connected');
      newNotifications.push(`${connectedDevices} dispositivo(s) conectado(s) na rede`);
    } else {
      setNetworkStatus('disconnected');
    }
    
    setNotifications(newNotifications);
  }, [state.orders, state.currentUser?.name, discoveredDevices]);

  const waiterOrders = state.orders.filter(
    order => order.waiterName === state.currentUser?.name && 
    ['aberto', 'enviado', 'preparando', 'pronto', 'fechado'].includes(order.status)
  );

  const allTables = state.tables;
  const waiterTables = state.tables.filter(
    table => table.waiterName === state.currentUser?.name && table.status === 'ocupada'
  );

  // Calcular receita do garçom considerando pagamentos individuais
  const todayRevenue = state.orders.filter(order => {
    const today = new Date().toDateString();
    const orderDate = new Date(order.createdAt).toDateString();
    return orderDate === today && order.waiterName === state.currentUser?.name;
  }).reduce((sum, order) => {
    // Se o pedido está fechado, usar o total completo
    if (order.status === 'fechado') {
      return sum + order.total;
    }
    // Se tem pagamentos parciais, usar apenas o valor já pago
    if (order.paidTotal && order.paidTotal > 0) {
      return sum + order.paidTotal;
    }
    return sum;
  }, 0);

  const averageOrderValue = waiterOrders.length > 0 ? todayRevenue / waiterOrders.length : 0;

  const handleTableClick = (table: Table) => {
    console.log('Mesa clicada:', table);
    setSelectedTable(table);
    setShowTableModal(true);
  };

  const handleCustomerSelected = (customer: Customer) => {
    console.log('Cliente selecionado no dashboard:', customer);
    setSelectedCustomer(customer);
    
    // Garantir que o modal de seleção está fechado antes de abrir o de adicionar itens
    setShowCustomerSelectionModal(false);
    
    // Aguardar um pouco e abrir o modal de adicionar itens
    setTimeout(() => {
      setShowAddItemModal(true);
    }, 300);
  };

  const handleCustomerChangeInModal = (customer: Customer) => {
    console.log('🔄 Cliente alterado no modal:', customer.name);
    setSelectedCustomer(customer);
  };

  const handleAddItems = () => {
    setShowTableModal(false);
    if (selectedTable && selectedTable.customers.length > 0) {
      setTimeout(() => {
        setShowCustomerSelectionModal(true);
      }, 200);
    }
  };

  const handleCreateOrderForTable = (tableId: string, customerNames: string[]) => {
    const orderId = createOrder(tableId, customerNames, state.currentUser?.name || '');
    if (orderId) {
      const updatedTable = state.tables.find(t => t.id === tableId);
      if (updatedTable) {
        setSelectedTable(updatedTable);
      }
    }
    return orderId;
  };

  const handleCloseAddItemModal = () => {
    setShowAddItemModal(false);
    setSelectedCustomer(null);
    
    // Atualizar a mesa selecionada com os dados mais recentes
    if (selectedTable) {
      const updatedTable = state.tables.find(t => t.id === selectedTable.id);
      if (updatedTable) {
        setSelectedTable(updatedTable);
      }
    }
  };

  const handleCloseCustomerSelectionModal = () => {
    setShowCustomerSelectionModal(false);
    setSelectedCustomer(null);
  };

  const renderTabContent = () => {
    if (activeTab === 'tableManagement') {
      return <WaiterTableManagement />;
    }

    // Conteúdo principal - Layout das Mesas
    return (
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-4xl font-black bg-gradient-to-r from-slate-900 via-blue-900 to-indigo-900 bg-clip-text text-transparent">
              Layout das Mesas
            </h2>
            <p className="text-slate-600 mt-2 text-lg">Clique em uma mesa para gerenciar ou adicionar pedidos</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center bg-gradient-to-r from-emerald-50 to-green-50 px-4 py-3 rounded-2xl border border-emerald-200/60 shadow-lg">
              <div className="w-3 h-3 bg-emerald-500 rounded-full mr-3 animate-pulse shadow-lg shadow-emerald-500/50"></div>
              <span className="font-bold text-emerald-700 text-sm">
                Livre ({state.tables.filter(t => t.status === 'livre').length})
              </span>
            </div>
            <div className="flex items-center bg-gradient-to-r from-orange-50 to-amber-50 px-4 py-3 rounded-2xl border border-orange-200/60 shadow-lg">
              <div className="w-3 h-3 bg-orange-500 rounded-full mr-3 animate-pulse shadow-lg shadow-orange-500/50"></div>
              <span className="font-bold text-orange-700 text-sm">
                Ocupada ({state.tables.filter(t => t.status === 'ocupada').length})
              </span>
            </div>
            <div className="flex items-center bg-gradient-to-r from-yellow-50 to-amber-50 px-4 py-3 rounded-2xl border border-yellow-200/60 shadow-lg">
              <div className="w-3 h-3 bg-yellow-500 rounded-full mr-3 animate-pulse shadow-lg shadow-yellow-500/50"></div>
              <span className="font-bold text-yellow-700 text-sm">
                Aguardando ({state.tables.filter(t => t.status === 'aguardando').length})
              </span>
            </div>
          </div>
        </div>
        
        <TableGrid 
          tables={allTables} 
          showWaiterName={true}
          onTableClick={handleTableClick}
          currentUserRole={state.currentUser?.role}
        />
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/10 to-purple-600/10 rounded-full blur-3xl animate-float" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-emerald-400/10 to-blue-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '2s' }} />
      </div>

      {/* Modern header with glassmorphism - Ajustado para não conflitar com indicador de licença */}
      <header className="bg-white/80 backdrop-blur-2xl shadow-2xl border-b border-white/20 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-6">
              <div className="relative">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 rounded-2xl flex items-center justify-center shadow-2xl shadow-blue-500/25 transform rotate-3">
                  <Coffee className="w-7 h-7 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
                  <Sparkles className="w-2 h-2 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-black bg-gradient-to-r from-slate-900 via-blue-900 to-indigo-900 bg-clip-text text-transparent">
                  Painel do Garçom
                </h1>
                <p className="text-slate-600 flex items-center font-medium">
                  <span>Olá, {state.currentUser?.name}</span>
                  <span className="mx-3 w-1 h-1 bg-slate-400 rounded-full"></span>
                  <Clock className="w-4 h-4 mr-2" />
                  {currentTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Modern notifications */}
              {notifications.length > 0 && (
                <div className="relative">
                  <Button 
                    variant="warning" 
                    size="sm" 
                    icon={Bell} 
                    pulse
                    rounded="full"
                    className="bg-gradient-to-r from-amber-500 to-orange-500 shadow-lg shadow-amber-500/25"
                  >
                    {notifications.length}
                  </Button>
                </div>
              )}
              
              {/* Status de rede */}
              <div className={`flex items-center space-x-2 px-3 py-2 rounded-full text-xs font-bold ${
                networkStatus === 'connected' ? 'bg-green-100 text-green-800' :
                networkStatus === 'syncing' ? 'bg-yellow-100 text-yellow-800' :
                'bg-red-100 text-red-800'
              }`}>
                <div className={`w-2 h-2 rounded-full ${
                  networkStatus === 'connected' ? 'bg-green-500 animate-pulse' :
                  networkStatus === 'syncing' ? 'bg-yellow-500 animate-pulse' :
                  'bg-red-500'
                }`} />
                <span>
                  {networkStatus === 'connected' ? '🌐 Rede OK' :
                   networkStatus === 'syncing' ? '🔄 Sincronizando' :
                   '📡 Offline'}
                </span>
              </div>
              
              <Button
                variant="outline"
                icon={LogOut}
                onClick={logout}
                rounded="xl"
                className="border-slate-300 hover:border-slate-400"
              >
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10">
        {/* Enhanced stats cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
          <Card variant="modern" className="p-6 group hover:shadow-2xl" animated glow>
            <div className="flex items-center">
              <div className="p-4 bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl shadow-xl shadow-emerald-500/25 group-hover:scale-110 transition-transform duration-300">
                <Grid3X3 className="w-8 h-8 text-white" />
              </div>
              <div className="ml-6">
                <p className="text-sm font-bold text-slate-600 uppercase tracking-wide">Mesas Livres</p>
                <p className="text-4xl font-black bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
                  {state.tables.filter(t => t.status === 'livre').length}
                </p>
                <p className="text-xs text-slate-500 font-medium">de {state.tables.length} total</p>
              </div>
            </div>
          </Card>

          <Card variant="modern" className="p-6 group hover:shadow-2xl" animated glow>
            <div className="flex items-center">
              <div className="p-4 bg-gradient-to-br from-orange-500 to-amber-600 rounded-2xl shadow-xl shadow-orange-500/25 group-hover:scale-110 transition-transform duration-300">
                <Users className="w-8 h-8 text-white" />
              </div>
              <div className="ml-6">
                <p className="text-sm font-bold text-slate-600 uppercase tracking-wide">Minhas Mesas</p>
                <p className="text-4xl font-black bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                  {waiterTables.length}
                </p>
                <p className="text-xs text-slate-500 font-medium">atendendo agora</p>
              </div>
            </div>
          </Card>

          <Card variant="modern" className="p-6 group hover:shadow-2xl" animated glow>
            <div className="flex items-center">
              <div className="p-4 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl shadow-xl shadow-blue-500/25 group-hover:scale-110 transition-transform duration-300">
                <Coffee className="w-8 h-8 text-white" />
              </div>
              <div className="ml-6">
                <p className="text-sm font-bold text-slate-600 uppercase tracking-wide">Itens Servidos</p>
                <p className="text-4xl font-black bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  {waiterOrders.reduce((sum, order) => sum + order.items.length, 0)}
                </p>
                <p className="text-xs text-slate-500 font-medium">hoje</p>
              </div>
            </div>
          </Card>

          <Card variant="modern" className="p-6 group hover:shadow-2xl" animated glow>
            <div className="flex items-center">
              <div className="p-4 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl shadow-xl shadow-purple-500/25 group-hover:scale-110 transition-transform duration-300">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <div className="ml-6">
                <p className="text-sm font-bold text-slate-600 uppercase tracking-wide">Ticket Médio</p>
                <p className="text-4xl font-black bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  R$ {averageOrderValue.toFixed(0)}
                </p>
                <p className="text-xs text-slate-500 font-medium">por pedido</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Modern navigation tabs - Simplificado */}
        <div className="mb-10">
          <Card variant="glass" className="p-2 shadow-2xl">
            <nav className="flex space-x-2">
              <button
                onClick={() => setActiveTab('tables')}
                className={`flex-1 py-4 px-8 rounded-2xl font-bold text-sm transition-all duration-300 flex items-center justify-center space-x-3 ${
                  activeTab === 'tables'
                    ? 'bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white shadow-xl transform scale-105'
                    : 'text-slate-600 hover:text-slate-800 hover:bg-white/50'
                }`}
              >
                <Grid3X3 className="w-5 h-5" />
                <span>Layout das Mesas</span>
              </button>

              <button
                onClick={() => setActiveTab('tableManagement')}
                className={`flex-1 py-4 px-8 rounded-2xl font-bold text-sm transition-all duration-300 flex items-center justify-center space-x-3 ${
                  activeTab === 'tableManagement'
                    ? 'bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white shadow-xl transform scale-105'
                    : 'text-slate-600 hover:text-slate-800 hover:bg-white/50'
                }`}
              >
                <Settings className="w-5 h-5" />
                <span>Gerenciar Mesas</span>
              </button>
            </nav>
          </Card>
        </div>

        <div className="animate-fadeIn">
          {renderTabContent()}
        </div>
      </main>

      {/* Customer Selection Modal */}
      <CustomerSelectionModal
        isOpen={showCustomerSelectionModal}
        onClose={handleCloseCustomerSelectionModal}
        table={selectedTable}
        onCustomerSelected={handleCustomerSelected}
      />

      {/* Add Item Modal */}
      <AddItemModal
        isOpen={showAddItemModal}
        onClose={handleCloseAddItemModal}
        table={selectedTable}
        selectedCustomer={selectedCustomer}
        onCustomerChange={handleCustomerChangeInModal}
      />

      {/* Table Management Modal */}
      <TableManagementModal
        isOpen={showTableModal}
        onClose={() => {
          setShowTableModal(false);
          setSelectedTable(null);
        }}
        table={selectedTable}
        onAddItems={handleAddItems}
        onCreateOrder={handleCreateOrderForTable}
      />
    </div>
  );
}