import React, { useState } from 'react';
import { 
  ShoppingCart, 
  TrendingUp, 
  Settings, 
  LogOut, 
  DollarSign,
  Users,
  Calendar,
  Printer,
  Package,
  UserPlus,
  Grid3X3,
  CreditCard,
  Receipt
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { useNetworkSync } from '../../hooks/useNetworkSync';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { TableGrid } from '../ui/TableGrid';
import { OrderManagement } from './OrderManagement';
import { SalesReports } from './SalesReports';
import { SystemConfig } from './SystemConfig';
import { ProductManagement } from './ProductManagement';
import { UserManagement } from './UserManagement';
import { TableManagement } from './TableManagement';
import { IndividualPaymentModal } from './IndividualPaymentModal';
import { Table, Customer } from '../../types';

type ActiveTab = 'tables' | 'orders' | 'reports' | 'products' | 'users' | 'config' | 'tableManagement';

export function AdminDashboard() {
  const { state, logout, printPreview } = useApp();
  const { forcSync, discoveredDevices } = useNetworkSync();
  const [activeTab, setActiveTab] = useState<ActiveTab>('tables');
  const [showIndividualPayment, setShowIndividualPayment] = useState(false);
  const [selectedTable, setSelectedTable] = useState<Table | null>(null);
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const activeOrders = state.orders.filter(order => 
    ['aberto', 'enviado', 'preparando', 'pronto'].includes(order.status)
  );

  const todayOrders = state.orders.filter(order => {
    const today = new Date().toDateString();
    const orderDate = new Date(order.createdAt).toDateString();
    // Incluir pedidos fechados OU pedidos com pagamentos parciais do dia
    return orderDate === today && (order.status === 'fechado' || (order.paidTotal && order.paidTotal > 0));
  });

  // Calcular receita considerando pagamentos individuais
  const todayRevenue = state.orders.filter(order => {
    const today = new Date().toDateString();
    const orderDate = new Date(order.createdAt).toDateString();
    return orderDate === today;
  }).reduce((sum, order) => {
    // Se o pedido está fechado, usar o total completo
    if (order.status === 'fechado') {
      return sum + order.total;
    }
    // Se tem pagamentos parciais, usar apenas o valor já pago
    if (order.paidTotal && order.paidTotal > 0) {
      return sum + order.paidTotal;
    }
    return sum;
  }, 0);

  // Mostrar todas as mesas para o admin
  const allTables = state.tables;
  const occupiedTables = state.tables.filter(table => table.status === 'ocupada');

  const handleTableClick = (table: Table) => {
    console.log('🔄 Admin clicou na mesa:', table.number);
    
    // Se a mesa está ocupada e tem clientes, mostrar opções de pagamento individual
    if (table.status === 'ocupada' && table.customers.length > 0) {
      // Se há apenas um cliente, abrir direto o modal de pagamento
      if (table.customers.length === 1) {
        const customer = table.customers[0];
        const amountToPay = customer.totalAmount - customer.paidAmount;
        
        if (amountToPay > 0) {
          setSelectedTable(table);
          setSelectedCustomer(customer);
          setShowIndividualPayment(true);
        } else {
          alert(`✅ Cliente ${customer.name} já quitou sua parte!`);
        }
      } else {
        // Se há múltiplos clientes, mostrar lista para seleção
        showCustomerSelectionForPayment(table);
      }
    } else {
      alert('ℹ️ Esta mesa não possui clientes ou não está ocupada.');
    }
  };

  const showCustomerSelectionForPayment = (table: Table) => {
    const customersWithDebt = table.customers.filter(c => (c.totalAmount - c.paidAmount) > 0);
    
    if (customersWithDebt.length === 0) {
      alert('✅ Todos os clientes desta mesa já quitaram suas partes!');
      return;
    }
    
    if (customersWithDebt.length === 1) {
      setSelectedTable(table);
      setSelectedCustomer(customersWithDebt[0]);
      setShowIndividualPayment(true);
    } else {
      // Criar uma lista de seleção
      const customerList = customersWithDebt.map((customer, index) => {
        const amountToPay = customer.totalAmount - customer.paidAmount;
        return `${index + 1}. ${customer.name} - R$ ${amountToPay.toFixed(2)}`;
      }).join('\n');
      
      const selection = prompt(`Selecione o cliente para pagamento:\n\n${customerList}\n\nDigite o número do cliente:`);
      
      if (selection) {
        const customerIndex = parseInt(selection) - 1;
        if (customerIndex >= 0 && customerIndex < customersWithDebt.length) {
          setSelectedTable(table);
          setSelectedCustomer(customersWithDebt[customerIndex]);
          setShowIndividualPayment(true);
        } else {
          alert('❌ Seleção inválida!');
        }
      }
    }
  };

  const handleIndividualPaymentSuccess = () => {
    console.log('✅ Pagamento individual processado com sucesso no admin');
    
    // Fechar modal e limpar seleções
    setShowIndividualPayment(false);
    setSelectedTable(null);
    setSelectedCustomer(null);
    
    // Não redirecionar, apenas manter na mesma tela
    // O estado será atualizado automaticamente pelo contexto
  };

  const handleIndividualPaymentClose = () => {
    console.log('🔄 Fechando modal de pagamento individual no admin');
    setShowIndividualPayment(false);
    setSelectedTable(null);
    setSelectedCustomer(null);
  };

  const handlePrintPreview = (table: any) => {
    if (table.orderId) {
      const order = state.orders.find(o => o.id === table.orderId);
      if (order) {
        console.log('🖨️ Admin imprimindo prévia da comanda via impressora do garçom');
        printPreview(order);
      }
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'tables':
        return (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Todas as Mesas do Restaurante</h2>
                <p className="text-gray-600 mt-1">
                  💳 <strong>Clique em uma mesa ocupada</strong> para processar pagamento individual por cliente
                </p>
              </div>
              <div className="flex items-center space-x-4 text-sm">
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
                  <span>Livre ({state.tables.filter(t => t.status === 'livre').length})</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
                  <span>Ocupada ({occupiedTables.length})</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                  <span>Aguardando ({state.tables.filter(t => t.status === 'aguardando').length})</span>
                </div>
              </div>
            </div>

            {/* Instruções para pagamento individual */}
            <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <CreditCard className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-purple-900">
                    💳 Pagamento Individual por Cliente
                  </h4>
                  <p className="text-sm text-purple-700">
                    <strong>Como usar:</strong> Clique em qualquer mesa ocupada para processar o pagamento individual de cada cliente. 
                    Ideal para quando um cliente quer pagar apenas sua parte da conta.
                  </p>
                </div>
              </div>
            </Card>

            {/* Instruções para prévia de comanda */}
            <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <Receipt className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-green-900">
                    📋 Prévia de Comanda
                  </h4>
                  <p className="text-sm text-green-700">
                    <strong>Impressão automática:</strong> Prévias são impressas automaticamente na impressora do garçom configurada nas configurações. 
                    Tanto admin quanto garçom podem gerar prévias de consumo.
                  </p>
                </div>
              </div>
            </Card>
            
            <TableGrid 
              tables={allTables} 
              showWaiterName={true}
              showActions={true}
              currentUserRole="admin"
              onTableClick={handleTableClick}
            />
          </div>
        );
      case 'orders':
        return <OrderManagement />;
      case 'reports':
        return <SalesReports />;
      case 'products':
        return <ProductManagement />;
      case 'users':
        return <UserManagement />;
      case 'config':
        return <SystemConfig />;
      case 'tableManagement':
        return <TableManagement />;
      default:
        return <OrderManagement />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <header className="bg-white shadow-lg border-b sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-xl font-semibold text-gray-900">
                Painel Administrativo
              </h1>
              <p className="text-sm text-gray-500">
                Olá, {state.currentUser?.name} • {discoveredDevices.length} dispositivo(s) na rede
              </p>
            </div>
            <div className="flex items-center space-x-4">
              {/* Status de rede */}
              <div className={`flex items-center space-x-2 px-3 py-2 rounded-full text-xs font-bold ${
                discoveredDevices.length > 0 ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
              }`}>
                <div className={`w-2 h-2 rounded-full ${
                  discoveredDevices.length > 0 ? 'bg-green-500 animate-pulse' : 'bg-red-500'
                }`} />
                <span>
                  {discoveredDevices.length > 0 ? '🌐 Rede OK' : '📡 Offline'}
                </span>
              </div>
              
              <Button
                variant="outline"
                icon={LogOut}
                onClick={logout}
              >
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="p-6" animated>
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl">
                <ShoppingCart className="w-6 h-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pedidos Ativos</p>
                <p className="text-2xl font-bold text-gray-900">{activeOrders.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6" animated>
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-green-500 to-green-600 rounded-xl">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Receita Hoje</p>
                <p className="text-2xl font-bold text-gray-900">
                  R$ {todayRevenue.toFixed(2)}
                </p>
              </div>
            </div>
          </Card>

          <Card className="p-6" animated>
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-purple-500 to-purple-600 rounded-xl">
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pedidos Hoje</p>
                <p className="text-2xl font-bold text-gray-900">{todayOrders.length}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6" animated>
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-amber-500 to-amber-600 rounded-xl">
                <Grid3X3 className="w-6 h-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Mesas Ocupadas</p>
                <p className="text-sm font-bold text-gray-900">
                  {occupiedTables.length} / {state.tables.length}
                </p>
              </div>
            </div>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-8 overflow-x-auto">
            <button
              onClick={() => setActiveTab('tables')}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                activeTab === 'tables'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Grid3X3 className="w-4 h-4 inline mr-2" />
              Layout das Mesas
            </button>

            <button
              onClick={() => setActiveTab('tableManagement')}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                activeTab === 'tableManagement'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Settings className="w-4 h-4 inline mr-2" />
              Gerenciar Mesas
            </button>
            
            <button
              onClick={() => setActiveTab('orders')}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                activeTab === 'orders'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <ShoppingCart className="w-4 h-4 inline mr-2" />
              Pedidos ({activeOrders.length})
            </button>
            
            <button
              onClick={() => setActiveTab('reports')}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                activeTab === 'reports'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <TrendingUp className="w-4 h-4 inline mr-2" />
              Relatórios
            </button>
            
            <button
              onClick={() => setActiveTab('products')}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                activeTab === 'products'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Package className="w-4 h-4 inline mr-2" />
              Produtos ({state.products.length})
            </button>
            
            <button
              onClick={() => setActiveTab('users')}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                activeTab === 'users'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <UserPlus className="w-4 h-4 inline mr-2" />
              Usuários ({state.users.filter(u => u.active).length})
            </button>
            
            <button
              onClick={() => setActiveTab('config')}
              className={`py-2 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-all duration-200 ${
                activeTab === 'config'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Settings className="w-4 h-4 inline mr-2" />
              Configurações
            </button>
          </nav>
        </div>

        {/* Tab Content */}
        <div className="animate-fadeIn">
          {renderContent()}
        </div>
      </div>

      {/* Individual Payment Modal */}
      <IndividualPaymentModal
        isOpen={showIndividualPayment}
        onClose={handleIndividualPaymentClose}
        table={selectedTable}
        customer={selectedCustomer}
        onSuccess={handleIndividualPaymentSuccess}
      />
    </div>
  );
}