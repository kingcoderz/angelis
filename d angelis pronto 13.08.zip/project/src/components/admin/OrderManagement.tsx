import React, { useState } from 'react';
import { 
  Eye, 
  CreditCard, 
  XCircle, 
  Receipt, 
  Users,
  Clock,
  CheckCircle,
  Edit,
  Trash2,
  Plus
} from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Modal } from '../ui/Modal';
import { StatusBadge } from '../ui/StatusBadge';
import { Order } from '../../types';
import { CloseOrderModal } from './CloseOrderModal';
import { CancelOrderModal } from './CancelOrderModal';
import { OrderDetailsModal } from './OrderDetailsModal';
import { EditOrderModal } from './EditOrderModal';

export function OrderManagement() {
  const { state, printPreview } = useApp();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);

  // Apenas admin pode fechar pedidos - garçom não tem essa função
  const activeOrders = state.orders.filter(order => 
    ['aberto', 'enviado', 'preparando', 'pronto'].includes(order.status)
  );

  const handleViewDetails = (order: Order) => {
    setSelectedOrder(order);
    setShowDetailsModal(true);
  };

  const handleEditOrder = (order: Order) => {
    if (state.currentUser?.role !== 'admin') {
      alert('Apenas administradores podem editar pedidos!');
      return;
    }
    
    if (order.status !== 'aberto') {
      alert('Apenas pedidos em aberto podem ser editados!');
      return;
    }
    
    setSelectedOrder(order);
    setShowEditModal(true);
  };

  const handlePrintPreview = (order: Order) => {
    console.log('🖨️ Admin imprimindo prévia da comanda');
    printPreview(order);
  };
  const handleCloseOrder = (order: Order) => {
    // Verificar se é admin
    if (state.currentUser?.role !== 'admin') {
      alert('Apenas administradores podem fechar pedidos!');
      return;
    }
    
    setSelectedOrder(order);
    setShowCloseModal(true);
  };

  const handleCancelOrder = (order: Order) => {
    // Verificar se é admin
    if (state.currentUser?.role !== 'admin') {
      alert('Apenas administradores podem cancelar pedidos!');
      return;
    }
    
    setSelectedOrder(order);
    setShowCancelModal(true);
  };


  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Pedidos Ativos</h2>
        <div className="text-sm text-gray-500">
          {state.currentUser?.role === 'admin' ? 
            'Você pode fechar e cancelar pedidos' : 
            'Apenas visualização - Somente admin pode fechar pedidos'
          }
        </div>
      </div>

      {activeOrders.length === 0 ? (
        <Card className="text-center py-12">
          <CheckCircle className="w-16 h-16 text-green-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhum pedido ativo
          </h3>
          <p className="text-gray-500">
            Todos os pedidos foram finalizados ou não há pedidos em andamento.
          </p>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {activeOrders.map((order) => (
            <Card key={order.id} hover>
              <div className="flex justify-between items-start mb-3">
                <div>
                  <h3 className="font-semibold text-gray-900">
                    Mesa {order.tableNumber}
                  </h3>
                  <p className="text-sm text-gray-500 flex items-center">
                    <Users className="w-3 h-3 mr-1" />
                    {order.customers.map(c => c.name).join(', ')}
                  </p>
                  <p className="text-sm text-gray-500 flex items-center mt-1">
                    <Clock className="w-3 h-3 mr-1" />
                    {new Date(order.createdAt).toLocaleTimeString()}
                  </p>
                </div>
                <StatusBadge status={order.status} />
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-600 mb-1">
                  Garçom: {order.waiterName}
                </p>
                <p className="text-sm text-gray-600 mb-2">
                  {order.items.length} item(s)
                </p>
                
                {/* Mostrar consumo por cliente */}
                <div className="space-y-1 mb-3">
                  {order.customers.map(customer => (
                    <div key={customer.id} className="text-xs bg-gray-50 p-2 rounded">
                      <div className="flex justify-between">
                        <span className="font-medium">{customer.name}:</span>
                        <span>R$ {customer.totalAmount.toFixed(2)}</span>
                      </div>
                      {customer.paidAmount > 0 && (
                        <div className="flex justify-between text-green-600">
                          <span>Pago:</span>
                          <span>R$ {customer.paidAmount.toFixed(2)}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                
                <p className="text-lg font-bold text-gray-900">
                  Total: R$ {order.total.toFixed(2)}
                </p>
                {order.paidTotal > 0 && (
                  <p className="text-sm font-medium text-green-600">
                    Pago: R$ {order.paidTotal.toFixed(2)}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    icon={Eye}
                    onClick={() => handleViewDetails(order)}
                    fullWidth
                  >
                    Ver Detalhes
                  </Button>
                </div>
                  <Button
                    variant="outline"
                    size="sm"
                    icon={Receipt}
                    onClick={() => handlePrintPreview(order)}
                    className="bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
                  >
                    Prévia
                  </Button>
                
                {state.currentUser?.role === 'admin' && (
                  <div className="grid grid-cols-2 gap-2">
                    {order.status === 'aberto' && (
                      <Button
                        variant="outline"
                        size="sm"
                        icon={Edit}
                        onClick={() => handleEditOrder(order)}
                        className="bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                      >
                        Editar
                      </Button>
                    )}
                    
                    <Button
                      variant="success"
                      size="sm"
                      icon={CreditCard}
                      onClick={() => handleCloseOrder(order)}
                      className={order.status === 'aberto' ? '' : 'col-span-2'}
                    >
                      Fechar
                    </Button>
                    
                    <Button
                      variant="danger"
                      size="sm"
                      icon={XCircle}
                      onClick={() => handleCancelOrder(order)}
                      className="col-span-2"
                    >
                      Cancelar
                    </Button>
                  </div>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Modals */}
      <OrderDetailsModal
        isOpen={showDetailsModal}
        onClose={() => setShowDetailsModal(false)}
        order={selectedOrder}
      />

      <EditOrderModal
        isOpen={showEditModal}
        onClose={() => setShowEditModal(false)}
        order={selectedOrder}
        onSuccess={() => setShowEditModal(false)}
      />
      {state.currentUser?.role === 'admin' && (
        <>
          <CloseOrderModal
            isOpen={showCloseModal}
            onClose={() => setShowCloseModal(false)}
            order={selectedOrder}
            onSuccess={() => {
              setShowCloseModal(false);
            }}
          />

          <CancelOrderModal
            isOpen={showCancelModal}
            onClose={() => setShowCancelModal(false)}
            order={selectedOrder}
            onSuccess={() => setShowCancelModal(false)}
          />
        </>
      )}
    </div>
  );
}