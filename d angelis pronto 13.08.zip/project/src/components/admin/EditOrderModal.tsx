import React, { useState, useEffect } from 'react';
import { Edit, Trash2, Plus, Save, X, ShoppingCart, User } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Order, OrderItem, Customer } from '../../types';

interface EditOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onSuccess: () => void;
}

export function EditOrderModal({ isOpen, onClose, order, onSuccess }: EditOrderModalProps) {
  const { state, updateOrder, removeItemFromOrder, addItemToOrder } = useApp();
  const [editingItems, setEditingItems] = useState<OrderItem[]>([]);
  const [editingCustomers, setEditingCustomers] = useState<Customer[]>([]);
  const [showAddItem, setShowAddItem] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [selectedCustomer, setSelectedCustomer] = useState('');
  const [itemQuantity, setItemQuantity] = useState('1');
  const [itemNotes, setItemNotes] = useState('');
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    if (order && isOpen) {
      setEditingItems([...order.items]);
      setEditingCustomers([...order.customers]);
      setHasChanges(false);
    }
  }, [order, isOpen]);

  if (!order) return null;

  const handleRemoveItem = (itemId: string) => {
    if (confirm('Tem certeza que deseja remover este item?')) {
      const itemToRemove = editingItems.find(i => i.id === itemId);
      if (!itemToRemove) return;

      // Remover item da lista
      const updatedItems = editingItems.filter(i => i.id !== itemId);
      setEditingItems(updatedItems);

      // Atualizar customer
      const updatedCustomers = editingCustomers.map(customer => {
        if (customer.name === itemToRemove.customerName) {
          const customerItems = customer.items.filter(i => i.id !== itemId);
          const customerTotal = customerItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);
          return {
            ...customer,
            items: customerItems,
            totalAmount: customerTotal,
          };
        }
        return customer;
      });
      setEditingCustomers(updatedCustomers);
      setHasChanges(true);

      // Remover do pedido real
      removeItemFromOrder(order.id, itemId);
    }
  };

  const handleUpdateItemQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return;

    const updatedItems = editingItems.map(item => {
      if (item.id === itemId) {
        return { ...item, quantity: newQuantity };
      }
      return item;
    });
    setEditingItems(updatedItems);

    // Atualizar customer
    const updatedCustomers = editingCustomers.map(customer => {
      const customerItems = customer.items.map(item => {
        if (item.id === itemId) {
          return { ...item, quantity: newQuantity };
        }
        return item;
      });
      const customerTotal = customerItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);
      return {
        ...customer,
        items: customerItems,
        totalAmount: customerTotal,
      };
    });
    setEditingCustomers(updatedCustomers);
    setHasChanges(true);
  };

  const handleUpdateItemNotes = (itemId: string, notes: string) => {
    const updatedItems = editingItems.map(item => {
      if (item.id === itemId) {
        return { ...item, notes: notes.trim() || undefined };
      }
      return item;
    });
    setEditingItems(updatedItems);

    // Atualizar customer
    const updatedCustomers = editingCustomers.map(customer => {
      const customerItems = customer.items.map(item => {
        if (item.id === itemId) {
          return { ...item, notes: notes.trim() || undefined };
        }
        return item;
      });
      return {
        ...customer,
        items: customerItems,
      };
    });
    setEditingCustomers(updatedCustomers);
    setHasChanges(true);
  };

  const handleAddItem = () => {
    if (!selectedProduct || !selectedCustomer || !itemQuantity) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    const product = state.products.find(p => p.id === selectedProduct);
    if (!product) return;

    const newItem: OrderItem = {
      id: `item-${Date.now()}-${Math.random()}`,
      productId: product.id,
      productName: product.name,
      price: product.price,
      quantity: parseInt(itemQuantity),
      customerName: selectedCustomer,
      notes: itemNotes.trim() || undefined,
      status: 'pendente',
    };

    // Adicionar ao pedido real
    addItemToOrder(order.id, newItem);

    // Reset form
    setSelectedProduct('');
    setSelectedCustomer('');
    setItemQuantity('1');
    setItemNotes('');
    setShowAddItem(false);
    setHasChanges(true);
  };

  const handleSaveChanges = () => {
    const newTotal = editingItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    const updatedOrder: Order = {
      ...order,
      items: editingItems,
      customers: editingCustomers,
      total: newTotal,
      updatedAt: new Date().toISOString(),
    };

    updateOrder(updatedOrder);
    setHasChanges(false);
    onSuccess();
    alert('✅ Pedido atualizado com sucesso!');
  };

  const totalOrder = editingItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Editar Pedido - Mesa ${order.tableNumber}`}
      size="xl"
      variant="modern"
    >
      <div className="space-y-6">
        {/* Header Info */}
        <Card variant="modern" className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-bold text-blue-900">
                Mesa {order.tableNumber} - {order.customers.map(c => c.name).join(', ')}
              </h3>
              <p className="text-sm text-blue-700">
                Garçom: {order.waiterName} • Criado: {new Date(order.createdAt).toLocaleString('pt-BR')}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-blue-700">Total atual:</p>
              <p className="text-2xl font-black text-blue-900">
                R$ {totalOrder.toFixed(2)}
              </p>
            </div>
          </div>
        </Card>

        {/* Add Item Section */}
        <Card variant="modern">
          <div className="flex justify-between items-center mb-4">
            <h4 className="text-lg font-bold text-gray-900">Itens do Pedido</h4>
            <Button
              variant="primary"
              size="sm"
              icon={Plus}
              onClick={() => setShowAddItem(!showAddItem)}
              rounded="xl"
            >
              Adicionar Item
            </Button>
          </div>

          {showAddItem && (
            <Card variant="modern" className="bg-green-50 border-green-200 mb-4">
              <h5 className="font-bold text-green-900 mb-4">Adicionar Novo Item</h5>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Produto *
                  </label>
                  <select
                    value={selectedProduct}
                    onChange={(e) => setSelectedProduct(e.target.value)}
                    className="block w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                  >
                    <option value="">Selecione um produto...</option>
                    {state.products.filter(p => p.available).map(product => (
                      <option key={product.id} value={product.id}>
                        {product.name} - R$ {product.price.toFixed(2)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Cliente *
                  </label>
                  <select
                    value={selectedCustomer}
                    onChange={(e) => setSelectedCustomer(e.target.value)}
                    className="block w-full rounded-xl border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500"
                  >
                    <option value="">Selecione um cliente...</option>
                    {order.customers.map(customer => (
                      <option key={customer.id} value={customer.name}>
                        {customer.name}
                      </option>
                    ))}
                  </select>
                </div>

                <Input
                  label="Quantidade *"
                  type="number"
                  min="1"
                  value={itemQuantity}
                  onChange={setItemQuantity}
                  variant="modern"
                />

                <Input
                  label="Observações"
                  placeholder="Ex: sem cebola, bem passado..."
                  value={itemNotes}
                  onChange={setItemNotes}
                  variant="modern"
                />
              </div>

              <div className="flex space-x-3 mt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowAddItem(false);
                    setSelectedProduct('');
                    setSelectedCustomer('');
                    setItemQuantity('1');
                    setItemNotes('');
                  }}
                  rounded="xl"
                >
                  Cancelar
                </Button>
                <Button
                  variant="success"
                  onClick={handleAddItem}
                  disabled={!selectedProduct || !selectedCustomer || !itemQuantity}
                  rounded="xl"
                >
                  Adicionar Item
                </Button>
              </div>
            </Card>
          )}

          {/* Items List */}
          <div className="space-y-3">
            {editingItems.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                Nenhum item no pedido
              </div>
            ) : (
              editingItems.map((item) => (
                <Card key={item.id} variant="modern" className="p-4">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h5 className="font-bold text-gray-900">
                          {item.productName}
                        </h5>
                        <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded-full">
                          {item.customerName}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">
                            Quantidade
                          </label>
                          <div className="flex items-center space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleUpdateItemQuantity(item.id, item.quantity - 1)}
                              disabled={item.quantity <= 1}
                              rounded="full"
                            >
                              -
                            </Button>
                            <span className="w-12 text-center font-bold">
                              {item.quantity}
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleUpdateItemQuantity(item.id, item.quantity + 1)}
                              rounded="full"
                            >
                              +
                            </Button>
                          </div>
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">
                            Preço unitário
                          </label>
                          <p className="font-bold text-gray-900">
                            R$ {item.price.toFixed(2)}
                          </p>
                        </div>

                        <div>
                          <label className="block text-xs font-medium text-gray-600 mb-1">
                            Total
                          </label>
                          <p className="font-bold text-green-600 text-lg">
                            R$ {(item.price * item.quantity).toFixed(2)}
                          </p>
                        </div>
                      </div>

                      <div className="mt-3">
                        <label className="block text-xs font-medium text-gray-600 mb-1">
                          Observações
                        </label>
                        <textarea
                          value={item.notes || ''}
                          onChange={(e) => handleUpdateItemNotes(item.id, e.target.value)}
                          placeholder="Observações do item..."
                          className="w-full text-sm border border-gray-200 rounded-lg px-3 py-2 focus:border-blue-500 focus:ring-blue-500"
                          rows={2}
                        />
                      </div>
                    </div>

                    <Button
                      variant="danger"
                      size="sm"
                      icon={Trash2}
                      onClick={() => handleRemoveItem(item.id)}
                      rounded="full"
                      className="ml-4"
                    >
                      Remover
                    </Button>
                  </div>
                </Card>
              ))
            )}
          </div>
        </Card>

        {/* Summary */}
        <Card variant="modern" className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <div className="flex justify-between items-center">
            <div>
              <h4 className="text-lg font-bold text-green-900">
                Resumo do Pedido
              </h4>
              <p className="text-sm text-green-700">
                {editingItems.length} item(s) • {editingCustomers.length} cliente(s)
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-green-700">Total geral:</p>
              <p className="text-3xl font-black text-green-900">
                R$ {totalOrder.toFixed(2)}
              </p>
            </div>
          </div>
        </Card>

        {/* Actions */}
        <div className="flex justify-between items-center pt-6 border-t border-gray-200">
          <div>
            {hasChanges && (
              <p className="text-sm text-orange-600 font-medium">
                ⚠️ Há alterações não salvas
              </p>
            )}
          </div>
          
          <div className="flex space-x-4">
            <Button
              variant="outline"
              onClick={onClose}
              rounded="xl"
            >
              Fechar
            </Button>
            
            {hasChanges && (
              <Button
                variant="success"
                icon={Save}
                onClick={handleSaveChanges}
                rounded="xl"
                className="bg-gradient-to-r from-green-600 to-emerald-600"
              >
                Salvar Alterações
              </Button>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
}