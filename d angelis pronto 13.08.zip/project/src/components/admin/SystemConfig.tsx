import React, { useState, useEffect } from 'react';
import { Save, Building, Printer, Plus, Trash2, TestTube, CheckCircle, XCircle, Wifi, Settings, Search, RefreshCw } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Modal } from '../ui/Modal';
import { AppConfig, PrinterConfig } from '../../types';
import { NetworkService } from '../../services/NetworkService';
import { PrinterDiscoveryService } from '../../services/PrinterDiscovery';

export function SystemConfig() {
  const { state, updateConfig } = useApp();
  const [config, setConfig] = useState<AppConfig>(state.config);
  const [saving, setSaving] = useState(false);
  const [showPrinterModal, setShowPrinterModal] = useState(false);
  const [editingPrinter, setEditingPrinter] = useState<PrinterConfig | null>(null);
  const [printerType, setPrinterType] = useState<'kitchen' | 'waiter'>('kitchen');
  const [testingPrinter, setTestingPrinter] = useState<string | null>(null);
  const [discoveringPrinters, setDiscoveringPrinters] = useState(false);
  const [discoveredPrinters, setDiscoveredPrinters] = useState<any[]>([]);
  const [showDiscoveredPrinters, setShowDiscoveredPrinters] = useState(false);
  const [printerForm, setPrinterForm] = useState({
    name: '',
    ip: '',
    port: '9100'
  });

  // Sincronizar com o estado global
  useEffect(() => {
    try {
      setConfig(state.config);
    } catch (error) {
      console.error('Erro ao sincronizar configurações:', error);
    }
  }, [state.config]);

  const handleCompanyChange = (field: keyof AppConfig['company'], value: string) => {
    try {
      setConfig({
        ...config,
        company: {
          ...config.company,
          [field]: value,
        },
      });
    } catch (error) {
      console.error('Erro ao atualizar dados da empresa:', error);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      updateConfig(config);
      alert('✅ Configurações salvas com sucesso!');
    } catch (error) {
      console.error('Erro ao salvar:', error);
      alert('❌ Erro ao salvar configurações');
    } finally {
      setSaving(false);
    }
  };

  const handleAddPrinter = (type: 'kitchen' | 'waiter') => {
    setPrinterType(type);
    setEditingPrinter(null);
    setShowDiscoveredPrinters(false);
    setPrinterForm({
      name: type === 'kitchen' ? 'Impressora da Cozinha' : 'Impressora do Garçom',
      ip: '192.168.1.100',
      port: '9100'
    });
    setShowPrinterModal(true);
  };

  const handleEditPrinter = (printer: PrinterConfig) => {
    setEditingPrinter(printer);
    setPrinterType(printer.type);
    setShowDiscoveredPrinters(false);
    setPrinterForm({
      name: printer.name,
      ip: printer.ip,
      port: printer.port.toString()
    });
    setShowPrinterModal(true);
  };

  const handleSavePrinter = () => {
    if (!printerForm.name.trim() || !printerForm.ip.trim() || !printerForm.port.trim()) {
      alert('❌ Preencha todos os campos obrigatórios');
      return;
    }

    const newPrinter: PrinterConfig = {
      id: editingPrinter?.id || `printer-${Date.now()}`,
      name: printerForm.name.trim(),
      ip: printerForm.ip.trim(),
      port: parseInt(printerForm.port),
      enabled: true,
      type: printerType
    };

    const updatedConfig = {
      ...config,
      printers: {
        ...config.printers,
        [printerType]: newPrinter
      }
    };

    setConfig(updatedConfig);
    setShowPrinterModal(false);
    resetPrinterForm();
    
    alert(`✅ Impressora ${printerType === 'kitchen' ? 'da cozinha' : 'do garçom'} configurada com sucesso!`);
  };

  const handleRemovePrinter = (type: 'kitchen' | 'waiter') => {
    if (confirm(`Tem certeza que deseja remover a impressora ${type === 'kitchen' ? 'da cozinha' : 'do garçom'}?`)) {
      const updatedConfig = {
        ...config,
        printers: {
          ...config.printers,
          [type]: null
        }
      };
      setConfig(updatedConfig);
      alert(`✅ Impressora ${type === 'kitchen' ? 'da cozinha' : 'do garçom'} removida com sucesso!`);
    }
  };

  const handleTestPrinter = async (printer: PrinterConfig) => {
    setTestingPrinter(printer.id);
    
    try {
      const testContent = `
===============================
🧾 TESTE DE IMPRESSÃO
===============================
Impressora: ${printer.name}
Tipo: ${printer.type === 'kitchen' ? 'Cozinha' : 'Garçom'}
IP: ${printer.ip}:${printer.port}
Data/Hora: ${new Date().toLocaleString('pt-BR')}
===============================

✅ TESTE REALIZADO COM SUCESSO!

Se você consegue ler esta mensagem,
a impressora está funcionando 
corretamente.

🎉 Sua impressora está pronta 
   para uso no sistema.

===============================
Sistema PDV - Versão 2.0
Teste realizado em: ${new Date().toLocaleString('pt-BR')}
===============================

-------------------------------
Techno A.I Soluções Tecnológicas
(28) 98115-3400
-------------------------------
      `.trim();

      // Abrir janela de impressão para teste
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Teste de Impressão - ${printer.name}</title>
              <style>
                @page { 
                  size: 80mm auto; 
                  margin: 2mm; 
                }
                body { 
                  font-family: 'Courier New', 'Consolas', monospace; 
                  font-size: 16px; 
                  font-weight: bold;
                  margin: 0; 
                  padding: 0;
                  line-height: 1.3;
                  color: #000;
                }
                pre { 
                  white-space: pre-wrap; 
                  margin: 0; 
                  font-family: inherit;
                  font-size: inherit;
                  font-weight: inherit;
                }
                @media print {
                  body { 
                    font-size: 14px; 
                    font-weight: bold;
                    -webkit-print-color-adjust: exact;
                    print-color-adjust: exact;
                  }
                  @page {
                    margin: 0;
                  }
                }
              </style>
            </head>
            <body>
              <pre>${testContent}</pre>
            </body>
          </html>
        `);
        printWindow.document.close();
        
        setTimeout(() => {
          printWindow.print();
          setTimeout(() => printWindow.close(), 2000);
        }, 1000);
      }

      alert('✅ Teste de impressão enviado! Verifique se o recibo foi impresso na impressora.');
    } catch (error) {
      console.error('Erro no teste:', error);
      alert('❌ Erro ao testar impressora');
    } finally {
      setTestingPrinter(null);
    }
  };

  const resetPrinterForm = () => {
    setPrinterForm({
      name: '',
      ip: '',
      port: '9100'
    });
    setEditingPrinter(null);
  };

  // Testar impressora descoberta
  const testDiscoveredPrinter = async (printer: any) => {
    console.log('🧪 Testando impressora descoberta:', printer);
    
    const testContent = `
===============================
🧾 TESTE DE IMPRESSÃO AUTOMÁTICA
===============================
Impressora: ${printer.name}
IP: ${printer.ip}:${printer.port}
Tipo: ${printer.type}
Protocolo: ${printer.protocol}
Fabricante: ${printer.manufacturer}
Modelo: ${printer.model}
Data/Hora: ${new Date().toLocaleString('pt-BR')}
===============================

✅ TESTE REALIZADO COM SUCESSO!

Esta impressora foi descoberta
automaticamente na rede e está
funcionando corretamente.

🎉 Pronta para uso no sistema PDV!

===============================
Descoberta Automática - Sistema PDV
Teste realizado em: ${new Date().toLocaleString('pt-BR')}
===============================

-------------------------------
Techno A.I Soluções Tecnológicas
(28) 98115-3400
-------------------------------
    `.trim();

    try {
      const printerService = PrinterDiscoveryService.getInstance();
      const success = await printerService.testPrinter(printer.ip, printer.port, testContent);
      
      if (success) {
        alert(`✅ Teste enviado para ${printer.name}!\n\nVerifique se o recibo foi impresso.\n\nSe a impressão funcionou, você pode usar esta impressora no sistema.`);
      } else {
        alert(`❌ Falha no teste da impressora ${printer.name}\n\nPossíveis causas:\n• Impressora offline\n• Firewall bloqueando\n• Protocolo incompatível`);
      }
    } catch (error) {
      console.error('❌ Erro no teste:', error);
      alert('❌ Erro ao testar impressora');
    }
  };

  // Descobrir impressoras na rede automaticamente
  const handleDiscoverPrinters = async () => {
    setDiscoveringPrinters(true);
    console.log('🔍 Iniciando descoberta de impressoras na rede...');
    
    try {
      const printerService = PrinterDiscoveryService.getInstance();
      const printers = await printerService.discoverPrinters();
      
      console.log('🖨️ Impressoras descobertas:', printers);
      setDiscoveredPrinters(printers);
      setShowDiscoveredPrinters(true);
      
      if (printers.length === 0) {
        alert('🔍 Nenhuma impressora encontrada na rede.\n\nVerifique se:\n• As impressoras estão ligadas e conectadas\n• Estão na mesma rede WiFi/cabo\n• Possuem IP fixo configurado\n• Firewall não está bloqueando as portas\n• Impressoras suportam rede (não apenas USB)');
      } else {
        alert(`✅ ${printers.length} impressora(s) encontrada(s) na rede!\n\n🖨️ Impressoras descobertas:\n${printers.map(p => `• ${p.name} (${p.ip}:${p.port})`).join('\n')}\n\nSelecione uma das impressoras abaixo para configurar.`);
      }
    } catch (error) {
      console.error('❌ Erro na descoberta:', error);
      alert('❌ Erro ao descobrir impressoras na rede');
    } finally {
      setDiscoveringPrinters(false);
    }
  };

  // Selecionar impressora descoberta
  const handleSelectDiscoveredPrinter = (printer: any) => {
    console.log('🖨️ Selecionando impressora descoberta:', printer);
    
    setPrinterForm({
      name: printer.name,
      ip: printer.ip,
      port: printer.port.toString()
    });
    setShowDiscoveredPrinters(false);
    
    // Salvar automaticamente a impressora descoberta
    const printerService = PrinterDiscoveryService.getInstance();
    printerService.savePrinterConfig(printer, printerType);
    
    alert(`✅ Impressora selecionada e salva: ${printer.name}\n\nIP: ${printer.ip}:${printer.port}\nTipo: ${printer.type}\nProtocolo: ${printer.protocol}\n\n💾 Configuração salva automaticamente!\nVerifique os dados e clique em "Configurar" para finalizar.`);
  };

  const renderPrinterCard = (type: 'kitchen' | 'waiter', title: string, icon: React.ReactNode, description: string) => {
    const printer = config.printers[type];
    
    return (
      <Card variant="modern" className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg ${
              printer ? 'bg-gradient-to-br from-green-500 to-emerald-600' : 'bg-gradient-to-br from-slate-400 to-slate-500'
            }`}>
              {icon}
            </div>
            <div>
              <h4 className="text-lg font-bold text-slate-900">{title}</h4>
              <p className="text-sm text-slate-600">{description}</p>
            </div>
          </div>
          
          <div className={`px-3 py-1 rounded-full text-xs font-bold ${
            printer ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-600'
          }`}>
            {printer ? '✅ Configurada' : '⚪ Não configurada'}
          </div>
        </div>

        {printer ? (
          <div className="space-y-4">
            <div className="bg-slate-50 rounded-xl p-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-slate-600">Nome:</span>
                  <p className="font-bold text-slate-900">{printer.name}</p>
                </div>
                <div>
                  <span className="font-medium text-slate-600">Endereço:</span>
                  <p className="font-bold text-slate-900">{printer.ip}:{printer.port}</p>
                </div>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button
                variant="outline"
                size="sm"
                icon={TestTube}
                onClick={() => handleTestPrinter(printer)}
                loading={testingPrinter === printer.id}
                rounded="xl"
                fullWidth
              >
                {testingPrinter === printer.id ? 'Testando...' : 'Testar'}
              </Button>
              <Button
                variant="outline"
                size="sm"
                icon={Settings}
                onClick={() => handleEditPrinter(printer)}
                rounded="xl"
                fullWidth
              >
                Editar
              </Button>
              <Button
                variant="danger"
                size="sm"
                icon={Trash2}
                onClick={() => handleRemovePrinter(type)}
                rounded="xl"
              >
                Remover
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-slate-500 mb-4">Nenhuma impressora configurada</p>
            <Button
              variant="primary"
              icon={Plus}
              onClick={() => handleAddPrinter(type)}
              rounded="xl"
              className="bg-gradient-to-r from-blue-600 to-purple-600"
            >
              Configurar Impressora
            </Button>
          </div>
        )}
      </Card>
    );
  };

  // Verificar se há erro no estado
  if (!state || !state.config) {
    return (
      <div className="space-y-8">
        <Card variant="modern" className="p-8 text-center">
          <div className="w-16 h-16 text-yellow-500 mx-auto mb-4">⚠️</div>
          <h3 className="text-xl font-bold text-slate-900 mb-2">
            Erro ao carregar configurações
          </h3>
          <p className="text-slate-600">
            Não foi possível carregar as configurações do sistema.
          </p>
        </Card>
      </div>
    );
  }

  try {
    return (
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-4xl font-black bg-gradient-to-r from-slate-900 via-blue-900 to-indigo-900 bg-clip-text text-transparent">
              Configurações do Sistema
            </h2>
            <p className="text-slate-600 mt-2 text-lg">Configure sua empresa e impressoras de rede</p>
          </div>
          <Button
            variant="primary"
            icon={Save}
            onClick={handleSave}
            loading={saving}
            rounded="xl"
            className="bg-gradient-to-r from-blue-600 to-purple-600"
          >
            Salvar Configurações
          </Button>
        </div>

        {/* Company Configuration */}
        <Card variant="modern" animated>
          <div className="flex items-center mb-8">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg mr-4">
              <Building className="w-7 h-7 text-white" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-slate-900">
                Dados da Empresa
              </h3>
              <p className="text-slate-600">Informações que aparecerão nos recibos</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input
              label="Nome Fantasia"
              placeholder="Ex: Restaurante D'Angeles"
              value={config.company?.nomeFantasia || ''}
              onChange={(value) => handleCompanyChange('nomeFantasia', value)}
              fullWidth
              required
              variant="modern"
            />
            
            <Input
              label="Razão Social"
              placeholder="Ex: D'Angeles Restaurante Ltda"
              value={config.company?.razaoSocial || ''}
              onChange={(value) => handleCompanyChange('razaoSocial', value)}
              fullWidth
              variant="modern"
            />
            
            <Input
              label="CNPJ"
              placeholder="XX.XXX.XXX/XXXX-XX"
              value={config.company?.cnpj || ''}
              onChange={(value) => handleCompanyChange('cnpj', value)}
              fullWidth
              variant="modern"
            />
            
            <div className="md:col-span-2">
              <Input
                label="Endereço"
                placeholder="Rua, número, bairro, cidade/estado"
                value={config.company?.endereco || ''}
                onChange={(value) => handleCompanyChange('endereco', value)}
                fullWidth
                variant="modern"
              />
            </div>
          </div>
        </Card>

        {/* Printer Configuration */}
        <Card variant="modern" animated>
          <div className="flex items-center mb-8">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg mr-4">
              <Printer className="w-7 h-7 text-white" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-slate-900">
                Configuração de Impressoras de Rede
              </h3>
              <p className="text-slate-600">Configure impressoras para cozinha e garçom via IP</p>
            </div>
          </div>

          {/* Instructions */}
          <Card variant="modern" className="mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0">
                <Wifi className="w-6 h-6 text-white" />
              </div>
              <div>
                <h4 className="font-bold text-blue-900 mb-3 text-lg">🌐 Como configurar impressoras de rede:</h4>
                <div className="space-y-2 text-sm text-blue-700">
                  <p>• <strong>Impressora da Cozinha:</strong> Recebe automaticamente os novos pedidos enviados pelos garçons</p>
                  <p>• <strong>Impressora do Garçom:</strong> Imprime prévias de consumo quando solicitado pelo garçom ou caixa</p>
                  <p>• <strong>Configuração:</strong> Conecte a impressora na mesma rede WiFi e configure um IP fixo</p>
                  <p>• <strong>Portas comuns:</strong> 9100 (Raw), 631 (IPP), 515 (LPR)</p>
                  <p>• <strong>Teste:</strong> Use o botão "Testar" para verificar se a impressora está funcionando</p>
                </div>
              </div>
            </div>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Kitchen Printer */}
            {renderPrinterCard(
              'kitchen',
              '🍳 Impressora da Cozinha',
              <Printer className="w-6 h-6 text-white" />,
              'Imprime automaticamente novos pedidos'
            )}

            {/* Waiter Printer */}
            {renderPrinterCard(
              'waiter',
              '👨‍💼 Impressora do Garçom',
              <Printer className="w-6 h-6 text-white" />,
              'Imprime prévias de consumo das comandas'
            )}
          </div>
        </Card>

        {/* System Info */}
        <Card variant="modern" animated>
          <h3 className="text-2xl font-bold text-slate-900 mb-8">
            Informações do Sistema
          </h3>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="text-center p-6 bg-gradient-to-br from-slate-50 to-slate-100 rounded-2xl border border-slate-200">
              <p className="text-slate-600 text-sm font-bold uppercase tracking-wide">Versão</p>
              <p className="font-black text-slate-900 text-2xl">2.0.0</p>
            </div>
            
            <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl border border-blue-200">
              <p className="text-blue-600 text-sm font-bold uppercase tracking-wide">Pedidos</p>
              <p className="font-black text-blue-900 text-2xl">{state.orders?.length || 0}</p>
            </div>
            
            <div className="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-100 rounded-2xl border border-green-200">
              <p className="text-green-600 text-sm font-bold uppercase tracking-wide">Produtos</p>
              <p className="font-black text-green-900 text-2xl">{state.products?.length || 0}</p>
            </div>
            
            <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-pink-100 rounded-2xl border border-purple-200">
              <p className="text-purple-600 text-sm font-bold uppercase tracking-wide">Usuários</p>
              <p className="font-black text-purple-900 text-2xl">{state.users?.filter(u => u.active).length || 0}</p>
            </div>
            
            <div className="text-center p-6 bg-gradient-to-br from-amber-50 to-yellow-100 rounded-2xl border border-amber-200">
              <p className="text-amber-600 text-sm font-bold uppercase tracking-wide">Mesas</p>
              <p className="font-black text-amber-900 text-2xl">{state.tables?.length || 0}</p>
            </div>
            
            <div className="text-center p-6 bg-gradient-to-br from-orange-50 to-red-100 rounded-2xl border border-orange-200">
              <p className="text-orange-600 text-sm font-bold uppercase tracking-wide">Ocupadas</p>
              <p className="font-black text-orange-900 text-2xl">{state.tables?.filter(t => t.status === 'ocupada').length || 0}</p>
            </div>
            
            <div className="text-center p-6 bg-gradient-to-br from-teal-50 to-cyan-100 rounded-2xl border border-teal-200">
              <p className="text-teal-600 text-sm font-bold uppercase tracking-wide">Impressoras</p>
              <p className="font-black text-teal-900 text-2xl">
                {(config.printers.kitchen ? 1 : 0) + (config.printers.waiter ? 1 : 0)}
              </p>
            </div>
            
            <div className="text-center p-6 bg-gradient-to-br from-emerald-50 to-green-100 rounded-2xl border border-emerald-200">
              <p className="text-emerald-600 text-sm font-bold uppercase tracking-wide">Receita Hoje</p>
              <p className="font-black text-emerald-900 text-lg">
                R$ {state.orders?.filter(o => {
                  const today = new Date().toDateString();
                  return new Date(o.createdAt).toDateString() === today && o.status === 'fechado';
                }).reduce((sum, order) => sum + order.total, 0).toFixed(2) || '0.00'}
              </p>
            </div>
          </div>
        </Card>

        {/* Printer Configuration Modal */}
        <Modal
          isOpen={showPrinterModal}
          onClose={() => {
            setShowPrinterModal(false);
            setShowDiscoveredPrinters(false);
            resetPrinterForm();
          }}
          title={`${editingPrinter ? 'Editar' : 'Configurar'} Impressora ${printerType === 'kitchen' ? 'da Cozinha' : 'do Garçom'}`}
          size="lg"
          variant="modern"
        >
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
                <Printer className="w-8 h-8 text-white" />
              </div>
              <p className="text-slate-600">
                Configure uma impressora de rede para {printerType === 'kitchen' ? 'receber pedidos da cozinha' : 'imprimir prévias de consumo'}
              </p>
            </div>

            {/* Descoberta Automática de Impressoras */}
            <Card variant="modern" className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                    <Search className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h4 className="font-bold text-blue-900 text-lg">🔍 Descoberta Automática</h4>
                    <p className="text-sm text-blue-700">
                      Encontre impressoras conectadas na mesma rede automaticamente
                    </p>
                  </div>
                </div>
                <Button
                  variant="primary"
                  icon={discoveringPrinters ? RefreshCw : Search}
                  onClick={handleDiscoverPrinters}
                  loading={discoveringPrinters}
                  rounded="xl"
                  className="bg-gradient-to-r from-blue-600 to-indigo-600"
                >
                  {discoveringPrinters ? 'Descobrindo...' : 'Descobrir Impressoras'}
                </Button>
              </div>
            </Card>

            {/* Lista de Impressoras Descobertas */}
            {showDiscoveredPrinters && discoveredPrinters.length > 0 && (
              <Card variant="modern" className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
                <h4 className="font-bold text-green-900 mb-4 flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  🖨️ Impressoras Encontradas na Rede
                </h4>
                <div className="space-y-3">
                  {discoveredPrinters.map((printer, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-4 bg-white rounded-xl border border-green-200 hover:shadow-lg transition-all duration-300 hover:scale-[1.02]"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                          <Printer className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <p className="font-bold text-green-900 text-lg">{printer.name}</p>
                          <p className="text-sm text-green-700">
                            📍 {printer.ip}:{printer.port}
                          </p>
                          <p className="text-xs text-green-600">
                            🔧 {printer.type} • {printer.protocol} • {printer.manufacturer}
                          </p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          icon={TestTube}
                          onClick={() => testDiscoveredPrinter(printer)}
                          rounded="xl"
                        >
                          Testar
                        </Button>
                        <Button
                          variant="success"
                          size="sm"
                          onClick={() => handleSelectDiscoveredPrinter(printer)}
                          rounded="xl"
                          className="bg-gradient-to-r from-green-600 to-emerald-600"
                        >
                          Usar Esta
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 p-4 bg-green-100 rounded-xl">
                  <p className="text-sm text-green-700">
                    💡 <strong>Como usar:</strong><br/>
                    • <strong>Testar:</strong> Envia um teste de impressão<br/>
                    • <strong>Usar Esta:</strong> Configura automaticamente esta impressora<br/>
                    • <strong>Salvo automaticamente:</strong> Não precisa configurar novamente
                  </p>
                </div>
              </Card>
            )}

            <Input
              label="Nome da Impressora"
              placeholder="Ex: Impressora Térmica Cozinha"
              value={printerForm.name}
              onChange={(value) => setPrinterForm({ ...printerForm, name: value })}
              fullWidth
              required
              variant="modern"
            />

            <Input
              label="Endereço IP"
              placeholder="Ex: 192.168.1.100"
              value={printerForm.ip}
              onChange={(value) => setPrinterForm({ ...printerForm, ip: value })}
              fullWidth
              required
              variant="modern"
            />

            <Input
              label="Porta"
              placeholder="Ex: 9100"
              value={printerForm.port}
              onChange={(value) => setPrinterForm({ ...printerForm, port: value })}
              fullWidth
              required
              variant="modern"
            />

            <Card variant="modern" className="bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-200">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">💡</span>
                </div>
                <div>
                  <p className="text-sm font-bold text-yellow-900">Dicas de configuração:</p>
                  <ul className="text-xs text-yellow-700 mt-1 space-y-1">
                    <li>• Configure um IP fixo na impressora</li>
                    <li>• Porta 9100 é a mais comum para impressoras térmicas</li>
                    <li>• Certifique-se que a impressora está na mesma rede</li>
                  </ul>
                </div>
              </div>
            </Card>

            <div className="flex space-x-3 pt-4">
              <Button
                variant="outline"
                fullWidth
                onClick={() => {
                  setShowPrinterModal(false);
                  resetPrinterForm();
                }}
                rounded="xl"
              >
                Cancelar
              </Button>
              <Button
                variant="primary"
                fullWidth
                onClick={handleSavePrinter}
                rounded="xl"
                className="bg-gradient-to-r from-purple-600 to-pink-600"
              >
                {editingPrinter ? 'Atualizar' : 'Configurar'}
              </Button>
            </div>
          </div>
        </Modal>
      </div>
    );
  } catch (error) {
    console.error('Erro ao renderizar SystemConfig:', error);
    return (
      <div className="space-y-8">
        <Card variant="modern" className="p-8 text-center bg-red-50 border-red-200">
          <div className="w-16 h-16 text-red-500 mx-auto mb-4">⚠️</div>
          <h3 className="text-xl font-bold text-red-900 mb-2">
            Erro na página de configurações
          </h3>
          <p className="text-red-700 mb-4">
            Ocorreu um erro ao carregar a página de configurações.
          </p>
          <Button 
            variant="outline" 
            onClick={() => window.location.reload()}
            className="border-red-300 text-red-700 hover:bg-red-50"
          >
            Recarregar Página
          </Button>
        </Card>
      </div>
    );
  }
}