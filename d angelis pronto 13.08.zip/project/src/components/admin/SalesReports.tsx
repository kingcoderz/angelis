import React, { useState, useMemo } from 'react';
import { Calendar, Download, DollarSign, TrendingUp, ShoppingCart, Printer, FileText, Share2 } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Order } from '../../types';

export function SalesReports() {
  const { state } = useApp();
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [paymentFilter, setPaymentFilter] = useState<string>('all');

  const filteredOrders = useMemo(() => {
    return state.orders.filter(order => {
      // Incluir pedidos fechados OU com pagamentos parciais
      if (order.status !== 'fechado' && (!order.paidTotal || order.paidTotal <= 0)) return false;
      
      const orderDate = new Date(order.closedAt || order.createdAt).toISOString().split('T')[0];
      const isInDateRange = orderDate >= startDate && orderDate <= endDate;
      
      const matchesPayment = paymentFilter === 'all' || order.paymentMethod === paymentFilter;
      
      return isInDateRange && matchesPayment;
    });
  }, [state.orders, startDate, endDate, paymentFilter]);

  const statistics = useMemo(() => {
    // Calcular receita considerando pagamentos parciais
    const totalRevenue = filteredOrders.reduce((sum, order) => {
      if (order.status === 'fechado') {
        return sum + order.total;
      }
      // Para pedidos com pagamentos parciais, usar apenas o valor pago
      return sum + (order.paidTotal || 0);
    }, 0);
    
    const totalOrders = filteredOrders.length;
    const averageOrderValue = totalOrders > 0 ? totalRevenue / totalOrders : 0;
    
    const paymentMethodStats = {
      dinheiro: filteredOrders.filter(o => o.paymentMethod === 'dinheiro').length,
      pix: filteredOrders.filter(o => o.paymentMethod === 'pix').length,
      cartao: filteredOrders.filter(o => o.paymentMethod === 'cartao').length,
    };

    const paymentMethodRevenue = {
      dinheiro: filteredOrders.filter(o => o.paymentMethod === 'dinheiro').reduce((sum, o) => sum + o.total, 0),
      pix: filteredOrders.filter(o => o.paymentMethod === 'pix').reduce((sum, o) => sum + o.total, 0),
      cartao: filteredOrders.filter(o => o.paymentMethod === 'cartao').reduce((sum, o) => sum + o.total, 0),
    };

    const dailyStats = filteredOrders.reduce((acc, order) => {
      const date = new Date(order.closedAt || order.createdAt).toISOString().split('T')[0];
      if (!acc[date]) {
        acc[date] = { revenue: 0, orders: 0 };
      }
      acc[date].revenue += order.total;
      acc[date].orders += 1;
      return acc;
    }, {} as Record<string, { revenue: number; orders: number }>);

    // Estatísticas por garçom
    const waiterStats = filteredOrders.reduce((acc, order) => {
      if (!acc[order.waiterName]) {
        acc[order.waiterName] = { orders: 0, revenue: 0 };
      }
      acc[order.waiterName].orders += 1;
      acc[order.waiterName].revenue += order.total;
      return acc;
    }, {} as Record<string, { orders: number; revenue: number }>);

    // Produtos mais vendidos
    const productStats = filteredOrders.reduce((acc, order) => {
      order.items.forEach(item => {
        if (!acc[item.productName]) {
          acc[item.productName] = { quantity: 0, revenue: 0 };
        }
        acc[item.productName].quantity += item.quantity;
        acc[item.productName].revenue += item.price * item.quantity;
      });
      return acc;
    }, {} as Record<string, { quantity: number; revenue: number }>);

    return {
      totalRevenue,
      totalOrders,
      averageOrderValue,
      paymentMethodStats,
      paymentMethodRevenue,
      dailyStats,
      waiterStats,
      productStats,
    };
  }, [filteredOrders]);

  const exportToCSV = () => {
    const headers = ['Data', 'Mesa', 'Cliente', 'Total', 'Pagamento', 'Garçom'];
    const rows = filteredOrders.map(order => [
      new Date(order.closedAt || order.createdAt).toLocaleDateString(),
      order.tableNumber,
      order.customers.map(c => c.name).join('; '),
      `R$ ${order.total.toFixed(2)}`,
      order.paymentMethod === 'dinheiro' ? 'Dinheiro' : 
      order.paymentMethod === 'pix' ? 'PIX' : 
      order.paymentMethod === 'cartao' ? 'Cartão' : 'N/A',
      order.waiterName,
    ]);

    const csvContent = [headers, ...rows]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `relatorio-vendas-${startDate}-${endDate}.csv`);
    link.click();
  };

  const printReport = () => {
    const company = state.config.company;
    const reportContent = generatePrintableReport();
    
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Relatório de Vendas - ${company.nomeFantasia}</title>
            <style>
              @page { 
                size: A4; 
                margin: 20mm; 
              }
              body { 
                font-family: 'Arial', sans-serif; 
                font-size: 12px; 
                margin: 0; 
                padding: 0;
                line-height: 1.4;
                color: #000;
              }
              .header {
                text-align: center;
                border-bottom: 2px solid #333;
                padding-bottom: 20px;
                margin-bottom: 30px;
              }
              .company-name {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 5px;
              }
              .company-info {
                font-size: 11px;
                color: #666;
                margin-bottom: 10px;
              }
              .report-title {
                font-size: 18px;
                font-weight: bold;
                margin-top: 15px;
              }
              .period {
                font-size: 14px;
                color: #666;
                margin-top: 5px;
              }
              .section {
                margin-bottom: 30px;
              }
              .section-title {
                font-size: 16px;
                font-weight: bold;
                border-bottom: 1px solid #ccc;
                padding-bottom: 5px;
                margin-bottom: 15px;
                color: #333;
              }
              .stats-grid {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 20px;
                margin-bottom: 20px;
              }
              .stat-card {
                border: 1px solid #ddd;
                padding: 15px;
                border-radius: 5px;
                text-align: center;
              }
              .stat-label {
                font-size: 11px;
                color: #666;
                text-transform: uppercase;
                margin-bottom: 5px;
              }
              .stat-value {
                font-size: 20px;
                font-weight: bold;
                color: #333;
              }
              table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
              }
              th, td {
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
                font-size: 11px;
              }
              th {
                background-color: #f5f5f5;
                font-weight: bold;
              }
              .text-right {
                text-align: right;
              }
              .footer {
                margin-top: 40px;
                padding-top: 20px;
                border-top: 1px solid #ccc;
                text-align: center;
                font-size: 10px;
                color: #666;
              }
              @media print {
                body { 
                  font-size: 11px; 
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                .no-print {
                  display: none;
                }
              }
            </style>
          </head>
          <body>
            ${reportContent}
          </body>
        </html>
      `);
      printWindow.document.close();
      
      setTimeout(() => {
        printWindow.print();
        setTimeout(() => printWindow.close(), 2000);
      }, 1000);
    }
  };

  const generatePrintableReport = () => {
    const company = state.config.company;
    const formatDate = (date: string) => new Date(date).toLocaleDateString('pt-BR');
    const formatCurrency = (value: number) => `R$ ${value.toFixed(2)}`;
    
    return `
      <div class="header">
        <div class="company-name">${company.nomeFantasia}</div>
        <div class="company-info">
          ${company.razaoSocial}<br>
          CNPJ: ${company.cnpj}<br>
          ${company.endereco}
        </div>
        <div class="report-title">RELATÓRIO DE VENDAS</div>
        <div class="period">Período: ${formatDate(startDate)} a ${formatDate(endDate)}</div>
        <div class="period">Gerado em: ${new Date().toLocaleString('pt-BR')}</div>
      </div>

      <div class="section">
        <div class="section-title">RESUMO GERAL</div>
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-label">Total de Pedidos</div>
            <div class="stat-value">${statistics.totalOrders}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Receita Total</div>
            <div class="stat-value">${formatCurrency(statistics.totalRevenue)}</div>
          </div>
          <div class="stat-card">
            <div class="stat-label">Ticket Médio</div>
            <div class="stat-value">${formatCurrency(statistics.averageOrderValue)}</div>
          </div>
        </div>
      </div>

      <div class="section">
        <div class="section-title">VENDAS POR FORMA DE PAGAMENTO</div>
        <table>
          <thead>
            <tr>
              <th>Forma de Pagamento</th>
              <th class="text-right">Quantidade</th>
              <th class="text-right">Receita</th>
              <th class="text-right">% do Total</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>💵 Dinheiro</td>
              <td class="text-right">${statistics.paymentMethodStats.dinheiro}</td>
              <td class="text-right">${formatCurrency(statistics.paymentMethodRevenue.dinheiro)}</td>
              <td class="text-right">${statistics.totalRevenue > 0 ? ((statistics.paymentMethodRevenue.dinheiro / statistics.totalRevenue) * 100).toFixed(1) : 0}%</td>
            </tr>
            <tr>
              <td>📱 PIX</td>
              <td class="text-right">${statistics.paymentMethodStats.pix}</td>
              <td class="text-right">${formatCurrency(statistics.paymentMethodRevenue.pix)}</td>
              <td class="text-right">${statistics.totalRevenue > 0 ? ((statistics.paymentMethodRevenue.pix / statistics.totalRevenue) * 100).toFixed(1) : 0}%</td>
            </tr>
            <tr>
              <td>💳 Cartão</td>
              <td class="text-right">${statistics.paymentMethodStats.cartao}</td>
              <td class="text-right">${formatCurrency(statistics.paymentMethodRevenue.cartao)}</td>
              <td class="text-right">${statistics.totalRevenue > 0 ? ((statistics.paymentMethodRevenue.cartao / statistics.totalRevenue) * 100).toFixed(1) : 0}%</td>
            </tr>
          </tbody>
        </table>
      </div>

      <div class="section">
        <div class="section-title">VENDAS DIÁRIAS</div>
        <table>
          <thead>
            <tr>
              <th>Data</th>
              <th class="text-right">Pedidos</th>
              <th class="text-right">Receita</th>
              <th class="text-right">Ticket Médio</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(statistics.dailyStats)
              .sort(([a], [b]) => b.localeCompare(a))
              .map(([date, stats]) => `
                <tr>
                  <td>${formatDate(date)}</td>
                  <td class="text-right">${stats.orders}</td>
                  <td class="text-right">${formatCurrency(stats.revenue)}</td>
                  <td class="text-right">${formatCurrency(stats.revenue / stats.orders)}</td>
                </tr>
              `).join('')}
          </tbody>
        </table>
      </div>

      <div class="section">
        <div class="section-title">PERFORMANCE POR GARÇOM</div>
        <table>
          <thead>
            <tr>
              <th>Garçom</th>
              <th class="text-right">Pedidos</th>
              <th class="text-right">Receita</th>
              <th class="text-right">Ticket Médio</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(statistics.waiterStats)
              .sort(([,a], [,b]) => b.revenue - a.revenue)
              .map(([waiter, stats]) => `
                <tr>
                  <td>${waiter}</td>
                  <td class="text-right">${stats.orders}</td>
                  <td class="text-right">${formatCurrency(stats.revenue)}</td>
                  <td class="text-right">${formatCurrency(stats.revenue / stats.orders)}</td>
                </tr>
              `).join('')}
          </tbody>
        </table>
      </div>

      <div class="section">
        <div class="section-title">PRODUTOS MAIS VENDIDOS</div>
        <table>
          <thead>
            <tr>
              <th>Produto</th>
              <th class="text-right">Quantidade</th>
              <th class="text-right">Receita</th>
              <th class="text-right">% da Receita</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(statistics.productStats)
              .sort(([,a], [,b]) => b.revenue - a.revenue)
              .slice(0, 10)
              .map(([product, stats]) => `
                <tr>
                  <td>${product}</td>
                  <td class="text-right">${stats.quantity}</td>
                  <td class="text-right">${formatCurrency(stats.revenue)}</td>
                  <td class="text-right">${statistics.totalRevenue > 0 ? ((stats.revenue / statistics.totalRevenue) * 100).toFixed(1) : 0}%</td>
                </tr>
              `).join('')}
          </tbody>
        </table>
      </div>

      <div class="section">
        <div class="section-title">PEDIDOS DETALHADOS</div>
        <table>
          <thead>
            <tr>
              <th>Data/Hora</th>
              <th>Mesa</th>
              <th>Cliente(s)</th>
              <th>Garçom</th>
              <th class="text-right">Total</th>
              <th>Pagamento</th>
            </tr>
          </thead>
          <tbody>
            ${filteredOrders
              .sort((a, b) => new Date(b.closedAt || b.createdAt).getTime() - new Date(a.closedAt || a.createdAt).getTime())
              .map(order => `
                <tr>
                  <td>${new Date(order.closedAt || order.createdAt).toLocaleString('pt-BR')}</td>
                  <td>${order.tableNumber}</td>
                  <td>${order.customers.map(c => c.name).join(', ')}</td>
                  <td>${order.waiterName}</td>
                  <td class="text-right">${formatCurrency(order.total)}</td>
                  <td>${order.paymentMethod === 'dinheiro' ? 'Dinheiro' : 
                         order.paymentMethod === 'pix' ? 'PIX' : 
                         order.paymentMethod === 'cartao' ? 'Cartão' : 'N/A'}</td>
                </tr>
              `).join('')}
          </tbody>
        </table>
      </div>

      <div class="footer">
        <p>Relatório gerado automaticamente pelo Sistema PDV - ${company.nomeFantasia}</p>
        <p>Data de geração: ${new Date().toLocaleString('pt-BR')}</p>
      </div>
    `;
  };

  const shareReport = async () => {
    const reportData = {
      periodo: `${startDate} a ${endDate}`,
      totalPedidos: statistics.totalOrders,
      receitaTotal: statistics.totalRevenue,
      ticketMedio: statistics.averageOrderValue,
      pagamentos: statistics.paymentMethodStats,
    };

    const shareText = `📊 Relatório de Vendas - ${state.config.company.nomeFantasia}

📅 Período: ${new Date(startDate).toLocaleDateString('pt-BR')} a ${new Date(endDate).toLocaleDateString('pt-BR')}

📈 Resumo:
• Total de Pedidos: ${statistics.totalOrders}
• Receita Total: R$ ${statistics.totalRevenue.toFixed(2)}
• Ticket Médio: R$ ${statistics.averageOrderValue.toFixed(2)}

💳 Formas de Pagamento:
• Dinheiro: ${statistics.paymentMethodStats.dinheiro} pedidos
• PIX: ${statistics.paymentMethodStats.pix} pedidos  
• Cartão: ${statistics.paymentMethodStats.cartao} pedidos

🎯 Gerado em: ${new Date().toLocaleString('pt-BR')}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Relatório de Vendas',
          text: shareText,
        });
      } catch (error) {
        console.log('Compartilhamento cancelado');
      }
    } else {
      // Fallback: copiar para clipboard
      try {
        await navigator.clipboard.writeText(shareText);
        alert('📋 Relatório copiado para a área de transferência!');
      } catch (error) {
        console.error('Erro ao copiar:', error);
        alert('❌ Erro ao copiar relatório');
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Relatórios de Vendas</h2>
        <div className="flex space-x-3">
          <Button
            variant="outline"
            icon={Share2}
            onClick={shareReport}
            rounded="xl"
          >
            Compartilhar
          </Button>
          <Button
            variant="outline"
            icon={Printer}
            onClick={printReport}
            rounded="xl"
          >
            Imprimir
          </Button>
          <Button
            variant="outline"
            icon={Download}
            onClick={exportToCSV}
            rounded="xl"
          >
            Exportar CSV
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Filtros</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Input
            label="Data Inicial"
            type="date"
            value={startDate}
            onChange={setStartDate}
            fullWidth
          />
          
          <Input
            label="Data Final"
            type="date"
            value={endDate}
            onChange={setEndDate}
            fullWidth
          />
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Forma de Pagamento
            </label>
            <select
              value={paymentFilter}
              onChange={(e) => setPaymentFilter(e.target.value)}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
            >
              <option value="all">Todas</option>
              <option value="dinheiro">Dinheiro</option>
              <option value="pix">PIX</option>
              <option value="cartao">Cartão</option>
            </select>
          </div>

          <div className="flex items-end">
            <Button
              variant="primary"
              icon={FileText}
              onClick={printReport}
              fullWidth
              rounded="xl"
            >
              Gerar Relatório
            </Button>
          </div>
        </div>
      </Card>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="p-6">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 rounded-lg">
              <DollarSign className="w-8 h-8 text-green-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Receita Total</p>
              <p className="text-3xl font-bold text-gray-900">
                R$ {statistics.totalRevenue.toFixed(2)}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 rounded-lg">
              <ShoppingCart className="w-8 h-8 text-blue-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Total de Pedidos</p>
              <p className="text-3xl font-bold text-gray-900">
                {statistics.totalOrders}
              </p>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 rounded-lg">
              <TrendingUp className="w-8 h-8 text-purple-600" />
            </div>
            <div className="ml-4">
              <p className="text-sm font-medium text-gray-600">Ticket Médio</p>
              <p className="text-3xl font-bold text-gray-900">
                R$ {statistics.averageOrderValue.toFixed(2)}
              </p>
            </div>
          </div>
        </Card>
      </div>

      {/* Payment Methods Stats */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Vendas por Forma de Pagamento
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-sm text-gray-600">💵 Dinheiro</p>
            <p className="text-2xl font-bold text-green-600">
              {statistics.paymentMethodStats.dinheiro}
            </p>
            <p className="text-sm text-green-600 font-medium">
              R$ {statistics.paymentMethodRevenue.dinheiro.toFixed(2)}
            </p>
          </div>
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <p className="text-sm text-gray-600">📱 PIX</p>
            <p className="text-2xl font-bold text-blue-600">
              {statistics.paymentMethodStats.pix}
            </p>
            <p className="text-sm text-blue-600 font-medium">
              R$ {statistics.paymentMethodRevenue.pix.toFixed(2)}
            </p>
          </div>
          <div className="text-center p-4 bg-purple-50 rounded-lg">
            <p className="text-sm text-gray-600">💳 Cartão</p>
            <p className="text-2xl font-bold text-purple-600">
              {statistics.paymentMethodStats.cartao}
            </p>
            <p className="text-sm text-purple-600 font-medium">
              R$ {statistics.paymentMethodRevenue.cartao.toFixed(2)}
            </p>
          </div>
        </div>
      </Card>

      {/* Performance por Garçom */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Performance por Garçom
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Garçom
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pedidos
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Receita
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ticket Médio
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {Object.entries(statistics.waiterStats)
                .sort(([,a], [,b]) => b.revenue - a.revenue)
                .map(([waiter, stats]) => (
                <tr key={waiter}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {waiter}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {stats.orders}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    R$ {stats.revenue.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    R$ {(stats.revenue / stats.orders).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Daily Sales */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Vendas Diárias
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pedidos
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Receita
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Ticket Médio
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {Object.entries(statistics.dailyStats)
                .sort(([a], [b]) => b.localeCompare(a))
                .map(([date, stats]) => (
                <tr key={date}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {new Date(date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {stats.orders}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    R$ {stats.revenue.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    R$ {(stats.revenue / stats.orders).toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Recent Orders */}
      <Card>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Pedidos Recentes
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Data/Hora
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Mesa
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Cliente
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Total
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Pagamento
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Garçom
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredOrders
                .sort((a, b) => new Date(b.closedAt || b.createdAt).getTime() - new Date(a.closedAt || a.createdAt).getTime())
                .slice(0, 10)
                .map((order) => (
                <tr key={order.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(order.closedAt || order.createdAt).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {order.tableNumber}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {order.customers.map(c => c.name).join(', ')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    R$ {order.total.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {order.paymentMethod === 'dinheiro' ? '💵 Dinheiro' : 
                     order.paymentMethod === 'pix' ? '📱 PIX' : 
                     order.paymentMethod === 'cartao' ? '💳 Cartão' : 'N/A'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {order.waiterName}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}