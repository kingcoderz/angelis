import React, { useState } from 'react';
import { CreditCard, DollarSign, Smartphone, User, CheckCircle } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Customer, Table } from '../../types';

interface IndividualPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  table: Table | null;
  customer: Customer | null;
  onSuccess: () => void;
}

export function IndividualPaymentModal({ 
  isOpen, 
  onClose, 
  table, 
  customer, 
  onSuccess 
}: IndividualPaymentModalProps) {
  const { processIndividualPayment } = useApp();
  const [paymentMethod, setPaymentMethod] = useState<'dinheiro' | 'pix' | 'cartao'>('dinheiro');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!table || !customer) return null;

  const amountToPay = customer.totalAmount - customer.paidAmount;
  const isAlreadyPaid = customer.paidAmount >= customer.totalAmount;

  const handlePayment = async () => {
    if (isAlreadyPaid || amountToPay <= 0) return;

    setIsProcessing(true);
    console.log('💳 Iniciando pagamento individual...', {
      mesa: table.number,
      cliente: customer.name,
      valor: amountToPay,
      formaPagamento: paymentMethod
    });

    try {
      // Processar pagamento
      await processIndividualPayment(table.id, customer.id, paymentMethod);
      
      console.log('✅ Pagamento processado com sucesso');
      
      // Gerar recibo individual
      printIndividualReceipt();
      
      // Mostrar feedback de sucesso
      alert(`✅ Pagamento processado com sucesso!\n\nCliente: ${customer.name}\nValor: R$ ${amountToPay.toFixed(2)}\nForma: ${paymentMethod === 'dinheiro' ? 'Dinheiro' : paymentMethod === 'pix' ? 'PIX' : 'Cartão'}\n\n🧾 Recibo individual foi gerado!`);
      
      // Chamar callback de sucesso
      onSuccess();
      
      // Fechar modal após um pequeno delay para garantir que o estado foi atualizado
      setTimeout(() => {
        handleClose();
      }, 500);
      
    } catch (error) {
      console.error('❌ Erro ao processar pagamento:', error);
      alert('❌ Erro ao processar pagamento. Tente novamente.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClose = () => {
    console.log('🔄 Fechando modal de pagamento individual');
    setPaymentMethod('dinheiro'); // Reset form
    onClose();
  };

  const printIndividualReceipt = () => {
    const receiptContent = `
RESTAURANTE D'ANGELES
-------------------------------
RECIBO INDIVIDUAL
-------------------------------
Mesa: ${table.number}
Cliente: ${customer.name}
Data/Hora: ${new Date().toLocaleString('pt-BR')}

ITENS CONSUMIDOS:
${customer.items.map(item => 
  `${item.quantity}x ${item.productName} ........ R$ ${(item.price * item.quantity).toFixed(2)}`
).join('\n')}

-------------------------------
Subtotal: .............. R$ ${customer.totalAmount.toFixed(2)}
Valor Pago: ............ R$ ${amountToPay.toFixed(2)}
Forma de Pagamento: .... ${paymentMethod === 'dinheiro' ? 'Dinheiro' : 
                          paymentMethod === 'pix' ? 'PIX' : 'Cartão'}

*** PAGAMENTO INDIVIDUAL ***
*** CLIENTE QUITADO ***
-------------------------------
Obrigado pela preferência!

-------------------------------
Techno A.I Soluções Tecnológicas
(28) 98115-3400
-------------------------------
    `.trim();

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Recibo Individual - ${customer.name}</title>
            <style>
              @page { 
                size: 80mm auto; 
                margin: 2mm; 
              }
              body { 
                font-family: 'Courier New', 'Consolas', monospace; 
                font-size: 16px; 
                font-weight: bold;
                margin: 0; 
                padding: 0;
                line-height: 1.3;
                color: #000;
              }
              pre { 
                white-space: pre-wrap; 
                margin: 0; 
                font-family: inherit;
                font-size: inherit;
                font-weight: inherit;
              }
              @media print {
                body { 
                  font-size: 14px; 
                  font-weight: bold;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                @page {
                  margin: 0;
                }
              }
            </style>
          </head>
          <body>
            <pre>${receiptContent}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      
      setTimeout(() => {
        printWindow.print();
        setTimeout(() => printWindow.close(), 2000);
      }, 1000);
    }
  };

  const paymentOptions = [
    { id: 'dinheiro', label: 'Dinheiro', icon: DollarSign, color: 'text-green-600 bg-green-100' },
    { id: 'pix', label: 'PIX', icon: Smartphone, color: 'text-blue-600 bg-blue-100' },
    { id: 'cartao', label: 'Cartão', icon: CreditCard, color: 'text-purple-600 bg-purple-100' },
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={handleClose}
      title={`Pagamento Individual - ${customer.name}`}
      size="md"
      variant="modern"
    >
      <div className="space-y-6">
        {/* Customer Info */}
        <Card variant="modern" className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center shadow-lg">
              <User className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h4 className="text-lg font-bold text-blue-900">
                Mesa {table.number} - {customer.name}
              </h4>
              <p className="text-sm text-blue-700">
                {customer.items.length} item(s) consumido(s)
              </p>
            </div>
          </div>
        </Card>

        {/* Payment Status */}
        {isAlreadyPaid ? (
          <Card variant="modern" className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <div className="flex items-center space-x-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div>
                <h4 className="text-lg font-bold text-green-900">
                  Cliente já quitou sua parte!
                </h4>
                <p className="text-sm text-green-700">
                  Total pago: R$ {customer.paidAmount.toFixed(2)}
                </p>
              </div>
            </div>
          </Card>
        ) : (
          <>
            {/* Items Consumed */}
            <Card variant="modern">
              <h4 className="font-bold text-gray-900 mb-4">Itens Consumidos</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {customer.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                    <div>
                      <span className="font-medium text-gray-900">
                        {item.quantity}x {item.productName}
                      </span>
                      {item.notes && (
                        <p className="text-xs text-gray-500">Obs: {item.notes}</p>
                      )}
                    </div>
                    <span className="font-bold text-gray-900">
                      R$ {(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
              
              <div className="pt-4 border-t border-gray-200 mt-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-700">Total do Cliente:</span>
                  <span className="text-lg font-bold text-gray-900">
                    R$ {customer.totalAmount.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center mb-2">
                  <span className="text-gray-700">Já Pago:</span>
                  <span className="text-lg font-bold text-green-600">
                    R$ {customer.paidAmount.toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-700 font-bold">A Pagar:</span>
                  <span className="text-2xl font-black text-red-600">
                    R$ {amountToPay.toFixed(2)}
                  </span>
                </div>
              </div>
            </Card>

            {/* Payment Method Selection */}
            <div>
              <h4 className="text-sm font-bold text-gray-700 mb-3 uppercase tracking-wide">
                Forma de Pagamento:
              </h4>
              
              <div className="grid grid-cols-1 gap-3">
                {paymentOptions.map((option) => {
                  const Icon = option.icon;
                  return (
                    <button
                      key={option.id}
                      onClick={() => setPaymentMethod(option.id as any)}
                      disabled={isProcessing}
                      className={`
                        p-4 rounded-xl border-2 transition-all duration-200 flex items-center space-x-3
                        ${paymentMethod === option.id
                          ? 'border-blue-500 bg-blue-50 shadow-lg'
                          : 'border-gray-200 hover:border-gray-300 bg-white'
                        }
                        ${isProcessing ? 'opacity-50 cursor-not-allowed' : 'hover:shadow-md'}
                      `}
                    >
                      <div className={`p-3 rounded-xl ${option.color} shadow-md`}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <span className="font-bold text-gray-900 text-lg">{option.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3 pt-4 border-t border-gray-200">
              <Button
                variant="outline"
                fullWidth
                onClick={handleClose}
                disabled={isProcessing}
                rounded="xl"
              >
                Cancelar
              </Button>
              <Button
                variant="success"
                fullWidth
                onClick={handlePayment}
                disabled={amountToPay <= 0 || isProcessing}
                loading={isProcessing}
                rounded="xl"
                className="bg-gradient-to-r from-green-600 to-emerald-600"
              >
                {isProcessing ? 'Processando...' : `Pagar R$ ${amountToPay.toFixed(2)}`}
              </Button>
            </div>
          </>
        )}

        {/* Processing Indicator */}
        {isProcessing && (
          <Card variant="modern" className="bg-gradient-to-r from-yellow-50 to-amber-50 border-yellow-200">
            <div className="flex items-center space-x-4">
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center animate-pulse">
                <CreditCard className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="font-bold text-yellow-900">Processando pagamento...</p>
                <p className="text-sm text-yellow-700">Aguarde, não feche esta janela</p>
              </div>
            </div>
          </Card>
        )}
      </div>
    </Modal>
  );
}