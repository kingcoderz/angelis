import React, { useState } from 'react';
import { Plus, Edit, Trash2, Users, Search, UserCheck, UserX } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Modal } from '../ui/Modal';
import { User } from '../../types';

export function UserManagement() {
  const { state, addUser, updateUser, deleteUser } = useApp();
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    name: '',
    role: 'garcom' as 'garcom' | 'admin',
    active: true,
  });

  const filteredUsers = state.users.filter(user => 
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.username.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = () => {
    if (!formData.username || !formData.password || !formData.name) return;

    if (editingUser) {
      updateUser({
        ...editingUser,
        ...formData,
      });
    } else {
      // Check if username already exists
      const existingUser = state.users.find(u => u.username === formData.username);
      if (existingUser) {
        alert('Nome de usuário já existe!');
        return;
      }
      
      addUser(formData);
    }

    resetForm();
  };

  const handleEdit = (user: User) => {
    setEditingUser(user);
    setFormData({
      username: user.username,
      password: user.password,
      name: user.name,
      role: user.role,
      active: user.active,
    });
    setShowModal(true);
  };

  const handleDelete = (userId: string) => {
    const user = state.users.find(u => u.id === userId);
    if (user?.username === 'admin') {
      alert('Não é possível excluir o usuário administrador padrão!');
      return;
    }
    
    if (confirm('Tem certeza que deseja excluir este usuário?')) {
      deleteUser(userId);
    }
  };

  const toggleUserStatus = (user: User) => {
    updateUser({
      ...user,
      active: !user.active,
    });
  };

  const resetForm = () => {
    setFormData({
      username: '',
      password: '',
      name: '',
      role: 'garcom',
      active: true,
    });
    setEditingUser(null);
    setShowModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Gerenciar Usuários</h2>
        <Button
          variant="primary"
          icon={Plus}
          onClick={() => setShowModal(true)}
        >
          Novo Usuário
        </Button>
      </div>

      {/* Search */}
      <Card>
        <Input
          label="Buscar usuários"
          placeholder="Nome ou usuário..."
          value={searchTerm}
          onChange={setSearchTerm}
          icon={Search}
          fullWidth
        />
      </Card>

      {/* Users List */}
      {filteredUsers.length === 0 ? (
        <Card className="text-center py-12">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Nenhum usuário encontrado
          </h3>
          <p className="text-gray-500 mb-4">
            {searchTerm 
              ? 'Tente ajustar o termo de busca.'
              : 'Adicione novos usuários ao sistema.'
            }
          </p>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredUsers.map((user) => (
            <Card key={user.id} hover animated>
              <div className="flex justify-between items-start mb-3">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <h3 className="font-semibold text-gray-900 mr-2">
                      {user.name}
                    </h3>
                    {user.active ? (
                      <UserCheck className="w-4 h-4 text-green-600" />
                    ) : (
                      <UserX className="w-4 h-4 text-red-600" />
                    )}
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-1">
                    Usuário: {user.username}
                  </p>
                  
                  <div className={`
                    inline-flex px-2 py-1 rounded-full text-xs font-medium
                    ${user.role === 'admin' 
                      ? 'bg-purple-100 text-purple-800' 
                      : 'bg-blue-100 text-blue-800'
                    }
                  `}>
                    {user.role === 'admin' ? 'Administrador' : 'Garçom'}
                  </div>
                </div>
                
                <div className={`
                  px-2 py-1 rounded-full text-xs font-medium
                  ${user.active 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                  }
                `}>
                  {user.active ? 'Ativo' : 'Inativo'}
                </div>
              </div>

              <div className="text-xs text-gray-500 mb-3">
                Criado em: {new Date(user.createdAt).toLocaleDateString()}
              </div>

              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  icon={Edit}
                  onClick={() => handleEdit(user)}
                  fullWidth
                >
                  Editar
                </Button>
                
                <Button
                  variant={user.active ? 'warning' : 'success'}
                  size="sm"
                  onClick={() => toggleUserStatus(user)}
                >
                  {user.active ? 'Desativar' : 'Ativar'}
                </Button>
                
                {user.username !== 'admin' && (
                  <Button
                    variant="danger"
                    size="sm"
                    icon={Trash2}
                    onClick={() => handleDelete(user.id)}
                  >
                    Excluir
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* User Modal */}
      <Modal
        isOpen={showModal}
        onClose={resetForm}
        title={editingUser ? 'Editar Usuário' : 'Novo Usuário'}
      >
        <div className="space-y-4">
          <Input
            label="Nome Completo"
            placeholder="Ex: João Silva"
            value={formData.name}
            onChange={(value) => setFormData({ ...formData, name: value })}
            fullWidth
            required
          />

          <div className="grid grid-cols-2 gap-4">
            <Input
              label="Nome de Usuário"
              placeholder="Ex: joao"
              value={formData.username}
              onChange={(value) => setFormData({ ...formData, username: value })}
              fullWidth
              required
              disabled={editingUser?.username === 'admin'}
            />

            <Input
              label="Senha"
              type="password"
              placeholder="Digite a senha"
              value={formData.password}
              onChange={(value) => setFormData({ ...formData, password: value })}
              fullWidth
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Função <span className="text-red-500">*</span>
            </label>
            <select
              value={formData.role}
              onChange={(e) => setFormData({ ...formData, role: e.target.value as 'garcom' | 'admin' })}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
              disabled={editingUser?.username === 'admin'}
            >
              <option value="garcom">Garçom</option>
              <option value="admin">Administrador</option>
            </select>
          </div>

          <div className="flex items-center">
            <input
              type="checkbox"
              id="active"
              checked={formData.active}
              onChange={(e) => setFormData({ ...formData, active: e.target.checked })}
              className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
              disabled={editingUser?.username === 'admin'}
            />
            <label htmlFor="active" className="ml-2 block text-sm text-gray-900">
              Usuário ativo
            </label>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button
              variant="outline"
              fullWidth
              onClick={resetForm}
            >
              Cancelar
            </Button>
            <Button
              variant="primary"
              fullWidth
              onClick={handleSubmit}
              disabled={!formData.username || !formData.password || !formData.name}
            >
              {editingUser ? 'Atualizar' : 'Adicionar'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}