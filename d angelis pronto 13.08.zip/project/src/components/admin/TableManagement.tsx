import React, { useState } from 'react';
import { Plus, Edit, Trash2, Grid3X3, Search, Users, Coffee } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Input } from '../ui/Input';
import { Modal } from '../ui/Modal';
import { TableGrid } from '../ui/TableGrid';
import { Table } from '../../types';

export function TableManagement() {
  const { state, addTable, updateTable, deleteTable } = useApp();
  const [showModal, setShowModal] = useState(false);
  const [editingTable, setEditingTable] = useState<Table | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    number: '',
    capacity: '4',
  });

  const filteredTables = state.tables.filter(table => 
    table.number.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSubmit = () => {
    if (!formData.number.trim()) return;

    // Verificar se o número da mesa já existe (exceto se estiver editando)
    const existingTable = state.tables.find(t => 
      t.number === formData.number.trim() && t.id !== editingTable?.id
    );
    
    if (existingTable) {
      alert('Já existe uma mesa com este número!');
      return;
    }

    if (editingTable) {
      const updatedTable: Table = {
        ...editingTable,
        number: formData.number.trim(),
      };
      updateTable(updatedTable);
    } else {
      addTable({
        number: formData.number.trim(),
        customers: [],
        status: 'livre',
      });
    }

    resetForm();
  };

  const handleEdit = (table: Table) => {
    if (table.status === 'ocupada') {
      alert('Não é possível editar uma mesa ocupada!');
      return;
    }
    
    setEditingTable(table);
    setFormData({
      number: table.number,
      capacity: '4',
    });
    setShowModal(true);
  };

  const handleDelete = (table: Table) => {
    if (table.status === 'ocupada') {
      alert('Não é possível excluir uma mesa ocupada!');
      return;
    }
    
    if (confirm(`Tem certeza que deseja excluir a Mesa ${table.number}?`)) {
      deleteTable(table.id);
    }
  };

  const resetForm = () => {
    setFormData({
      number: '',
      capacity: '4',
    });
    setEditingTable(null);
    setShowModal(false);
  };

  const getNextTableNumber = () => {
    const numbers = state.tables.map(t => parseInt(t.number)).filter(n => !isNaN(n));
    const maxNumber = numbers.length > 0 ? Math.max(...numbers) : 0;
    return (maxNumber + 1).toString();
  };

  const handleQuickAdd = () => {
    const nextNumber = getNextTableNumber();
    setFormData({
      number: nextNumber,
      capacity: '4',
    });
    setShowModal(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Gerenciar Mesas</h2>
          <p className="text-gray-600 mt-1">
            {state.tables.length} mesa(s) • {state.tables.filter(t => t.status === 'livre').length} livre(s) • {state.tables.filter(t => t.status === 'ocupada').length} ocupada(s)
          </p>
        </div>
        <div className="flex space-x-3">
          <Button
            variant="outline"
            icon={Plus}
            onClick={handleQuickAdd}
            rounded="xl"
          >
            Adicionar Mesa
          </Button>
          <Button
            variant="primary"
            icon={Grid3X3}
            onClick={() => setShowModal(true)}
            rounded="xl"
          >
            Nova Mesa
          </Button>
        </div>
      </div>

      {/* Search and Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="md:col-span-2 p-4">
          <Input
            label="Buscar mesas"
            placeholder="Número da mesa..."
            value={searchTerm}
            onChange={setSearchTerm}
            icon={Search}
            fullWidth
            variant="modern"
          />
        </Card>

        <Card className="p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <div className="w-3 h-3 bg-green-500 rounded-full mr-2"></div>
            <span className="text-sm font-medium text-gray-600">Livres</span>
          </div>
          <p className="text-2xl font-bold text-green-600">
            {state.tables.filter(t => t.status === 'livre').length}
          </p>
        </Card>

        <Card className="p-4 text-center">
          <div className="flex items-center justify-center mb-2">
            <div className="w-3 h-3 bg-orange-500 rounded-full mr-2"></div>
            <span className="text-sm font-medium text-gray-600">Ocupadas</span>
          </div>
          <p className="text-2xl font-bold text-orange-600">
            {state.tables.filter(t => t.status === 'ocupada').length}
          </p>
        </Card>
      </div>

      {/* Tables Grid */}
      {filteredTables.length === 0 ? (
        <Card className="text-center py-12">
          <Coffee className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {searchTerm ? 'Nenhuma mesa encontrada' : 'Nenhuma mesa cadastrada'}
          </h3>
          <p className="text-gray-500 mb-4">
            {searchTerm 
              ? 'Tente ajustar o termo de busca.'
              : 'Comece adicionando mesas ao seu restaurante.'
            }
          </p>
          <Button
            variant="primary"
            icon={Plus}
            onClick={() => setShowModal(true)}
            rounded="xl"
          >
            Adicionar Primeira Mesa
          </Button>
        </Card>
      ) : (
        <div className="space-y-6">
          <TableGrid 
            tables={filteredTables}
            showWaiterName={true}
            showActions={true}
            onEditTable={handleEdit}
            onDeleteTable={handleDelete}
            currentUserRole="admin"
          />
        </div>
      )}

      {/* Table Modal */}
      <Modal
        isOpen={showModal}
        onClose={resetForm}
        title={editingTable ? `Editar Mesa ${editingTable.number}` : 'Nova Mesa'}
        variant="modern"
      >
        <div className="space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl">
              <Grid3X3 className="w-8 h-8 text-white" />
            </div>
            <p className="text-gray-600">
              {editingTable ? 'Edite as informações da mesa' : 'Configure uma nova mesa para o restaurante'}
            </p>
          </div>

          <Input
            label="Número da Mesa"
            placeholder="Ex: 1, 2, A1, VIP1..."
            value={formData.number}
            onChange={(value) => setFormData({ ...formData, number: value })}
            fullWidth
            required
            variant="modern"
          />

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Capacidade Sugerida
            </label>
            <select
              value={formData.capacity}
              onChange={(e) => setFormData({ ...formData, capacity: e.target.value })}
              className="block w-full rounded-xl border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 transition-colors duration-200"
            >
              <option value="2">2 pessoas</option>
              <option value="4">4 pessoas</option>
              <option value="6">6 pessoas</option>
              <option value="8">8 pessoas</option>
              <option value="10">10+ pessoas</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">
              Esta informação é apenas para referência
            </p>
          </div>

          {editingTable && (
            <Card className="bg-blue-50 border-blue-200">
              <div className="flex items-center space-x-3">
                <Users className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="text-sm font-medium text-blue-900">
                    Status atual: {editingTable.status === 'livre' ? 'Livre' : 
                                  editingTable.status === 'ocupada' ? 'Ocupada' : 'Aguardando'}
                  </p>
                  {editingTable.waiterName && (
                    <p className="text-xs text-blue-700">
                      Garçom: {editingTable.waiterName}
                    </p>
                  )}
                </div>
              </div>
            </Card>
          )}

          <div className="flex space-x-3 pt-4">
            <Button
              variant="outline"
              fullWidth
              onClick={resetForm}
              rounded="xl"
            >
              Cancelar
            </Button>
            <Button
              variant="primary"
              fullWidth
              onClick={handleSubmit}
              disabled={!formData.number.trim()}
              rounded="xl"
              className="bg-gradient-to-r from-blue-600 to-purple-600"
            >
              {editingTable ? 'Atualizar Mesa' : 'Criar Mesa'}
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}