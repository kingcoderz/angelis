import React, { useState } from 'react';
import { useApp } from '../../contexts/AppContext';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { Order } from '../../types';

interface CancelOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onSuccess: () => void;
}

export function CancelOrderModal({ isOpen, onClose, order, onSuccess }: CancelOrderModalProps) {
  const { cancelOrder } = useApp();
  const [reason, setReason] = useState('');

  const handleCancel = () => {
    if (order && reason.trim()) {
      cancelOrder(order.id, reason.trim());
      setReason('');
      onSuccess();
    }
  };

  if (!order) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        setReason('');
        onClose();
      }}
      title="Cancelar Pedido"
    >
      <div className="space-y-4">
        <div className="bg-red-50 border border-red-200 rounded-md p-4">
          <h3 className="font-medium text-red-800 mb-2">
            Mesa {order.tableNumber} - {order.customers.join(', ')}
          </h3>
          <p className="text-sm text-red-600">
            Esta ação irá cancelar permanentemente este pedido.
          </p>
        </div>

        <Input
          label="Motivo do cancelamento"
          placeholder="Ex: Erro de lançamento, cliente desistiu..."
          value={reason}
          onChange={setReason}
          fullWidth
          required
        />

        <div className="flex space-x-3">
          <Button
            variant="outline"
            fullWidth
            onClick={() => {
              setReason('');
              onClose();
            }}
          >
            Voltar
          </Button>
          <Button
            variant="danger"
            fullWidth
            onClick={handleCancel}
            disabled={!reason.trim()}
          >
            Cancelar Pedido
          </Button>
        </div>
      </div>
    </Modal>
  );
}