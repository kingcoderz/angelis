import React, { useState } from 'react';
import { CreditCard, DollarSign, Smartphone } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { Modal } from '../ui/Modal';
import { Button } from '../ui/Button';
import { Card } from '../ui/Card';
import { Order } from '../../types';

interface CloseOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onSuccess: () => void;
}

export function CloseOrderModal({ isOpen, onClose, order, onSuccess }: CloseOrderModalProps) {
  const { state, closeOrder } = useApp();
  const [paymentMethod, setPaymentMethod] = useState<'dinheiro' | 'pix' | 'cartao'>('dinheiro');

  const handleCloseOrder = () => {
    if (order) {
      closeOrder(order.id, paymentMethod);
      
      // Gerar e imprimir recibo automaticamente
      setTimeout(() => {
        printOrderReceipt(order);
      }, 500);
      
      onSuccess();
    }
  };

  const printOrderReceipt = (order: Order) => {
    const company = state.config.company;
    const receiptContent = `
${company.nomeFantasia}
Razão Social: ${company.razaoSocial}
CNPJ: ${company.cnpj}
${company.endereco}
-------------------------------
CUPOM FISCAL
-------------------------------
Mesa: ${order.tableNumber}
Garçom: ${order.waiterName}
Data/Hora: ${new Date().toLocaleString('pt-BR')}

CLIENTES E CONSUMO:
${order.customers.map(customer => `
${customer.name.toUpperCase()}:
${customer.items.map(item => 
  `  ${item.quantity}x ${item.productName} ........ R$ ${(item.price * item.quantity).toFixed(2)}`
).join('\n')}
  Subtotal: .............. R$ ${customer.totalAmount.toFixed(2)}
  Pago: .................. R$ ${customer.paidAmount.toFixed(2)}
  ${customer.totalAmount > customer.paidAmount ? 
    `Pendente: .............. R$ ${(customer.totalAmount - customer.paidAmount).toFixed(2)}` : 
    'Status: ............... PAGO'
  }
`).join('\n')}
-------------------------------
RESUMO GERAL:
Total Geral: ........... R$ ${order.total.toFixed(2)}
Total Pago: ............ R$ ${order.paidTotal || 0}
${(order.total - (order.paidTotal || 0)) > 0 ? 
  `Restante Pago: ......... R$ ${(order.total - (order.paidTotal || 0)).toFixed(2)}` : 
  'Status: ............... QUITADO'
}

Forma de pagamento: ${paymentMethod === 'dinheiro' ? 'Dinheiro' : 
                     paymentMethod === 'pix' ? 'PIX' : 'Cartão'}
-------------------------------
Obrigado pela preferência!
Volte sempre!

-------------------------------
Techno A.I Soluções Tecnológicas
(28) 98115-3400
-------------------------------
    `.trim();

    // Abrir janela de impressão
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Cupom Fiscal - Mesa ${order.tableNumber}</title>
            <style>
              @page { 
                size: 80mm auto; 
                margin: 2mm; 
              }
              body { 
                font-family: 'Courier New', 'Consolas', monospace; 
                font-size: 16px; 
                font-weight: bold;
                margin: 0; 
                padding: 0;
                line-height: 1.3;
                color: #000;
              }
              pre { 
                white-space: pre-wrap; 
                margin: 0; 
                font-family: inherit;
                font-size: inherit;
                font-weight: inherit;
              }
              @media print {
                body { 
                  font-size: 14px; 
                  font-weight: bold;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                @page {
                  margin: 0;
                }
              }
            </style>
          </head>
          <body>
            <pre>${receiptContent}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      
      setTimeout(() => {
        printWindow.print();
        setTimeout(() => printWindow.close(), 2000);
      }, 1000);
    }
  };

  if (!order) return null;

  const paymentOptions = [
    { id: 'dinheiro', label: 'Dinheiro', icon: DollarSign, color: 'text-green-600 bg-green-100' },
    { id: 'pix', label: 'PIX', icon: Smartphone, color: 'text-blue-600 bg-blue-100' },
    { id: 'cartao', label: 'Cartão', icon: CreditCard, color: 'text-purple-600 bg-purple-100' },
  ];

  // Calcular valores
  const totalOrder = order.total;
  const totalPaid = order.paidTotal || 0;
  const remainingAmount = totalOrder - totalPaid;
  const isFullyPaid = remainingAmount <= 0;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Fechar Pedido"
      size="md"
    >
      <div className="space-y-6">
        {/* Order Summary */}
        <Card className="bg-gray-50">
          <h3 className="font-semibold text-gray-900 mb-2">
            Mesa {order.tableNumber}
          </h3>
          <p className="text-sm text-gray-600 mb-2">
            Clientes: {order.customers.map(c => c.name).join(', ')}
          </p>
          <p className="text-sm text-gray-600 mb-4">
            {order.items.length} item(s)
          </p>
          
          {/* Detalhamento de pagamentos */}
          <div className="space-y-2 mb-4">
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Total do Pedido:</span>
              <span className="text-lg font-bold text-gray-900">R$ {totalOrder.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-600">Já Pago (Individual):</span>
              <span className="text-lg font-bold text-green-600">R$ {totalPaid.toFixed(2)}</span>
            </div>
            <div className="flex justify-between border-t pt-2">
              <span className="text-sm font-bold text-gray-900">
                {isFullyPaid ? 'Status:' : 'Restante a Pagar:'}
              </span>
              <span className={`text-xl font-black ${isFullyPaid ? 'text-green-600' : 'text-red-600'}`}>
                {isFullyPaid ? '✅ QUITADO' : `R$ ${remainingAmount.toFixed(2)}`}
              </span>
            </div>
          </div>

          {/* Status por cliente */}
          <div className="border-t pt-4">
            <h4 className="text-sm font-bold text-gray-700 mb-2">Status por Cliente:</h4>
            <div className="space-y-1">
              {order.customers.map((customer) => {
                const customerRemaining = customer.totalAmount - customer.paidAmount;
                const customerPaid = customerRemaining <= 0;
                
                return (
                  <div key={customer.id} className="flex justify-between text-xs">
                    <span className="font-medium">{customer.name}:</span>
                    <span className={customerPaid ? 'text-green-600 font-bold' : 'text-red-600'}>
                      {customerPaid ? '✅ Pago' : `Deve R$ ${customerRemaining.toFixed(2)}`}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>

        {/* Aviso se há valores pendentes */}
        {!isFullyPaid && (
          <Card className="bg-yellow-50 border-yellow-200">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">⚠️</span>
              </div>
              <div>
                <p className="text-sm font-bold text-yellow-800">
                  Atenção: Ainda há R$ {remainingAmount.toFixed(2)} pendente
                </p>
                <p className="text-xs text-yellow-700">
                  Ao fechar o pedido, o valor restante será considerado pago na forma selecionada abaixo.
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Payment Method Selection - Só mostrar se há valor restante */}
        {!isFullyPaid && (
          <div>
            <h4 className="text-sm font-medium text-gray-700 mb-3">
              Forma de pagamento para o valor restante (R$ {remainingAmount.toFixed(2)}):
            </h4>
            
            <div className="grid grid-cols-1 gap-3">
              {paymentOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <button
                    key={option.id}
                    onClick={() => setPaymentMethod(option.id as any)}
                    className={`
                      p-4 rounded-lg border-2 transition-all duration-200 flex items-center space-x-3
                      ${paymentMethod === option.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-gray-300'
                      }
                    `}
                  >
                    <div className={`p-2 rounded-lg ${option.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="font-medium text-gray-900">{option.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Se já está totalmente pago */}
        {isFullyPaid && (
          <Card className="bg-green-50 border-green-200">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">✅</span>
              </div>
              <div>
                <p className="text-sm font-bold text-green-800">
                  Pedido totalmente quitado!
                </p>
                <p className="text-xs text-green-700">
                  Todos os clientes já pagaram suas partes individualmente.
                </p>
              </div>
            </div>
          </Card>
        )}

        {/* Item Details */}
        <div>
          <h4 className="text-sm font-medium text-gray-700 mb-3">
            Itens do pedido:
          </h4>
          <div className="max-h-40 overflow-y-auto space-y-2">
            {order.items.map((item, index) => (
              <div key={index} className="flex justify-between items-center text-sm">
                <div>
                  <span className="font-medium">{item.quantity}x {item.productName}</span>
                  {item.customerName && (
                    <span className="text-gray-500 ml-2">({item.customerName})</span>
                  )}
                </div>
                <span className="font-medium">
                  R$ {(item.price * item.quantity).toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex space-x-3 pt-4 border-t">
          <Button
            variant="outline"
            fullWidth
            onClick={onClose}
          >
            Cancelar
          </Button>
          <Button
            variant="success"
            fullWidth
            onClick={handleCloseOrder}
          >
            {isFullyPaid ? 'Finalizar Pedido (Quitado)' : `Finalizar e Cobrar R$ ${remainingAmount.toFixed(2)}`}
          </Button>
        </div>
      </div>
    </Modal>
  );
}