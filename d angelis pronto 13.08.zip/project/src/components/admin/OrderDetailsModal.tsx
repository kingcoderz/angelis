import React from 'react';
import { Users, Clock, User } from 'lucide-react';
import { Modal } from '../ui/Modal';
import { Card } from '../ui/Card';
import { StatusBadge } from '../ui/StatusBadge';
import { Order } from '../../types';

interface OrderDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
}

export function OrderDetailsModal({ isOpen, onClose, order }: OrderDetailsModalProps) {
  if (!order) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Detalhes do Pedido - Mesa ${order.tableNumber}`}
      size="lg"
    >
      <div className="space-y-6">
        {/* Header Info */}
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 flex items-center">
              <Users className="w-5 h-5 mr-2" />
              {order.customers.join(', ')}
            </h3>
            <p className="text-sm text-gray-500 flex items-center mt-1">
              <User className="w-4 h-4 mr-1" />
              Garçom: {order.waiterName}
            </p>
            <p className="text-sm text-gray-500 flex items-center mt-1">
              <Clock className="w-4 h-4 mr-1" />
              Criado: {new Date(order.createdAt).toLocaleString()}
            </p>
          </div>
          <StatusBadge status={order.status} />
        </div>

        {/* Items List */}
        <Card>
          <h4 className="font-medium text-gray-900 mb-4">Itens do Pedido</h4>
          <div className="space-y-3">
            {order.items.map((item, index) => (
              <div key={index} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">
                    {item.quantity}x {item.productName}
                  </p>
                  {item.customerName && (
                    <p className="text-sm text-gray-500">
                      Cliente: {item.customerName}
                    </p>
                  )}
                  {item.notes && (
                    <p className="text-sm text-gray-500">
                      Obs: {item.notes}
                    </p>
                  )}
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">
                    R$ {(item.price * item.quantity).toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-500">
                    R$ {item.price.toFixed(2)} cada
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="pt-4 border-t border-gray-200 mt-4">
            <div className="flex justify-between items-center">
              <p className="text-lg font-semibold text-gray-900">Total</p>
              <p className="text-2xl font-bold text-green-600">
                R$ {order.total.toFixed(2)}
              </p>
            </div>
          </div>
        </Card>

        {/* Payment Info */}
        {order.status === 'fechado' && order.paymentMethod && (
          <Card>
            <h4 className="font-medium text-gray-900 mb-2">Informações de Pagamento</h4>
            <p className="text-sm text-gray-600">
              Forma de pagamento: <span className="font-medium">
                {order.paymentMethod === 'dinheiro' ? 'Dinheiro' : 
                 order.paymentMethod === 'pix' ? 'PIX' : 
                 order.paymentMethod === 'cartao' ? 'Cartão' : 'N/A'}
              </span>
            </p>
            {order.closedAt && (
              <p className="text-sm text-gray-600 mt-1">
                Fechado em: {new Date(order.closedAt).toLocaleString()}
              </p>
            )}
          </Card>
        )}

        {/* Cancel Info */}
        {order.status === 'cancelado' && order.cancelReason && (
          <Card className="bg-red-50 border-red-200">
            <h4 className="font-medium text-red-800 mb-2">Pedido Cancelado</h4>
            <p className="text-sm text-red-600">
              Motivo: {order.cancelReason}
            </p>
          </Card>
        )}
      </div>
    </Modal>
  );
}