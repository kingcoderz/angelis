import React from 'react';
import { Users, Clock, User, Edit, Trash2, Plus, Wifi, Battery, Signal, Zap } from 'lucide-react';
import { Table } from '../../types';
import { Card } from './Card';
import { Button } from './Button';

interface TableGridProps {
  tables: Table[];
  onTableClick?: (table: Table) => void;
  onEditTable?: (table: Table) => void;
  onDeleteTable?: (table: Table) => void;
  onAddCustomer?: (table: Table) => void;
  showWaiterName?: boolean;
  showActions?: boolean;
  currentUserRole?: string;
}

export function TableGrid({ 
  tables, 
  onTableClick, 
  onEditTable,
  onDeleteTable,
  onAddCustomer,
  showWaiterName = true,
  showActions = false,
  currentUserRole = 'garcom'
}: TableGridProps) {
  const getTableStatusColor = (table: Table) => {
    switch (table.status) {
      case 'livre':
        return 'from-emerald-400 via-green-500 to-emerald-600';
      case 'ocupada':
        return 'from-orange-400 via-amber-500 to-orange-600';
      case 'aguardando':
        return 'from-yellow-400 via-amber-400 to-yellow-500';
      default:
        return 'from-slate-400 via-slate-500 to-slate-600';
    }
  };

  const getTableGlow = (table: Table) => {
    switch (table.status) {
      case 'livre':
        return 'shadow-emerald-500/30 hover:shadow-emerald-500/50';
      case 'ocupada':
        return 'shadow-orange-500/30 hover:shadow-orange-500/50';
      case 'aguardando':
        return 'shadow-yellow-500/30 hover:shadow-yellow-500/50';
      default:
        return 'shadow-slate-500/30 hover:shadow-slate-500/50';
    }
  };

  const handleTableClick = (table: Table, event: React.MouseEvent) => {
    // ✅ CORREÇÃO: Permitir clique mesmo com botões, mas verificar se não é um botão específico
    const clickedElement = event.target as HTMLElement;
    const isActionButton = clickedElement.closest('button[data-action]');
    
    if (isActionButton) {
      return; // Só bloquear se for um botão de ação específico
    }
    
    if (onTableClick) {
      onTableClick(table);
    }
  };

  const getTableIcon = (table: Table) => {
    switch (table.status) {
      case 'livre':
        return <Battery className="w-3 h-3" />;
      case 'ocupada':
        return <Zap className="w-3 h-3" />;
      case 'aguardando':
        return <Wifi className="w-3 h-3" />;
      default:
        return null;
    }
  };

  const getStatusEmoji = (status: string) => {
    switch (status) {
      case 'livre': return '🟢';
      case 'ocupada': return '🔴';
      case 'aguardando': return '🟡';
      default: return '⚪';
    }
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-6">
      {tables.map((table) => (
        <div
          key={table.id}
          className="relative group"
        >
          <div
            className={`
              relative overflow-hidden cursor-pointer transition-all duration-500 ease-out
              bg-gradient-to-br ${getTableStatusColor(table)}
              hover:scale-110 hover:rotate-1 transform-gpu
              min-h-[160px] flex flex-col justify-between
              rounded-3xl shadow-2xl border-2 border-white/20 p-5
              ${getTableGlow(table)}
              ${onTableClick ? 'hover:shadow-2xl' : ''}
              backdrop-blur-sm
            `}
            onClick={(e) => handleTableClick(table, e)}
          >
            {/* Animated background pattern */}
            <div className="absolute inset-0 opacity-20">
              <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/30 to-white/0 transform -skew-x-12 animate-pulse" />
            </div>

            {/* Modern status indicator */}
            <div className="absolute top-4 right-4 flex items-center space-x-2">
              <div className={`
                flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-bold
                bg-white/25 backdrop-blur-xl border border-white/30 text-white
                shadow-lg
              `}>
                {getTableIcon(table)}
                <span className="text-lg">{getStatusEmoji(table.status)}</span>
              </div>
            </div>

            {/* Table number with modern design */}
            <div className="text-center relative z-10 flex-1 flex flex-col justify-center">
              <div className={`
                w-20 h-20 mx-auto mb-4 rounded-3xl flex items-center justify-center text-2xl font-black
                bg-white/25 backdrop-blur-xl border-2 border-white/30 text-white
                shadow-2xl transform transition-all duration-300 group-hover:scale-110 group-hover:rotate-3
              `}>
                {table.number}
              </div>

              {/* Table info with modern glassmorphism */}
              <div className="space-y-2 text-white">
                <div className="text-sm font-bold bg-white/15 backdrop-blur-xl rounded-xl px-3 py-2 border border-white/20">
                  {table.status === 'livre' ? '✨ Disponível' : 
                   table.status === 'ocupada' ? '👥 Ocupada' : '⏳ Aguardando'}
                </div>

                {table.status === 'ocupada' && table.customers.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-center text-xs bg-white/15 backdrop-blur-xl rounded-xl px-3 py-1.5 border border-white/20">
                      <Users className="w-3 h-3 mr-1" />
                      <span className="truncate max-w-20 font-medium">
                        {table.customers.length > 1 
                          ? `${table.customers[0].name}...` 
                          : table.customers[0].name
                        }
                      </span>
                    </div>
                    
                    {showWaiterName && table.waiterName && (
                      <div className="flex items-center justify-center text-xs bg-white/15 backdrop-blur-xl rounded-xl px-3 py-1.5 border border-white/20">
                        <User className="w-3 h-3 mr-1" />
                        <span className="truncate max-w-20 font-medium">{table.waiterName}</span>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-center text-xs bg-white/15 backdrop-blur-xl rounded-xl px-3 py-1.5 border border-white/20">
                      <Clock className="w-3 h-3 mr-1" />
                      <span className="font-medium">
                        {new Date(table.lastActivity || table.createdAt).toLocaleTimeString('pt-BR', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Modern action buttons - Removido para não aparecer no hover */}
            {showActions && table.status === 'ocupada' && currentUserRole === 'admin' && (
              <div className="absolute inset-0 bg-black/50 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center space-x-2 rounded-3xl">
                {onAddCustomer && (
                  <Button
                    variant="glass"
                    size="sm"
                    icon={Plus}
                    onClick={(e) => {
                      e.stopPropagation();
                      onAddCustomer(table);
                    }}
                    rounded="full"
                    className="shadow-xl"
                    data-action="add-customer"
                  />
                )}
                {onEditTable && (
                  <Button
                    variant="glass"
                    size="sm"
                    icon={Edit}
                    onClick={(e) => {
                      e.stopPropagation();
                      onEditTable(table);
                    }}
                    rounded="full"
                    className="shadow-xl"
                    data-action="edit-table"
                  />
                )}
                {onDeleteTable && currentUserRole === 'admin' && (
                  <Button
                    variant="danger"
                    size="sm"
                    icon={Trash2}
                    onClick={(e) => {
                      e.stopPropagation();
                      onDeleteTable(table);
                    }}
                    rounded="full"
                    className="shadow-xl"
                    data-action="delete-table"
                  />
                )}
              </div>
            )}

            {/* Enhanced shimmer animation */}
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 hover:opacity-100 transform -skew-x-12 -translate-x-full hover:translate-x-full transition-all duration-1000 rounded-3xl" />
          </div>

          {/* Modern customer count badge */}
          {table.status === 'ocupada' && table.customers.length > 1 && (
            <div className="absolute -top-3 -right-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white text-xs rounded-full w-8 h-8 flex items-center justify-center font-black shadow-xl animate-bounce border-3 border-white">
              {table.customers.length}
            </div>
          )}

          {/* Modern connection indicator */}
          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2">
            <div className={`w-3 h-3 rounded-full border-2 border-white shadow-lg ${
              table.status === 'ocupada' ? 'bg-green-400 animate-pulse' : 'bg-slate-300'
            }`} />
          </div>
        </div>
      ))}
    </div>
  );
}