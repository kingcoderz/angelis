import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { Button } from './Button';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  variant?: 'default' | 'modern' | 'glass';
}

export function Modal({ 
  isOpen, 
  onClose, 
  title, 
  children, 
  size = 'md',
  variant = 'modern'
}: ModalProps) {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const sizeClasses = {
    sm: 'max-w-md',
    md: 'max-w-lg',
    lg: 'max-w-2xl',
    xl: 'max-w-4xl',
    '2xl': 'max-w-6xl',
  };

  const variantClasses = {
    default: 'bg-white shadow-2xl',
    modern: 'bg-white shadow-2xl shadow-slate-900/20',
    glass: 'bg-white/90 backdrop-blur-2xl shadow-2xl shadow-black/20 border border-white/20',
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto">
      {/* Backdrop */}
      <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
        <div 
          className="fixed inset-0 transition-opacity bg-slate-900/60 backdrop-blur-sm" 
          onClick={onClose} 
        />

        {/* Modal */}
        <div className={`
          inline-block w-full ${sizeClasses[size]} p-8 my-8 overflow-hidden text-left align-middle 
          transition-all transform ${variantClasses[variant]} rounded-3xl relative
          animate-fadeIn
        `}>
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-slate-900 bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
              {title}
            </h3>
            <Button
              variant="ghost"
              size="sm"
              icon={X}
              onClick={onClose}
              rounded="full"
              className="hover:bg-slate-100"
            />
          </div>
          
          {/* Content */}
          <div className="relative">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}