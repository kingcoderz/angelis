import React from 'react';

interface StatusBadgeProps {
  status: 'aberto' | 'enviado' | 'preparando' | 'pronto' | 'fechado' | 'cancelado';
  size?: 'sm' | 'md' | 'lg';
  variant?: 'default' | 'modern' | 'glass';
}

export function StatusBadge({ status, size = 'md', variant = 'modern' }: StatusBadgeProps) {
  const statusConfig = {
    aberto: {
      label: 'Aberto',
      className: 'from-blue-500 to-blue-600 text-white',
      dotColor: 'bg-blue-400',
    },
    enviado: {
      label: 'Enviado',
      className: 'from-yellow-500 to-amber-500 text-white',
      dotColor: 'bg-yellow-400',
    },
    preparando: {
      label: 'Preparando',
      className: 'from-orange-500 to-red-500 text-white',
      dotColor: 'bg-orange-400',
    },
    pronto: {
      label: 'Pronto',
      className: 'from-emerald-500 to-green-600 text-white',
      dotColor: 'bg-emerald-400',
    },
    fechado: {
      label: 'Fechado',
      className: 'from-slate-500 to-slate-600 text-white',
      dotColor: 'bg-slate-400',
    },
    cancelado: {
      label: 'Cancelado',
      className: 'from-red-500 to-rose-600 text-white',
      dotColor: 'bg-red-400',
    },
  };

  const sizeClasses = {
    sm: 'px-2 py-1 text-xs',
    md: 'px-3 py-1.5 text-xs',
    lg: 'px-4 py-2 text-sm',
  };

  const config = statusConfig[status];

  const baseClasses = variant === 'glass' 
    ? 'bg-white/20 backdrop-blur-xl border border-white/30'
    : `bg-gradient-to-r ${config.className}`;

  return (
    <span className={`
      inline-flex items-center rounded-full font-semibold
      ${sizeClasses[size]}
      ${baseClasses}
      shadow-lg transition-all duration-200 hover:scale-105
    `}>
      <span className={`w-2 h-2 ${config.dotColor} rounded-full mr-2 animate-pulse`} />
      {config.label}
    </span>
  );
}