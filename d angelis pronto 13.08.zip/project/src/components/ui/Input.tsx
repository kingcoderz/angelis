import React from 'react';
import { DivideIcon as LucideIcon } from 'lucide-react';

interface InputProps {
  label?: string;
  placeholder?: string;
  type?: 'text' | 'password' | 'email' | 'number' | 'tel' | 'date';
  value: string;
  onChange: (value: string) => void;
  icon?: LucideIcon;
  error?: string;
  disabled?: boolean;
  required?: boolean;
  fullWidth?: boolean;
  variant?: 'default' | 'modern' | 'glass';
  size?: 'sm' | 'md' | 'lg';
}

export function Input({
  label,
  placeholder,
  type = 'text',
  value,
  onChange,
  icon: Icon,
  error,
  disabled = false,
  required = false,
  fullWidth = false,
  variant = 'modern',
  size = 'md',
}: InputProps) {
  const sizeClasses = {
    sm: 'px-3 py-2 text-sm',
    md: 'px-4 py-3 text-sm',
    lg: 'px-5 py-4 text-base',
  };

  const variantClasses = {
    default: 'border-slate-300 bg-white focus:border-blue-500 focus:ring-blue-500',
    modern: 'border-slate-200 bg-slate-50/50 focus:border-blue-500 focus:ring-blue-500 focus:bg-white',
    glass: 'border-white/20 bg-white/10 backdrop-blur-xl focus:border-blue-400 focus:ring-blue-400 text-slate-800 placeholder-slate-500',
  };

  return (
    <div className={fullWidth ? 'w-full' : ''}>
      {label && (
        <label className="block text-sm font-semibold text-slate-700 mb-2">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
      )}
      
      <div className="relative group">
        {Icon && (
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Icon className="h-5 w-5 text-slate-400 group-focus-within:text-blue-500 transition-colors duration-200" />
          </div>
        )}
        
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          required={required}
          className={`
            block w-full rounded-xl border shadow-sm
            focus:ring-2 focus:ring-offset-0
            transition-all duration-200
            ${sizeClasses[size]}
            ${Icon ? 'pl-12' : ''}
            ${variantClasses[variant]}
            ${error ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : ''}
            ${disabled ? 'bg-slate-100 cursor-not-allowed opacity-60' : ''}
            hover:shadow-md focus:shadow-lg
          `}
        />
        
        {/* Focus ring effect */}
        <div className="absolute inset-0 rounded-xl border-2 border-blue-500/20 opacity-0 group-focus-within:opacity-100 transition-opacity duration-200 pointer-events-none" />
      </div>
      
      {error && (
        <p className="mt-2 text-sm text-red-600 flex items-center">
          <span className="w-1 h-1 bg-red-500 rounded-full mr-2"></span>
          {error}
        </p>
      )}
    </div>
  );
}