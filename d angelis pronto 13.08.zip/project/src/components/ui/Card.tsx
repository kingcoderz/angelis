import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
  padding?: 'none' | 'sm' | 'md' | 'lg' | 'xl';
  hover?: boolean;
  animated?: boolean;
  variant?: 'default' | 'glass' | 'gradient' | 'elevated' | 'bordered' | 'modern';
  glow?: boolean;
  rounded?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
}

export function Card({ 
  children, 
  className = '', 
  padding = 'md', 
  hover = false, 
  animated = true,
  variant = 'default',
  glow = false,
  rounded = '2xl'
}: CardProps) {
  const paddingClasses = {
    none: '',
    sm: 'p-4',
    md: 'p-6',
    lg: 'p-8',
    xl: 'p-10',
  };

  const variantClasses = {
    default: 'bg-white border border-slate-200/60 shadow-lg shadow-slate-900/5',
    glass: 'bg-white/80 backdrop-blur-xl border border-white/20 shadow-xl shadow-black/5',
    gradient: 'bg-gradient-to-br from-white via-slate-50 to-slate-100 border border-slate-200/60 shadow-lg shadow-slate-900/5',
    elevated: 'bg-white border-0 shadow-2xl shadow-slate-900/10',
    bordered: 'bg-white border-2 border-slate-200 shadow-md shadow-slate-900/5',
    modern: 'bg-gradient-to-br from-white to-slate-50/50 border border-slate-200/40 shadow-xl shadow-slate-900/5 backdrop-blur-sm',
  };

  const roundedClasses = {
    sm: 'rounded-lg',
    md: 'rounded-xl',
    lg: 'rounded-2xl',
    xl: 'rounded-3xl',
    '2xl': 'rounded-3xl',
    '3xl': 'rounded-[2rem]',
  };

  const classes = `
    ${roundedClasses[rounded]}
    ${paddingClasses[padding]}
    ${variantClasses[variant]}
    ${hover ? 'hover:shadow-2xl cursor-pointer hover:-translate-y-1 hover:scale-[1.02]' : ''}
    ${animated ? 'transition-all duration-300 ease-out' : ''}
    ${glow ? 'shadow-lg shadow-blue-500/20 hover:shadow-blue-500/30' : ''}
    group relative overflow-hidden
    ${className}
  `.trim();

  return (
    <div className={classes}>
      {/* Subtle gradient overlay for modern effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/50 via-transparent to-slate-100/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none rounded-inherit" />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}