import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { User, Order, Product, AppConfig, OrderItem, Table, Customer, PrinterConfig } from '../types';
import productsData from '../data/products.json';
import usersData from '../data/users.json';
import configData from '../data/config.json';
import ordersData from '../data/orders.json';
import tablesData from '../data/tables.json';
import { NetworkService } from '../services/NetworkService';

interface AppState {
  currentUser: User | null;
  orders: Order[];
  products: Product[];
  users: User[];
  tables: Table[];
  config: AppConfig;
  isLoading: boolean;
}

type AppAction =
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_ORDERS'; payload: Order[] }
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'UPDATE_ORDER'; payload: Order }
  | { type: 'DELETE_ORDER'; payload: string }
  | { type: 'SET_PRODUCTS'; payload: Product[] }
  | { type: 'ADD_PRODUCT'; payload: Product }
  | { type: 'UPDATE_PRODUCT'; payload: Product }
  | { type: 'DELETE_PRODUCT'; payload: string }
  | { type: 'SET_USERS'; payload: User[] }
  | { type: 'ADD_USER'; payload: User }
  | { type: 'UPDATE_USER'; payload: User }
  | { type: 'DELETE_USER'; payload: string }
  | { type: 'SET_TABLES'; payload: Table[] }
  | { type: 'ADD_TABLE'; payload: Table }
  | { type: 'UPDATE_TABLE'; payload: Table }
  | { type: 'DELETE_TABLE'; payload: string }
  | { type: 'SET_CONFIG'; payload: AppConfig }
  | { type: 'SET_LOADING'; payload: boolean };

const initialState: AppState = {
  currentUser: null,
  orders: ordersData as Order[],
  products: productsData as Product[],
  users: usersData as User[],
  tables: tablesData as Table[],
  config: configData as AppConfig,
  isLoading: false,
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  createOrder: (tableId: string, customerNames: string[], waiterName: string) => string;
  addItemToOrder: (orderId: string, item: OrderItem) => void;
  removeItemFromOrder: (orderId: string, itemId: string) => void;
  updateOrderItem: (orderId: string, item: OrderItem) => void;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  closeOrder: (orderId: string, paymentMethod: Order['paymentMethod']) => void;
  cancelOrder: (orderId: string, reason: string) => void;
  updateOrder: (order: Order) => void;
  updateConfig: (config: AppConfig) => void;
  sendOrderToKitchen: (orderId: string) => void;
  addProduct: (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  addUser: (user: Omit<User, 'id' | 'createdAt'>) => void;
  updateUser: (user: User) => void;
  deleteUser: (userId: string) => void;
  addTable: (table: Omit<Table, 'id' | 'createdAt'>) => void;
  updateTable: (table: Table) => void;
  deleteTable: (tableId: string) => void;
  addCustomerToTable: (tableId: string, customerName: string) => void;
  removeCustomerFromTable: (tableId: string, customerId: string) => void;
  processIndividualPayment: (tableId: string, customerId: string, paymentMethod: 'dinheiro' | 'pix' | 'cartao') => void;
  printToKitchen: (order: Order, newItems: OrderItem[]) => void;
  printReceipt: (order: Order) => void;
  printPreview: (order: Order) => void;
}>({
  state: initialState,
  dispatch: () => {},
  login: () => false,
  logout: () => {},
  createOrder: () => '',
  addItemToOrder: () => {},
  removeItemFromOrder: () => {},
  updateOrderItem: () => {},
  updateOrderStatus: () => {},
  closeOrder: () => {},
  cancelOrder: () => {},
  updateOrder: () => {},
  updateConfig: () => {},
  sendOrderToKitchen: () => {},
  addProduct: () => {},
  updateProduct: () => {},
  deleteProduct: () => {},
  addUser: () => {},
  updateUser: () => {},
  deleteUser: () => {},
  addTable: () => {},
  updateTable: () => {},
  deleteTable: () => {},
  addCustomerToTable: () => {},
  removeCustomerFromTable: () => {},
  processIndividualPayment: () => {},
  printToKitchen: () => {},
  printReceipt: () => {},
  printPreview: () => {},
});

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, currentUser: action.payload };
    case 'SET_ORDERS':
      return { ...state, orders: action.payload };
    case 'ADD_ORDER':
      return { ...state, orders: [...state.orders, action.payload] };
    case 'UPDATE_ORDER':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.payload.id ? action.payload : order
        ),
      };
    case 'DELETE_ORDER':
      return {
        ...state,
        orders: state.orders.filter(order => order.id !== action.payload),
      };
    case 'SET_PRODUCTS':
      return { ...state, products: action.payload };
    case 'ADD_PRODUCT':
      return { ...state, products: [...state.products, action.payload] };
    case 'UPDATE_PRODUCT':
      return {
        ...state,
        products: state.products.map(product =>
          product.id === action.payload.id ? action.payload : product
        ),
      };
    case 'DELETE_PRODUCT':
      return {
        ...state,
        products: state.products.filter(product => product.id !== action.payload),
      };
    case 'SET_USERS':
      return { ...state, users: action.payload };
    case 'ADD_USER':
      return { ...state, users: [...state.users, action.payload] };
    case 'UPDATE_USER':
      return {
        ...state,
        users: state.users.map(user =>
          user.id === action.payload.id ? action.payload : user
        ),
      };
    case 'DELETE_USER':
      return {
        ...state,
        users: state.users.filter(user => user.id !== action.payload),
      };
    case 'SET_TABLES':
      return { ...state, tables: action.payload };
    case 'ADD_TABLE':
      return { ...state, tables: [...state.tables, action.payload] };
    case 'UPDATE_TABLE':
      return {
        ...state,
        tables: state.tables.map(table =>
          table.id === action.payload.id ? action.payload : table
        ),
      };
    case 'DELETE_TABLE':
      return {
        ...state,
        tables: state.tables.filter(table => table.id !== action.payload),
      };
    case 'SET_CONFIG':
      return { ...state, config: action.payload };
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    default:
      return state;
  }
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  const saveToStorage = (key: string, data: any) => {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
      console.error('Erro ao salvar no localStorage:', error);
    }
  };

  const login = (username: string, password: string): boolean => {
    const user = state.users.find(u => u.username === username && u.password === password && u.active);
    if (user) {
      dispatch({ type: 'SET_USER', payload: user });
      localStorage.setItem('currentUser', JSON.stringify(user));
      return true;
    }
    return false;
  };

  const logout = () => {
    dispatch({ type: 'SET_USER', payload: null });
    localStorage.removeItem('currentUser');
  };

  const createOrder = (tableId: string, customerNames: string[], waiterName: string): string => {
    const table = state.tables.find(t => t.id === tableId);
    if (!table) return '';

    const customers: Customer[] = customerNames.map(name => ({
      id: `customer-${Date.now()}-${Math.random()}`,
      name,
      items: [],
      totalAmount: 0,
      paidAmount: 0,
      status: 'ativo',
    }));

    const newOrder: Order = {
      id: Date.now().toString(),
      tableNumber: table.number,
      customers,
      items: [],
      status: 'aberto',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      waiterName,
      total: 0,
      paidTotal: 0,
    };

    const updatedTable: Table = {
      ...table,
      customers,
      waiterName,
      status: 'ocupada',
      orderId: newOrder.id,
      lastActivity: new Date().toISOString(),
    };

    dispatch({ type: 'ADD_ORDER', payload: newOrder });
    dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });
    
    const updatedOrders = [...state.orders, newOrder];
    const updatedTables = state.tables.map(t => t.id === tableId ? updatedTable : t);
    saveToStorage('orders', updatedOrders);
    saveToStorage('tables', updatedTables);
    
    // ✅ SINCRONIZAR NOVO PEDIDO COM REDE
    const networkService = NetworkService.getInstance();
    networkService.syncWithNetwork({
      type: 'new_order',
      order: newOrder,
      table: updatedTable,
      timestamp: new Date().toISOString()
    });
    
    return newOrder.id;
  };

  const addItemToOrder = (orderId: string, item: OrderItem) => {
    console.log('🛒 [CONTEXT] Adicionando item ao pedido:', { orderId, item });
    
    const order = state.orders.find(o => o.id === orderId);
    if (!order) {
      console.error('❌ [CONTEXT] Pedido não encontrado:', orderId);
      return;
    }

    console.log('📋 [CONTEXT] Estado atual do pedido:', {
      id: order.id,
      totalItens: order.items.length,
      clientes: order.customers.length,
      itensDetalhados: order.items.map(i => ({ id: i.id, nome: i.productName, cliente: i.customerName }))
    });

    // GARANTIR ID ÚNICO ABSOLUTO
    const uniqueId = `item-${Date.now()}-${Math.random().toString(36).substr(2, 12)}-${item.productId}-${order.items.length}`;
    
    const newItem: OrderItem = {
      ...item,
      id: uniqueId,
      status: 'pendente',
    };

    console.log('➕ [CONTEXT] Criando novo item com ID único:', {
      id: newItem.id,
      produto: newItem.productName,
      cliente: newItem.customerName,
      quantidade: newItem.quantity,
      preco: newItem.price
    });

    // CRIAR NOVA ARRAY DE ITENS (IMUTÁVEL)
    const updatedItems = [...order.items, newItem];
    const newTotal = updatedItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);

    console.log('📊 [CONTEXT] Cálculos atualizados:', {
      itensAntes: order.items.length,
      itensDepois: updatedItems.length,
      totalAntes: order.total,
      totalDepois: newTotal,
      novoItemId: newItem.id
    });

    // ATUALIZAR CUSTOMER ITEMS (IMUTÁVEL)
    const updatedCustomers = order.customers.map(customer => {
      if (customer.name === item.customerName) {
        const customerItems = [...customer.items, newItem]; // NOVA ARRAY
        const customerTotal = customerItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);
        
        console.log(`👤 [CONTEXT] Atualizando cliente ${customer.name}:`, {
          itensAntes: customer.items.length,
          itensDepois: customerItems.length,
          totalAntes: customer.totalAmount,
          totalDepois: customerTotal,
          novoItem: newItem.productName
        });
        
        return {
          ...customer,
          items: customerItems,
          totalAmount: customerTotal,
        };
      }
      return customer;
    });

    // CRIAR NOVO OBJETO ORDER COMPLETAMENTE IMUTÁVEL
    const updatedOrder: Order = {
      ...order,
      items: updatedItems,
      customers: updatedCustomers,
      total: newTotal,
      updatedAt: new Date().toISOString(),
    };
    
    console.log('📋 [CONTEXT] Pedido atualizado:', {
      id: updatedOrder.id,
      totalItens: updatedOrder.items.length,
      clientes: updatedOrder.customers.length,
      total: updatedOrder.total,
      ultimoItemAdicionado: newItem.id
    });
    
    // DISPATCH IMEDIATO COM NOVO OBJETO
    dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
    
    // Atualizar mesa
    const table = state.tables.find(t => t.orderId === orderId);
    if (table) {
      const updatedTable = {
        ...table,
        customers: updatedCustomers,
        lastActivity: new Date().toISOString(),
      };
      dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });
      
      // Salvar mesa atualizada
      const updatedTables = state.tables.map(t => t.id === table.id ? updatedTable : t);
      saveToStorage('tables', updatedTables);
    }
    
    // ✅ CORREÇÃO CRÍTICA: Salvar pedidos atualizados IMEDIATAMENTE
    const updatedOrders = state.orders.map(o => o.id === orderId ? updatedOrder : o);
    saveToStorage('orders', updatedOrders);
    
    // ✅ IMPORTANTE: Atualizar o estado local também para garantir sincronização
    dispatch({ type: 'SET_ORDERS', payload: updatedOrders });
    
    // Imprimir automaticamente na cozinha
    printToKitchen(updatedOrder, [newItem]);
    
    console.log('✅ [CONTEXT] Item adicionado com sucesso! Total de itens no pedido:', updatedOrder.items.length);
    console.log('💾 [CONTEXT] Dados salvos no localStorage e estado atualizado');
  };

  const removeItemFromOrder = (orderId: string, itemId: string) => {
    const order = state.orders.find(o => o.id === orderId);
    if (!order) return;

    const itemToRemove = order.items.find(i => i.id === itemId);
    if (!itemToRemove) return;

    const updatedItems = order.items.filter(item => item.id !== itemId);
    const newTotal = updatedItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);

    // Atualizar customer items
    const updatedCustomers = order.customers.map(customer => {
      if (customer.name === itemToRemove.customerName) {
        const customerItems = customer.items.filter(i => i.id !== itemId);
        const customerTotal = customerItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);
        return {
          ...customer,
          items: customerItems,
          totalAmount: customerTotal,
        };
      }
      return customer;
    });

    const updatedOrder = {
      ...order,
      items: updatedItems,
      customers: updatedCustomers,
      total: newTotal,
      updatedAt: new Date().toISOString(),
    };
    
    dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
    
    // Atualizar mesa
    const table = state.tables.find(t => t.orderId === orderId);
    if (table) {
      const updatedTable = {
        ...table,
        customers: updatedCustomers,
        lastActivity: new Date().toISOString(),
      };
      dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });
      
      const updatedTables = state.tables.map(t => t.id === table.id ? updatedTable : t);
      saveToStorage('tables', updatedTables);
    }
    
    const updatedOrders = state.orders.map(o => o.id === orderId ? updatedOrder : o);
    saveToStorage('orders', updatedOrders);
  };

  const updateOrderItem = (orderId: string, updatedItem: OrderItem) => {
    const order = state.orders.find(o => o.id === orderId);
    if (!order) return;

    const updatedItems = order.items.map(item => 
      item.id === updatedItem.id ? updatedItem : item
    );
    const newTotal = updatedItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);

    // Atualizar customer items
    const updatedCustomers = order.customers.map(customer => {
      const customerItems = customer.items.map(item => 
        item.id === updatedItem.id ? updatedItem : item
      );
      const customerTotal = customerItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);
      return {
        ...customer,
        items: customerItems,
        totalAmount: customerTotal,
      };
    });

    const updatedOrder = {
      ...order,
      items: updatedItems,
      customers: updatedCustomers,
      total: newTotal,
      updatedAt: new Date().toISOString(),
    };
    
    dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
    
    const updatedOrders = state.orders.map(o => o.id === orderId ? updatedOrder : o);
    saveToStorage('orders', updatedOrders);
  };

  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    const order = state.orders.find(o => o.id === orderId);
    if (!order) return;

    const updatedOrder = {
      ...order,
      status,
      updatedAt: new Date().toISOString(),
    };
    dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
    
    const updatedOrders = state.orders.map(o => o.id === orderId ? updatedOrder : o);
    saveToStorage('orders', updatedOrders);
  };

  const closeOrder = (orderId: string, paymentMethod: Order['paymentMethod']) => {
    console.log('💰 [CONTEXT] Fechando pedido:', { orderId, paymentMethod });
    
    const order = state.orders.find(o => o.id === orderId);
    if (!order) {
      console.error('❌ Pedido não encontrado para fechar:', orderId);
      return;
    }

    // ✅ CORREÇÃO CRÍTICA: Calcular valores restantes corretamente
    const totalOrder = order.total;
    const totalPaid = order.paidTotal || 0;
    const remainingAmount = totalOrder - totalPaid;

    console.log('💰 Valores do fechamento:', {
      totalPedido: totalOrder,
      jaPago: totalPaid,
      restante: remainingAmount,
      formaPagamento: paymentMethod
    });

    // ✅ IMPORTANTE: Atualizar paidTotal para incluir o valor restante
    const finalPaidTotal = totalOrder; // Todo o pedido será considerado pago

    const updatedOrder: Order = {
      ...order,
      status: 'fechado' as const,
      paymentMethod,
      paidTotal: finalPaidTotal, // ✅ CORREÇÃO: Marcar como totalmente pago
      closedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    console.log('✅ Pedido fechado:', {
      id: updatedOrder.id,
      status: updatedOrder.status,
      total: updatedOrder.total,
      paidTotal: updatedOrder.paidTotal,
      paymentMethod: updatedOrder.paymentMethod,
      closedAt: updatedOrder.closedAt
    });
    
    dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
    
    // ✅ CORREÇÃO CRÍTICA: Liberar mesa corretamente
    const table = state.tables.find(t => t.orderId === orderId);
    if (table) {
      console.log('🏠 Liberando mesa:', table.number);
      const updatedTable = {
        ...table,
        customers: [],
        waiterName: undefined,
        status: 'livre' as const,
        orderId: undefined,
        lastActivity: new Date().toISOString(),
      };
      
      console.log('🏠 Mesa atualizada:', {
        numero: updatedTable.number,
        status: updatedTable.status,
        clientes: updatedTable.customers.length,
        orderId: updatedTable.orderId
      });
      
      dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });
      
      const updatedTables = state.tables.map(t => t.id === table.id ? updatedTable : t);
      saveToStorage('tables', updatedTables);
      
      console.log('✅ Mesa liberada e salva no localStorage');
    }
    
    // ✅ SALVAR PEDIDO FECHADO IMEDIATAMENTE
    const updatedOrders = state.orders.map(o => o.id === orderId ? updatedOrder : o);
    saveToStorage('orders', updatedOrders);
    
    // ✅ ATUALIZAR ESTADO PARA GARANTIR SINCRONIZAÇÃO
    dispatch({ type: 'SET_ORDERS', payload: updatedOrders });
    
    // ✅ SINCRONIZAR FECHAMENTO COM REDE
    const networkService = NetworkService.getInstance();
    networkService.syncWithNetwork({
      type: 'order_closed',
      order: updatedOrder,
      timestamp: new Date().toISOString()
    });
    
    // ✅ CORREÇÃO: Imprimir recibo automaticamente após fechar pedido
    setTimeout(() => {
      printReceipt(updatedOrder);
    }, 500);
    
    console.log('💾 [CONTEXT] Pedido fechado salvo no localStorage e estado atualizado');
  };

  const cancelOrder = (orderId: string, reason: string) => {
    const order = state.orders.find(o => o.id === orderId);
    if (!order) return;

    const updatedOrder = {
      ...order,
      status: 'cancelado' as const,
      cancelReason: reason,
      updatedAt: new Date().toISOString(),
    };
    
    dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
    
    // Liberar mesa
    const table = state.tables.find(t => t.orderId === orderId);
    if (table) {
      const updatedTable = {
        ...table,
        customers: [],
        waiterName: undefined,
        status: 'livre' as const,
        orderId: undefined,
        lastActivity: new Date().toISOString(),
      };
      dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });
      
      const updatedTables = state.tables.map(t => t.id === table.id ? updatedTable : t);
      saveToStorage('tables', updatedTables);
    }
    
    const updatedOrders = state.orders.map(o => o.id === orderId ? updatedOrder : o);
    saveToStorage('orders', updatedOrders);
  };

  const updateOrder = (updatedOrder: Order) => {
    console.log('📝 [CONTEXT] Atualizando pedido:', updatedOrder.id);
    
    dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
    
    // Atualizar mesa se necessário
    const table = state.tables.find(t => t.orderId === updatedOrder.id);
    if (table) {
      const updatedTable = {
        ...table,
        customers: updatedOrder.customers,
        lastActivity: new Date().toISOString(),
      };
      dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });
      
      const updatedTables = state.tables.map(t => t.id === table.id ? updatedTable : t);
      saveToStorage('tables', updatedTables);
    }
    
    const updatedOrders = state.orders.map(o => o.id === updatedOrder.id ? updatedOrder : o);
    saveToStorage('orders', updatedOrders);
    
    console.log('✅ [CONTEXT] Pedido atualizado com sucesso');
  };

  const updateConfig = (config: AppConfig) => {
    dispatch({ type: 'SET_CONFIG', payload: config });
    saveToStorage('appConfig', config);
  };

  const sendOrderToKitchen = (orderId: string) => {
    const order = state.orders.find(o => o.id === orderId);
    if (!order) return;

    updateOrderStatus(orderId, 'enviado');
    printToKitchen(order, order.items);
  };

  const addProduct = (productData: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => {
    const newProduct: Product = {
      ...productData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    
    dispatch({ type: 'ADD_PRODUCT', payload: newProduct });
    
    const updatedProducts = [...state.products, newProduct];
    saveToStorage('products', updatedProducts);
  };

  const updateProduct = (product: Product) => {
    const updatedProduct = {
      ...product,
      updatedAt: new Date().toISOString(),
    };
    
    dispatch({ type: 'UPDATE_PRODUCT', payload: updatedProduct });
    
    const updatedProducts = state.products.map(p => p.id === product.id ? updatedProduct : p);
    saveToStorage('products', updatedProducts);
  };

  const deleteProduct = (productId: string) => {
    dispatch({ type: 'DELETE_PRODUCT', payload: productId });
    
    const updatedProducts = state.products.filter(p => p.id !== productId);
    saveToStorage('products', updatedProducts);
  };

  const addUser = (userData: Omit<User, 'id' | 'createdAt'>) => {
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    };
    
    dispatch({ type: 'ADD_USER', payload: newUser });
    
    const updatedUsers = [...state.users, newUser];
    saveToStorage('users', updatedUsers);
  };

  const updateUser = (user: User) => {
    dispatch({ type: 'UPDATE_USER', payload: user });
    
    const updatedUsers = state.users.map(u => u.id === user.id ? user : u);
    saveToStorage('users', updatedUsers);
  };

  const deleteUser = (userId: string) => {
    dispatch({ type: 'DELETE_USER', payload: userId });
    
    const updatedUsers = state.users.filter(u => u.id !== userId);
    saveToStorage('users', updatedUsers);
  };

  const addTable = (tableData: Omit<Table, 'id' | 'createdAt'>) => {
    const newTable: Table = {
      ...tableData,
      id: `table-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    
    dispatch({ type: 'ADD_TABLE', payload: newTable });
    
    const updatedTables = [...state.tables, newTable];
    saveToStorage('tables', updatedTables);
  };

  const updateTable = (table: Table) => {
    dispatch({ type: 'UPDATE_TABLE', payload: table });
    
    const updatedTables = state.tables.map(t => t.id === table.id ? table : t);
    saveToStorage('tables', updatedTables);
  };

  const deleteTable = (tableId: string) => {
    dispatch({ type: 'DELETE_TABLE', payload: tableId });
    
    const updatedTables = state.tables.filter(t => t.id !== tableId);
    saveToStorage('tables', updatedTables);
  };

  const addCustomerToTable = (tableId: string, customerName: string) => {
    const table = state.tables.find(t => t.id === tableId);
    if (!table) return;

    const newCustomer: Customer = {
      id: `customer-${Date.now()}-${Math.random()}`,
      name: customerName,
      items: [],
      totalAmount: 0,
      paidAmount: 0,
      status: 'ativo',
    };

    const updatedTable = {
      ...table,
      customers: [...table.customers, newCustomer],
      lastActivity: new Date().toISOString(),
    };

    dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });

    // Atualizar pedido se existir
    if (table.orderId) {
      const order = state.orders.find(o => o.id === table.orderId);
      if (order) {
        const updatedOrder = {
          ...order,
          customers: [...order.customers, newCustomer],
          updatedAt: new Date().toISOString(),
        };
        dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
        
        const updatedOrders = state.orders.map(o => o.id === table.orderId ? updatedOrder : o);
        saveToStorage('orders', updatedOrders);
      }
    }

    const updatedTables = state.tables.map(t => t.id === tableId ? updatedTable : t);
    saveToStorage('tables', updatedTables);
  };

  const removeCustomerFromTable = (tableId: string, customerId: string) => {
    const table = state.tables.find(t => t.id === tableId);
    if (!table) return;

    // ✅ VALIDAÇÃO CRÍTICA: Verificar se cliente tem consumo pendente
    const customer = table.customers.find(c => c.id === customerId);
    if (customer) {
      const amountPending = customer.totalAmount - customer.paidAmount;
      if (amountPending > 0) {
        console.error(`❌ Tentativa de remover cliente ${customer.name} com consumo pendente: R$ ${amountPending.toFixed(2)}`);
        return; // Bloquear remoção
      }
    }

    const updatedCustomers = table.customers.filter(c => c.id !== customerId);
    const updatedTable = {
      ...table,
      customers: updatedCustomers,
      lastActivity: new Date().toISOString(),
      status: updatedCustomers.length === 0 ? 'livre' as const : table.status,
    };

    dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });

    // Atualizar pedido se existir
    if (table.orderId) {
      const order = state.orders.find(o => o.id === table.orderId);
      if (order) {
        const customerToRemove = order.customers.find(c => c.id === customerId);
        if (customerToRemove) {
          // Remover itens do cliente do pedido
          const updatedItems = order.items.filter(item => item.customerName !== customerToRemove.name);
          const newTotal = updatedItems.reduce((sum, i) => sum + (i.price * i.quantity), 0);

          const updatedOrder = {
            ...order,
            customers: updatedCustomers,
            items: updatedItems,
            total: newTotal,
            updatedAt: new Date().toISOString(),
          };
          dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
          
          const updatedOrders = state.orders.map(o => o.id === table.orderId ? updatedOrder : o);
          saveToStorage('orders', updatedOrders);
        }
      }
    }

    const updatedTables = state.tables.map(t => t.id === tableId ? updatedTable : t);
    saveToStorage('tables', updatedTables);
  };

  const processIndividualPayment = (tableId: string, customerId: string, paymentMethod: 'dinheiro' | 'pix' | 'cartao') => {
    console.log('💳 [CONTEXT] Processando pagamento individual:', { tableId, customerId, paymentMethod });
    
    const table = state.tables.find(t => t.id === tableId);
    if (!table) {
      console.error('❌ Mesa não encontrada:', tableId);
      return;
    }

    const customer = table.customers.find(c => c.id === customerId);
    if (!customer) {
      console.error('❌ Cliente não encontrado:', customerId);
      return;
    }

    const amountToPay = customer.totalAmount - customer.paidAmount;
    
    if (amountToPay <= 0) {
      console.warn('⚠️ Cliente já quitou sua parte');
      return;
    }

    console.log('💰 Processando pagamento:', {
      cliente: customer.name,
      valorTotal: customer.totalAmount,
      jaPago: customer.paidAmount,
      aPagar: amountToPay,
      formaPagamento: paymentMethod
    });
    
    // ATUALIZAR CLIENTE COM PAGAMENTO COMPLETO
    const updatedCustomer = {
      ...customer,
      paidAmount: customer.totalAmount, // PAGAR O VALOR TOTAL DO CLIENTE
      status: 'pago' as const,
    };

    const updatedCustomers = table.customers.map(c => 
      c.id === customerId ? updatedCustomer : c
    );

    const updatedTable = {
      ...table,
      customers: updatedCustomers,
      lastActivity: new Date().toISOString(),
    };

    dispatch({ type: 'UPDATE_TABLE', payload: updatedTable });

    // ATUALIZAR PEDIDO SE EXISTIR - CORRIGIR CÁLCULO DO TOTAL PAGO
    if (table.orderId) {
      const order = state.orders.find(o => o.id === table.orderId);
      if (order) {
        const updatedOrderCustomers = order.customers.map(c => 
          c.id === customerId ? updatedCustomer : c
        );

        // RECALCULAR O TOTAL PAGO CORRETAMENTE
        const newPaidTotal = updatedOrderCustomers.reduce((sum, customer) => sum + customer.paidAmount, 0);

        console.log('🧮 Recalculando totais do pedido:', {
          totalPedidoAntes: order.total,
          totalPagoAntes: order.paidTotal,
          totalPagoDepois: newPaidTotal,
          pagamentoIndividual: amountToPay,
          clientePagou: customer.name
        });

        // ✅ CORREÇÃO CRÍTICA: Verificar se pedido foi totalmente quitado
        const isFullyPaid = newPaidTotal >= order.total;
        
        const updatedOrder = {
          ...order,
          customers: updatedOrderCustomers,
          paidTotal: newPaidTotal, // USAR O TOTAL RECALCULADO
          updatedAt: new Date().toISOString(),
          // ✅ CORREÇÃO: Marcar como fechado se totalmente quitado
          status: isFullyPaid ? 'fechado' as const : order.status,
          closedAt: isFullyPaid ? new Date().toISOString() : order.closedAt,
          paymentMethod: isFullyPaid ? 'dinheiro' as const : order.paymentMethod, // Definir método padrão
        };
        
        dispatch({ type: 'UPDATE_ORDER', payload: updatedOrder });
        
        const updatedOrders = state.orders.map(o => o.id === table.orderId ? updatedOrder : o);
        saveToStorage('orders', updatedOrders);
        
        // ✅ CORREÇÃO CRÍTICA: Liberar mesa quando pedido totalmente quitado
        if (isFullyPaid) {
          console.log('🏠 Pedido totalmente quitado via pagamentos individuais - liberando mesa');
          
          const fullyPaidTable = {
            ...updatedTable,
            customers: [],
            waiterName: undefined,
            status: 'livre' as const,
            orderId: undefined,
            lastActivity: new Date().toISOString(),
          };
          
          console.log('🏠 Mesa sendo liberada:', {
            numero: fullyPaidTable.number,
            statusAntes: updatedTable.status,
            statusDepois: fullyPaidTable.status,
            clientesAntes: updatedTable.customers.length,
            clientesDepois: fullyPaidTable.customers.length
          });
          
          dispatch({ type: 'UPDATE_TABLE', payload: fullyPaidTable });
          
          const finalUpdatedTables = state.tables.map(t => t.id === tableId ? fullyPaidTable : t);
          saveToStorage('tables', finalUpdatedTables);
          
          console.log('✅ Mesa liberada automaticamente - pedido quitado via pagamentos individuais');
        } else {
          // Salvar mesa com clientes atualizados se não foi totalmente quitado
          const updatedTables = state.tables.map(t => t.id === tableId ? updatedTable : t);
          saveToStorage('tables', updatedTables);
        }
        
        console.log('✅ Pedido atualizado com pagamento individual:', {
          totalPedido: updatedOrder.total,
          totalPago: updatedOrder.paidTotal,
          restante: updatedOrder.total - updatedOrder.paidTotal,
          percentualPago: ((updatedOrder.paidTotal / updatedOrder.total) * 100).toFixed(1) + '%'
        });
      } else {
        // Se não há pedido, apenas salvar a mesa atualizada
        const updatedTables = state.tables.map(t => t.id === tableId ? updatedTable : t);
        saveToStorage('tables', updatedTables);
      }
    } else {
      // Se não há pedido, apenas salvar a mesa atualizada
      const updatedTables = state.tables.map(t => t.id === tableId ? updatedTable : t);
      saveToStorage('tables', updatedTables);
    }


    console.log('✅ Pagamento individual processado com sucesso');
  };

  const printToKitchen = (order: Order, newItems: OrderItem[]) => {
    const kitchenPrinter = state.config.printers.kitchen;
    
    const kitchenTicket = `
===============================
🍳 PEDIDO COZINHA
===============================
Mesa: ${order.tableNumber}
Garçom: ${order.waiterName}
Data/Hora: ${new Date().toLocaleString('pt-BR')}
-------------------------------
CLIENTES NA MESA:
${order.customers.map(c => `• ${c.name}`).join('\n')}
-------------------------------
NOVOS ITENS:
${newItems.map(item => 
  `${item.quantity}x ${item.productName}
   Cliente: ${item.customerName}${item.notes ? `\n   Obs: ${item.notes}` : ''}`
).join('\n\n')}
-------------------------------
Total de itens: ${newItems.length}
===============================

-------------------------------
Techno A.I Soluções Tecnológicas
(28) 98115-3400
-------------------------------
    `.trim();

    console.log('🍳 IMPRIMINDO NA COZINHA:', kitchenTicket);
    
    // ✅ COMUNICAÇÃO MELHORADA: Usar NetworkService para envio
    if (kitchenPrinter && kitchenPrinter.enabled) {
      console.log(`🖨️ Enviando para impressora da cozinha: ${kitchenPrinter.name} (${kitchenPrinter.ip}:${kitchenPrinter.port})`);
      
      // ✅ USAR NETWORKSERVICE PARA COMUNICAÇÃO ROBUSTA
      const networkService = NetworkService.getInstance();
      networkService.sendToNetworkPrinter(
        kitchenPrinter.ip, 
        kitchenPrinter.port, 
        kitchenTicket
      ).then(success => {
        if (success) {
          console.log('✅ Pedido enviado para impressora da cozinha via rede');
          
          // ✅ SINCRONIZAR COM OUTROS MÓDULOS NA REDE
          networkService.syncWithNetwork({
            type: 'kitchen_order',
            order: order,
            newItems: newItems,
            timestamp: new Date().toISOString()
          });
        } else {
          console.warn('⚠️ Falha ao enviar para impressora da cozinha, usando fallback');
          printToKitchenFallback(kitchenTicket, order);
        }
      }).catch(error => {
        console.warn('⚠️ Erro ao conectar com impressora da cozinha, usando fallback:', error);
        printToKitchenFallback(kitchenTicket, order);
      });
    } else {
      // Fallback: abrir janela de impressão
      printToKitchenFallback(kitchenTicket, order);
    }
  };

  const printToKitchenFallback = (content: string, order: Order) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Pedido Cozinha - Mesa ${order.tableNumber}</title>
            <style>
              @page { 
                size: 80mm auto; 
                margin: 2mm; 
              }
              body { 
                font-family: 'Courier New', 'Consolas', monospace; 
                font-size: 16px; 
                font-weight: bold;
                margin: 0; 
                padding: 0;
                line-height: 1.3;
                color: #000;
              }
              pre { 
                white-space: pre-wrap; 
                margin: 0; 
                font-family: inherit;
                font-size: inherit;
                font-weight: inherit;
              }
              @media print {
                body { 
                  font-size: 14px; 
                  font-weight: bold;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                @page {
                  margin: 0;
                }
              }
            </style>
          </head>
          <body>
            <pre>${content}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      
      setTimeout(() => {
        printWindow.print();
        setTimeout(() => printWindow.close(), 2000);
      }, 1000);
    }
  };

  const printReceipt = (order: Order) => {
    const company = state.config.company;
    const receipt = `
${company.nomeFantasia}
Razão Social: ${company.razaoSocial}
CNPJ: ${company.cnpj}
${company.endereco}
-------------------------------
CUPOM FISCAL
-------------------------------
Mesa: ${order.tableNumber}
Garçom: ${order.waiterName}
Data/Hora: ${new Date(order.closedAt || order.createdAt).toLocaleString('pt-BR')}

CLIENTES E CONSUMO:
${order.customers.map(customer => `
${customer.name.toUpperCase()}:
${customer.items.map(item => 
  `  ${item.quantity}x ${item.productName} ........ R$ ${(item.price * item.quantity).toFixed(2)}`
).join('\n')}
  Subtotal: .............. R$ ${customer.totalAmount.toFixed(2)}
  Pago: .................. R$ ${customer.paidAmount.toFixed(2)}
  ${customer.totalAmount > customer.paidAmount ? 
    `Pendente: .............. R$ ${(customer.totalAmount - customer.paidAmount).toFixed(2)}` : 
    'Status: ............... PAGO'
  }
`).join('\n')}
-------------------------------
RESUMO GERAL:
Total Geral: ........... R$ ${order.total.toFixed(2)}
Total Pago: ............ R$ ${order.paidTotal.toFixed(2)}
${order.total > order.paidTotal ? 
  `Pendente: .............. R$ ${(order.total - order.paidTotal).toFixed(2)}` : 
  'Status: ............... QUITADO'
}

Forma de pagamento: ${order.paymentMethod === 'dinheiro' ? 'Dinheiro' : 
                                   order.paymentMethod === 'pix' ? 'PIX' : 
                                   order.paymentMethod === 'cartao' ? 'Cartão' : 'N/A'}
-------------------------------
Obrigado pela preferência!
Volte sempre!

-------------------------------
Techno A.I Soluções Tecnológicas
(28) 98115-3400
-------------------------------
    `.trim();

    console.log('🧾 IMPRIMINDO RECIBO:', receipt);
    
    // Abrir janela de impressão para recibo
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Cupom Fiscal - Mesa ${order.tableNumber}</title>
            <style>
              @page { 
                size: 80mm auto; 
                margin: 2mm; 
              }
              body { 
                font-family: 'Courier New', 'Consolas', monospace; 
                font-size: 16px; 
                font-weight: bold;
                margin: 0; 
                padding: 0;
                line-height: 1.3;
                color: #000;
              }
              pre { 
                white-space: pre-wrap; 
                margin: 0; 
                font-family: inherit;
                font-size: inherit;
                font-weight: inherit;
              }
              @media print {
                body { 
                  font-size: 14px; 
                  font-weight: bold;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                @page {
                  margin: 0;
                }
              }
            </style>
          </head>
          <body>
            <pre>${receipt}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      
      setTimeout(() => {
        printWindow.print();
        setTimeout(() => printWindow.close(), 2000);
      }, 1000);
    }
  };

  const printPreview = (order: Order) => {
    const waiterPrinter = state.config.printers.waiter;
    const company = state.config.company;
    
    const previewContent = `
${company.nomeFantasia}
Razão Social: ${company.razaoSocial}
CNPJ: ${company.cnpj}
${company.endereco}
-------------------------------
PRÉVIA DE CONSUMO
-------------------------------
Mesa: ${order.tableNumber}
Garçom: ${order.waiterName}
Data/Hora: ${new Date().toLocaleString('pt-BR')}

CLIENTES E CONSUMO:
${order.customers.map(customer => `
${customer.name.toUpperCase()}:
${customer.items.map(item => 
  `  ${item.quantity}x ${item.productName} ........ R$ ${(item.price * item.quantity).toFixed(2)}`
).join('\n')}
  Subtotal: .............. R$ ${customer.totalAmount.toFixed(2)}
  Pago: .................. R$ ${customer.paidAmount.toFixed(2)}
  ${customer.totalAmount > customer.paidAmount ? 
    `Pendente: .............. R$ ${(customer.totalAmount - customer.paidAmount).toFixed(2)}` : 
    'Status: ............... PAGO'
  }
`).join('\n')}
-------------------------------
RESUMO GERAL:
Total Geral: ........... R$ ${order.total.toFixed(2)}
Total Pago: ............ R$ ${order.paidTotal || 0}
${order.total > (order.paidTotal || 0) ? 
  `Pendente: .............. R$ ${(order.total - (order.paidTotal || 0)).toFixed(2)}` : 
  'Status: ............... QUITADO'
}

*** PRÉVIA DE CONSUMO ***
*** NÃO É CUPOM FISCAL ***
-------------------------------
Obrigado pela preferência!

-------------------------------
Techno A.I Soluções Tecnológicas
(28) 98115-3400
-------------------------------
    `.trim();

    console.log('📋 IMPRIMINDO PRÉVIA:', previewContent);
    
    // ✅ COMUNICAÇÃO MELHORADA: Usar NetworkService
    if (waiterPrinter && waiterPrinter.enabled) {
      console.log(`🖨️ Enviando prévia para impressora do garçom: ${waiterPrinter.name} (${waiterPrinter.ip}:${waiterPrinter.port})`);
      
      // ✅ USAR NETWORKSERVICE PARA COMUNICAÇÃO ROBUSTA
      const networkService = NetworkService.getInstance();
      networkService.sendToNetworkPrinter(
        waiterPrinter.ip, 
        waiterPrinter.port, 
        previewContent
      ).then(success => {
        if (success) {
          console.log('✅ Prévia enviada para impressora do garçom via rede');
        } else {
          console.warn('⚠️ Falha ao enviar para impressora do garçom, usando fallback');
          printPreviewFallback(previewContent, order);
        }
      }).catch(error => {
        console.warn('⚠️ Erro ao conectar com impressora do garçom, usando fallback:', error);
        printPreviewFallback(previewContent, order);
      });
    } else {
      // Fallback: abrir janela de impressão
      printPreviewFallback(previewContent, order);
    }
  };

  const printPreviewFallback = (content: string, order: Order) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Prévia de Consumo - Mesa ${order.tableNumber}</title>
            <style>
              @page { 
                size: 80mm auto; 
                margin: 2mm; 
              }
              body { 
                font-family: 'Courier New', 'Consolas', monospace; 
                font-size: 16px; 
                font-weight: bold;
                margin: 0; 
                padding: 0;
                line-height: 1.3;
                color: #000;
              }
              pre { 
                white-space: pre-wrap; 
                margin: 0; 
                font-family: inherit;
                font-size: inherit;
                font-weight: inherit;
              }
              @media print {
                body { 
                  font-size: 14px; 
                  font-weight: bold;
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
                @page {
                  margin: 0;
                }
              }
            </style>
          </head>
          <body>
            <pre>${content}</pre>
          </body>
        </html>
      `);
      printWindow.document.close();
      
      setTimeout(() => {
        printWindow.print();
        setTimeout(() => printWindow.close(), 2000);
      }, 1000);
    }
  };

  // Load data from localStorage on mount
  useEffect(() => {
    // ✅ INICIALIZAR NETWORKSERVICE PARA COMUNICAÇÃO
    const networkService = NetworkService.getInstance();
    console.log('🌐 NetworkService inicializado para comunicação entre módulos');
    
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
      dispatch({ type: 'SET_USER', payload: JSON.parse(savedUser) });
    }

    const savedConfig = localStorage.getItem('appConfig');
    if (savedConfig) {
      dispatch({ type: 'SET_CONFIG', payload: JSON.parse(savedConfig) });
    }

    // ✅ CORREÇÃO CRÍTICA: Carregar pedidos salvos do localStorage
    const savedOrders = localStorage.getItem('orders');
    if (savedOrders) {
      try {
        const parsedOrders = JSON.parse(savedOrders);
        console.log('📋 Carregando pedidos salvos:', parsedOrders.length);
        dispatch({ type: 'SET_ORDERS', payload: parsedOrders });
      } catch (error) {
        console.error('❌ Erro ao carregar pedidos salvos:', error);
      }
    }

    const savedProducts = localStorage.getItem('products');
    if (savedProducts) {
      dispatch({ type: 'SET_PRODUCTS', payload: JSON.parse(savedProducts) });
    }

    const savedUsers = localStorage.getItem('users');
    if (savedUsers) {
      dispatch({ type: 'SET_USERS', payload: JSON.parse(savedUsers) });
    }

    const savedTables = localStorage.getItem('tables');
    if (savedTables) {
      dispatch({ type: 'SET_TABLES', payload: JSON.parse(savedTables) });
    } else {
      // Se não há mesas salvas, usar as 30 mesas padrão
      saveToStorage('tables', tablesData);
    }
  }, []);

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        login,
        logout,
        createOrder,
        addItemToOrder,
        removeItemFromOrder,
        updateOrderItem,
        updateOrderStatus,
        closeOrder,
        cancelOrder,
        updateOrder,
        updateConfig,
        sendOrderToKitchen,
        addProduct,
        updateProduct,
        deleteProduct,
        addUser,
        updateUser,
        deleteUser,
        addTable,
        updateTable,
        deleteTable,
        addCustomerToTable,
        removeCustomerFromTable,
        processIndividualPayment,
        printToKitchen,
        printReceipt,
        printPreview,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};