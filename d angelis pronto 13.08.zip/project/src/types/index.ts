export interface User {
  id: string;
  username: string;
  password: string;
  role: 'garcom' | 'admin';
  name: string;
  active: boolean;
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  category: string;
  available: boolean;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  id: string;
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  customerName: string;
  notes?: string;
  status: 'pendente' | 'enviado' | 'preparando' | 'pronto' | 'entregue';
  sentAt?: string;
  paidBy?: string; // ID do cliente que pagou este item
}

export interface Customer {
  id: string;
  name: string;
  items: OrderItem[];
  totalAmount: number;
  paidAmount: number;
  status: 'ativo' | 'pago' | 'saiu';
}

export interface Order {
  id: string;
  tableNumber: string;
  customers: Customer[];
  items: OrderItem[];
  status: 'aberto' | 'enviado' | 'preparando' | 'pronto' | 'fechado' | 'cancelado';
  createdAt: string;
  updatedAt: string;
  waiterName: string;
  total: number;
  paidTotal: number;
  paymentMethod?: 'dinheiro' | 'pix' | 'cartao';
  closedAt?: string;
  cancelReason?: string;
}

export interface Table {
  id: string;
  number: string;
  customers: Customer[];
  waiterName?: string;
  status: 'livre' | 'ocupada' | 'aguardando';
  orderId?: string;
  createdAt: string;
  lastActivity?: string;
}

export interface CompanyConfig {
  nomeFantasia: string;
  razaoSocial: string;
  cnpj: string;
  endereco: string;
}

export interface PrinterConfig {
  id: string;
  name: string;
  ip: string;
  port: number;
  enabled: boolean;
  type: 'kitchen' | 'waiter';
}

export interface AppConfig {
  company: CompanyConfig;
  printers: {
    kitchen: PrinterConfig | null;
    waiter: PrinterConfig | null;
  };
  tables: {
    total: number;
    layout: 'grid' | 'list';
  };
}

export interface SubAccount {
  customerName: string;
  items: OrderItem[];
  total: number;
}

export interface PrintJob {
  id: string;
  type: 'kitchen' | 'receipt';
  content: string;
  status: 'pending' | 'printing' | 'completed' | 'failed';
  createdAt: string;
}